#!/bin/bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

string="run_Scanip.py -u 1"
#output=$(python $DIR/$string 2>&1)
#echo $output
cd /var/www/yana-server/plugins/HomeCheck/rpc/
sudo python -m server &

#@reboot sudo ifdown wlan0
#@reboot sudo /var/www/yana-server/plugins/HomeCheck/AFSniffer &
