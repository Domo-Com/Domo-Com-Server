
function plugin_alarme_chargement(blockId)
{
	document.getElementById(blockId).innerHTML = "<img src=\"./plugins/HomeCheck/img/preloader.gif\" align=\"middle\" alt=\"Chargement...Patientez\"></img>";
}

function sprintf(template, values) {
  return template.replace(/%s/g, function() {
    return values.shift();
  });
}

/*
$(function() {
	 clearTimeout() ;
})


$(function(){
setTimeout(HomeCheck_GetPic, 9000000);
});

function HomeCheck_GetPic(){

	url = "action.php?action=HomeCheck_GetPic";
	
	$.ajax({
		url: url
	}).done(function(answer) {
		answer = answer.trim();
		}
		console.log(answer);
		setTimeout(HomeCheck_GetPic, 9000000);
	});
		
}
*/

//Onglet Alarme>General
$(function(){
	$('#getOP').click(function() {
		getOP();
	});
});


//Onglet Alarme>General
$(function(){
	$('#plugin_alarme_doc_install').click(function() {
		plugin_alarme_addCommande_VocaleOn();
	});
});

//Onglet Alarme>Commandes Vocales
function plugin_alarme_addCommande_VocaleOn()
{
	if ($('#CommandeVocaleOn').val()=="")
	{
		alert ('Le champ Commande Vocale d\'activation de l\'alarme est vide');
		return false;
	}
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_CommandeVocale',
		type:'On',
		commandeVocale:$('#CommandeVocaleOn').val()
		}, function() {
		$('#CommandeVocaleOn').val('');
	});
};

$(function(){
	$('#submitAlarme_AddCommandes_VocaleOn').click(function() {
		plugin_alarme_addCommande_VocaleOn();
	});
});

function plugin_alarme_addCommande_VocaleOff()
{
	if ($('#CommandeVocaleOff').val()=="")
	{
		alert ('Le champ Commande Vocale d\'arrét de l\'alarme est vide');
		return false;
	}
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_CommandeVocale',
		type:'Off',
		commandeVocale:$('#CommandeVocaleOff').val()
		}, function() {
		$('#CommandeVocaleOff').val('');
	});
};

$(function(){
	$('#plugin_alarme_addCommande_VocaleOff').click(function() {
		plugin_alarme_addCommande_VocaleOff();
	});
});

function plugin_AddHomeCheck()
{
	if ($('#nameHomeCheck').val()=="")
	{
		alert ('Le champ nom est vide');
		return false;
	}
	
	if ($('#ISADMINHomeCheck').val()=="Yes") {
		IsAdmin=1;
	} else {
		IsAdmin=0;
	}
	
	if ($('#IsClientServHomeCheck').val()=="Yes") {
		IsClientServ=1;
	} else {
		IsClientServ=0;
	}

	
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_save_HomeCheck',
		id:$('#id').val(),
		nameHomeCheck:$('#nameHomeCheck').val(),
		descriptionHomeCheck:$('#descriptionHomeCheck').val(),
		IMEIHomeCheck:$('#IMEIHomeCheck').val(),
		ISADMINHomeCheck:IsAdmin,
		PASSHomeCheck:$('#PASSHomeCheck').val(),
		MobileHomeCheck:$('#MobileHomeCheck').val(),
		EmailHomeCheck:$('#EmailHomeCheck').val(),
		IsClientServHomeCheck:IsClientServ
		}, function() {
		$('#id').val('');	
		$('#nameHomeCheck').val('');
		$('#descriptionHomeCheck').val();
		$('#IMEIHomeCheck').val();
		$('#ISADMINHomeCheck').val();
		$('#PASSHomeCheck').val();
		$('#MobileHomeCheck').val();
		$('#EmailHomeCheck').val();
		$('#IsClientServHomeCheck').val();
	});
};

$(function(){
	$('#plugin_AddHomeCheck').click(function() {
		plugin_AddHomeCheck();
	});
});


function plugin_alarm_detectpos(element) {
	
	if ($('#MobileHomeCheck').val()=="") {
		alert("Selectionnez membre");
		return;
	};
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'HomeCheck_GetPos',
		nummob:$('#MobileHomeCheck').val()
		}, function() {
		$('#MobileHomeCheck').val('');
	});
	alert("Patientez un moment, le destinataire transmet sa position, puis Actualisez");

};

function plugin_alarm_fillpos(element) {
	
	var iframe = document.getElementById('mylovelyiframe');
	var doc = iframe.contentWindow.document;
	var elem = document.getElementById('mcc');
	alert(elem.value);
	elem.value = "123456" //doc.getElementsByName('thisone')[0].value;

};

//Onglet AlarmeAD>GPIO
function plugin_alarme_addADSensor()
{
	if ($('#descriptionADGPIO').val()=="")
	{
		alert ("Le Description du détecteur est vide");
		return false;
	}
		
	if ($('#numADGPIO').val()=="")
	{
		alert ('Le champ Numéro du GPIO est vide');
		return false;
	}
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_Sensor',
		type:$('#SensorType').val(),
		descriptionSensor:$('#descriptionADGPIO').val(),
		numGPIO:$('#numADGPIO').val()
		}, function() {
		$('#descriptionADGPIO').val('');
		$('#numADGPIO').val('');
	});
};

$(function(){
	$('#submitAlarme_AddADSensor').click(function() {
		plugin_alarme_addADSensor();
	});
});

function plugin_alarme_delete_alarme_ADSensor(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_ADSensor',
	id:id
	});
};

//Onglet Detecteur>GPIO

function plugin_alarme_addSensor()
{
	if ($('#descriptionSensor').val()=="")
	{
		alert ("Le Description du détecteur est vide");
		return false;
	}
		
	if ($('#numGPIO').val()=="")
	{
		alert ('Le champ Numéro du GPIO est vide');
		return false;
	}
	
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_Sensor',
		type:$('#SensorType').val(),
		descriptionSensor:$('#descriptionSensor').val(),
		numGPIO:$('#numGPIO').val()
		}, function() {
		$('#descriptionSensor').val('');
		$('#numGPIO').val('');
	});
};

$(function(){
	$('#submitAlarme_AddSensor').click(function() {
		plugin_alarme_addSensor();
	});
});

function plugin_alarme_delete_alarme_Sensor(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_Sensor',
	id:id
	});
};

function plugin_alarme_timetoStart()
{
	plugin_alarme_chargement("plugin_alarme_test_span3");
	$('#plugin_alarme_test_span3').load('action.php',{
		action:'plugin_alarme_timetoStart',
		time:$('#plugin_alarme_timetoStart').val()
		}, function() {
		$('#plugin_alarme_test_span3').fadeIn();
		$('#plugin_alarme_test_span3').delay(5000);
		$('#plugin_alarme_test_span3').fadeOut();
	});
}

$(function(){
	$('#submit_plugin_alarme_timetoStart').click(function() {
		plugin_alarme_timetoStart();
	});
});

//onglet config wificonfig

function plugin_alarme_test_wifi(id)
{

	user="0";
	pass="0";
	if (id==3) {
		if ($('#wifiUserId').val()=="")
		{
			alert ("Le champ ssid est vide");
			return false;
		}
		else {
			user=$('#wifiUserId').val()
		}
			
		if ($('#wifiPass').val()=="")
		{
			alert ('Le champ Mot de passe est vide');
			return false;
		} else {
			pass=$('#wifiPass').val()
		}
	}
	
	
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_test_wifi',
		id:id,
		user:user,
		pass:pass,
		}, function() {
		$('#plugin_alarme_test_span3').fadeIn();
	});
}


//Onglet Actions SMS
function plugin_alarme_test_SMS()
{
	if ($('#AlarmeUserId').val()=="")
	{
		alert ("Le champ Utilisateur est vide");
		return false;
	}
		
	if ($('#AlarmePassId').val()=="")
	{
		alert ('Le champ Mot de passe est vide');
		return false;
	}
	
	if ($('#AlarmeMsgId').val()=="")
	{
		alert ('Le champ Message est vide');
		return false;
	}
	
	plugin_alarme_chargement("plugin_alarme_test_span");
	$('#plugin_alarme_test_span').load('action.php',{
		action:'plugin_alarme_test_SMS',
		user:$('#AlarmeUserId').val(),
		pass:$('#AlarmePassId').val(),
		msg:$('#AlarmeMsgId').val()
		}, function() {
		$('#plugin_alarme_test_span').fadeIn();
		$('#plugin_alarme_test_span').delay(5000);
		$('#plugin_alarme_test_span').fadeOut();
	});
}

$(function(){
	$('#submitAlarme_test_SMS').click(function() {
		plugin_alarme_test_SMS();
	});
});

function plugin_alarme_test_SMS_ponctuel(id)
{
	$("#plugin_alarme_test_sms"+id).toggleClass('fa fa-refresh').toggleClass('fa fa-spinner fa-spin');
	$('#plugin_alarme_test_spanId'+id).load('action.php',{
		action:'plugin_alarme_test_SMS',
		id:id
		}, function() {
		$("#plugin_alarme_test_sms"+id).toggleClass('fa fa-spinner fa-spin').toggleClass('fa fa-refresh');
		$('#plugin_alarme_test_spanId'+id).fadeIn();
		$('#plugin_alarme_test_spanId'+id).delay(5000);
		$('#plugin_alarme_test_spanId'+id).fadeOut();
	});
}


function plugin_alarme_addActions_SMS()
{
	if ($('#AlarmeUserId').val()=="")
	{
		alert ("Le champ Utilisateur est vide");
		return false;
	}
		
	if ($('#AlarmePassId').val()=="")
	{
		alert ('Le champ Mot de passe est vide');
		return false;
	}
	
	if ($('#AlarmeMsgId').val()=="")
	{
		alert ('Le champ Message est vide');
		return false;
	}
	
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_sms',
		AlarmeTypeName:$('#AlarmeTypeId').val(),
		AlarmeUserName:$('#AlarmeUserId').val(),
		AlarmePassName:$('#AlarmePassId').val(),
		AlarmeMsgName:$('#AlarmeMsgId').val()
		}, function() {
		$('#AlarmeUserId').val('');
		$('#AlarmePassId').val('');
		$('#AlarmeMsgId').val('');
	});
};

$(function(){
	$('#submitAlarme_AddActions_SMS').click(function() {
		plugin_alarme_addActions_SMS();
	});
});


function plugin_alarme_delete_alarme_SMS(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_SMS',
	id:id
	});
};

//Onglet Actions Email
function plugin_alarme_test_Email()
{
	if ($('#smtpServerAddr').val()=="" && $('#smtpServerPort').val()=="" && $('#smtpServerUser').val()=="" && $('#smtpServerPasswd').val()=="" 
	&& $('#EmailAddr').val()=="" && $('#EmailExp').val()=="" && $('#EmailOjt').val()=="" && $('#EmailMsg').val()=="")
	{
		alert ("Un champs obligatoire est vide");
		return false;
	}
		
	plugin_alarme_chargement("plugin_alarme_test_span");
	$('#plugin_alarme_test_span').load('action.php',{
		action:'plugin_alarme_test_Email',	
		smtpServerAddr:$('#smtpServerAddr').val(),
		smtpServerPort:$('#smtpServerPort').val(),
		smtpServerSSL:$('#smtpServerSSL').val(),
		smtpServerUser:$('#smtpServerUser').val(),
		smtpServerPasswd:$('#smtpServerPasswd').val(),
		EmailAddr:$('#EmailAddr').val(),
		EmailExp:$('#EmailExp').val(),
		EmailOjt:$('#EmailOjt').val(),
		EmailMsg:$('#EmailMsg').val()
		}, function() {
		$('#plugin_alarme_test_span').fadeIn();
		$('#plugin_alarme_test_span').delay(5000);
		$('#plugin_alarme_test_span').fadeOut();
	});
}

$(function(){
	$('#submitAlarme_test_Email').click(function() {
		plugin_alarme_test_Email();
	});
});

function plugin_alarme_test_Email_ponctuel(id)
{
	$("#plugin_alarme_test_email"+id).toggleClass('fa fa-refresh').toggleClass('fa fa-spinner fa-spin');
	$('#plugin_alarme_test_spanId'+id).load('action.php',{
		action:'plugin_alarme_test_Email',
		id:id
		}, function() {
		$("#plugin_alarme_test_email"+id).toggleClass('fa fa-spinner fa-spin').toggleClass('fa fa-refresh');
		$('#plugin_alarme_test_spanId'+id).fadeIn();
		$('#plugin_alarme_test_spanId'+id).delay(5000);
		$('#plugin_alarme_test_spanId'+id).fadeOut();
	});
};

$(function(){
	$('#submitAlarme_AddActionProg').click(function() {
		submitAlarme_AddActionProg();
	});
});

function submitAlarme_AddActionProg()
{
	var appt,stdate,endate,month,week,weekd,day,hour,minute,url;
	var description,cmd,jj;
	var input,isMinuteChecked,ishourChecked;
	var jitter =120; // delay the job execution in s avoid traffic
	if ( $('#descriptionProg').val()=="")
	{
		alert ("Description obligatoire est vide");
		return false;
	}
	
	//appt=$('#appt').val();
	//if ( appt=="") appt="*"
	
	stdate=$('#tripstart').val();
	endate=$('#tripend').val();
	month="";
	jj=0;
	var selectedValues = [];    
    $("#month :selected").each(function(){
		if (jj==0) {month+=$(this).val();}
		else {month+="-"+$(this).val();}
			selectedValues.push($(this).val()); 
    });

    if (month=="" || month=="-1") month="*";
	selectedValues = []; 
	week="";
	jj=0;
    $("#week :selected").each(function(){
		if (jj==0) {week+=$(this).val();}
		else {week+="-"+$(this).val();}
		jj+=1;
		selectedValues.push($(this).val()); 
    });
	if (week=="" || week=="-1") week="*";
    //alert(selectedValues);
	
	selectedValues = []; 
	weekd='';
	jj=0;
    $("#weekday :selected").each(function(){
		if (jj==0) {weekday+=$(this).val();}
		else {weekday+="-"+$(this).val();}
		jj+=1;
		selectedValues.push($(this).val()); 
    });
    if (weekd=="" ||weekd=="-1") weekd="*";
	 
	selectedValues = []; 
	day="";
	jj=0;
    $("#day :selected").each(function(){
		if (jj==0) {day+=$(this).val();}
		else {day+="-"+$(this).val();}
		jj+=1;
		selectedValues.push($(this).val()); 
    });
    if (day=="" || day=="-1") day="*";
	
	selectedValues = []; 
	hour="";
	jj=0;
    $("#hour :selected").each(function(){
		if (jj==0) {hour+=$(this).val();}
		else {hour+="-"+$(this).val();}
		jj+=1;
		selectedValues.push($(this).val()); 
    });
    if (hour=="" || hour=="-1") hour="*";
	input = document.getElementById("everyhour");
	ishourChecked = input.checked;
	ishourChecked = (ishourChecked)? "checked" : "not checked";
	if (ishourChecked == 'checked') hour="*\/"+minute;
	
	selectedValues = []; 
	minute="";
	jj=0;
    $("#minute :selected").each(function(){
		if (jj==0) {minute+=$(this).val();}
		else {minute+="-"+$(this).val();}
		jj+=1;
		selectedValues.push($(this).val()); 
    });
    if (minute=="" || minute=="-1") minute="*";
	input = document.getElementById("everyminute");
	isMinuteChecked = input.checked;
	isMinuteChecked = (isMinuteChecked)? "checked" : "not checked";
	if (isMinuteChecked == 'checked') minute="*\/"+minute;
	
	var e = document.getElementById("relaiaction");
	var actionurl = e.options[e.selectedIndex].value;
	
	if (actionurl==-1) alert ("Sans action associée c'est moins drôle :=)");
	cmd=sprintf('month=%s,day=%s,week=%s,day_of_week=%s,hour=%s,minute=%s',[
		  month,day,week,weekd,hour,minute]);
	//cmd='mounth=${mounth},day=${day}, week=${week}, day_of_week=${weekd}, //hour=${hour}, minute=${minute},';
	if (stdate!="") cmd+=",start_date="+stdate;
	if (endate!="") cmd+=",end_date="+endate;
	cmd+=",jitter="+jitter;
	
	
	console.log(cmd);
	console.log(actionurl);
	
	$('#xhrAlarme').load('action.php',{
		action:'AddActionProg',	
		id:$('#id').val(),
		descriptionProg:$('#descriptionProg').val(),
		cmd:cmd,
		url:actionurl,
		pic:0,
		},function() {
			location.reload();
	});

};

$(function(){
	$('#submitAlarme_AddActionLumi').click(function() {
		submitAlarme_AddActionLumi();
	});
});

function submitAlarme_AddActionLumi()
{
	var lumi,hour,minute,url,interv;
	var description,cmd,jj;
	var input,isMinuteChecked,ishourChecked;
	var jitter =120; // delay the job execution in s avoid traffic
	
	if ($('#descriptionProg').val()=="")
	{
		alert ("Description obligatoire est vide");
		return false;
	}
	
	minute=$('#intmin').val();
	var intval = parseInt(minute, 10);
	if (intval<5 || intval>59) {
		alert("Fréquence incohérente");
		return;
	}
	minute= minute="*\/"+minute; //every
	
	lumi=$('#slumi').val();
	relaiscr=$('#relaiscr').val();
	
	senslumi=$('#senslumi').val();
	
	interv=$('#interv').val();
	if (interv!="") {
		var hour=interv.split(":");
		var ihour=parseInt(hour[0], 10);
		var ehour=parseInt(hour[1], 10);
		if (ehour<ihour) {
			hour=ihour+"-23,0-"+ehour;				//19-23,0-5
		} else {
			hour=ihour+"-"+ehour;	
		}
	} else {
		hour="*";
	}
	
	var e = document.getElementById("relaiactionlumi");
	var actionurl = e.options[e.selectedIndex].value;
	
	if (actionurl==-1) alert ("Sans action associée c'est moins drôle :=)");
	
	cmd=sprintf("hour=%s,minute=%s,jitter=%s",[hour,minute,jitter]);
		  
	//console.log(cmd);
	//console.log(actionurl);
	//console.log(relaiscr);
	//console.log(senslumi);
	//console.log(lumi);

	$('#xhrAlarme').load('action.php',{
		action:'AddActionLumi',	
		id:$('#id').val(),
		descriptionProg:$('#descriptionProg').val(),
		cmd:cmd,
		url:actionurl,
		pic:senslumi+"_"+lumi,
		linkr:relaiscr,
		},function() {
			location.reload();
	});

};

$(function(){
	$('#submitAlarme_AddActionGroup').click(function() {
		submitAlarme_AddActionGroup();
	});
});

function submitAlarme_AddActionGroup()
{
	
	if ( $('#descriptionGroup').val()=="")
	{
		alert ("Un champs obligatoire est vide");
		return false;
	}
	
	$('#xhrAlarme').load('action.php',{
		action:'AddActionGroup',	
		id:$('#id').val(),
		descriptionGroup:$('#descriptionGroup').val(),
		onCommand:$('#actiongroupOn').val(),
		offCommand:$('#actiongroupOff').val(),
		},function() {
			location.reload();
	});
};

function submitAlarme_AddActionItemGroup()
{
	if ($('#id').val()=="") {
		alert ("Un champs obligatoire est vide");
		return false;
	}
	if ($('#relaiaction').val()=="" ) {
		alert ("Un champs obligatoire est vide");
		return false;
	}
	var e = document.getElementById("relaiaction");
	var description = e.options[e.selectedIndex].text;
	
	
	$('#xhrAlarme').load('action.php',{
		action:'AddActionItemGroup',
		id:$('#id').val(),	
		linkid:$('#relaiaction').val(),
		description:description
		},function() {
			location.reload();
	});
	
};

function plugin_alarme_addActions_Email()
{
	if ($('#EmailAddr').val()=="" )
	{
		alert ("Un champs obligatoire est vide");
		return false;
	}

	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_Email',	
		EmailExp:$('#EmailExp').val()
		}, function() {
		$('#smtpServerAddr').val(''),
		$('#smtpServerPort').val(''),
		$('#smtpServerSSL').val(''),
		$('#smtpServerUser').val(''),
		$('#smtpServerPasswd').val('')
	});
};

$(function(){
	$('#submitAlarme_AddActions_Email').click(function() {
		plugin_alarme_addActions_Email();
	});
});

function plugin_alarme_delete_alarme_Email(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_Email',
	id:id
	});
};

$(function(){
	$('#IconeEmailInfobulle').click(function() {
		$("#EmailInfobulle" ).slideToggle( "slow", function() {

		});
	});
});


//Onglet Actions GPIO
function plugin_alarme_test_GPIO()
{
	if ($('#numGPIO').val()=="")
	{
		alert ('Le champ Numéro du GPIO est vide');
		return false;
	}
	
	if ($('#stateGPIO').val()=="")
	{
		alert ('Le champ Etat du GPIO est vide');
		return false;
	}
	
	plugin_alarme_chargement("plugin_alarme_test_span");
	$('#plugin_alarme_test_span').load('action.php',{
		action:'plugin_alarme_test_GPIO',
		numGPIO:$('#numGPIO').val(),
		stateGPIO:$('#stateGPIO').val()
		}, function() {
		$('#plugin_alarme_test_span').fadeIn();
		$('#plugin_alarme_test_span').delay(5000);
		$('#plugin_alarme_test_span').fadeOut();
	});
}

$(function(){
	$('#submitAlarme_test_GPIO').click(function() {
		plugin_alarme_test_GPIO();
	});
});

function plugin_alarme_test_GPIO_ponctuel(id)
{
	$("#plugin_alarme_test_GPIO"+id).toggleClass('fa fa-refresh').toggleClass('fa fa-spinner fa-spin');
	$('#plugin_alarme_test_spanId'+id).load('action.php',{
		action:'plugin_alarme_test_GPIO',
		id:id
		}, function() {
		$("#plugin_alarme_test_sms"+id).toggleClass('fa fa-spinner fa-spin').toggleClass('fa fa-refresh');
		$('#plugin_alarme_test_spanId'+id).fadeIn();
		$('#plugin_alarme_test_spanId'+id).delay(5000);
		$('#plugin_alarme_test_spanId'+id).fadeOut();
	});
}

function plugin_alarme_addActions_GPIO()
{
	if ($('#descriptionGPIO').val()=="")
	{
		alert ("Le Description du GPIO est vide");
		return false;
	}
		
	if ($('#numGPIO').val()=="")
	{
		alert ('Le champ Numéro du GPIO est vide');
		return false;
	}
	
	if ($('#stateGPIO').val()=="")
	{
		alert ('Le champ Etat du GPIO est vide');
		return false;
	}
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_GPIO',
		descriptionGPIO:$('#descriptionGPIO').val(),
		numGPIO:$('#numGPIO').val(),
		stateGPIO:$('#stateGPIO').val()
		}, function() {
		$('#descriptionGPIO').val('');
		$('#numGPIO').val('');
		$('#stateGPIO').val('');
	});
};

$(function(){
	$('#submitAlarme_AddActions_GPIO').click(function() {
		plugin_alarme_addActions_GPIO();
	});
});

function plugin_alarme_delete_alarme_GPIO(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_GPIO',
	id:id
	});
};

//Onglet Actions vocales
function plugin_alarme_test_Vocal()
{
	if ($('#MessageVocal').val()=="")
	{
		alert ('Le champ Message Vocal est vide');
		return false;
	}
		
	plugin_alarme_chargement("plugin_alarme_test_span");
	$('#plugin_alarme_test_span').load('action.php',{
		action:'plugin_alarme_test_Vocal',
		MessageVocal:$('#MessageVocal').val()
		}, function() {
		$('#plugin_alarme_test_span').fadeIn();
		$('#plugin_alarme_test_span').delay(5000);
		$('#plugin_alarme_test_span').fadeOut();
	});
}

$(function(){
	$('#submitAlarme_test_Vocal').click(function() {
		plugin_alarme_test_Vocal();
	});
});

function plugin_alarme_test_Vocal_ponctuel(id)
{
	$("#plugin_alarme_test_GPIO"+id).toggleClass('fa fa-refresh').toggleClass('fa fa-spinner fa-spin');
	$('#plugin_alarme_test_spanId'+id).load('action.php',{
		action:'plugin_alarme_test_Vocal',
		id:id
		}, function() {
		$("#plugin_alarme_test_vocal"+id).toggleClass('fa fa-spinner fa-spin').toggleClass('fa fa-refresh');
		$('#plugin_alarme_test_spanId'+id).fadeIn();
		$('#plugin_alarme_test_spanId'+id).delay(5000);
		$('#plugin_alarme_test_spanId'+id).fadeOut();
	});
}

function plugin_alarme_addActions_Vocal()
{
	if ($('#MessageVocal').val()=="")
	{
		alert ('Le champ Numéro du GPIO est vide');
		return false;
	}
	plugin_alarme_chargement("xhrAlarme");	
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_Vocal',
		MessageVocal:$('#MessageVocal').val()
		}, function() {
		$('#MessageVocal').val('');
	});
};

$(function(){
	$('#submitAlarme_AddActions_Vocal').click(function() {
		plugin_alarme_addActions_Vocal();
	});
});

function plugin_alarme_delete_alarme_Vocal(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_Vocal',
	id:id
	});
};


function plugin_HomeCheck_delete(id){

	if(!confirm('Êtes vous sûr de vouloir faire ça ?')) return;
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_delete_HomeCheck',
	id:id
	});
}

function plugin_ActionGroup_delete(id){

	if(!confirm('Êtes vous sûr de vouloir faire ça ?')) return;
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_delete_ActionGroup',
		id:id
	},function() {
			location.reload();
	});
}


function plugin_ActionProg_delete(id){

	if(!confirm('Êtes vous sûr de vouloir faire ça ?')) return;
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_delete_ActionProg',
		id:id
	},function() {
			location.reload();
	});
}

function plugin_ActionProg_mod(id){

	if(!confirm('Êtes vous sûr de vouloir faire ça ?')) return;
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_mod_ActionProg',
		id:id,
	},function() {
			location.reload();
	});
}

function plugin_ActionProg_nextrun(id){

	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_check_ActionProg',
		id:id
	},function() {
		$('#plugin_alarme_test_span3').fadeIn();
	});
	
}

function plugin_ActionItemGroup_delete(id,linkid){

	if(!confirm('Êtes vous sûr de vouloir faire ça ?')) return;
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_delete_ActionItemGroup',
		id:id,
		linkid:linkid
	},function() {
			location.reload();
	});
}


function plugin_HomeCheck_RelayDelete(id){

	if(!confirm('Êtes vous sûr de vouloir faire ça ?')) return;
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_delete_Relay',
	id:id
	});
}


function plugin_HomeCheck_RadioDelete(id,type){
	
	if(!confirm('Êtes vous sûr de vouloir faire ça ?')) return;
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_delete_Radio',
	id:id,
	type:type
	});
}

function plugin_alarme_delete_alarme_CommandeVocale(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_CommandeVocale',
	id:id
	});
};

//Onglet Camera 

$(function(){
	$('#IconeCameraInfobulle').click(function() {
		$("#CameraInfobulle" ).slideToggle( "slow", function() {
		});
	});
});

$(function(){
	$('#Plugin_Alarme_Camera').change(function() {
		if($("select option:selected").val()=="Photo")
		{
			$("#Plugin_Alarme_Video" ).slideToggle( "slow", function() {	
			});
			$("#Plugin_Alarme_Photo" ).slideToggle( "slow", function() {	
			});
		}
		if($("select option:selected").val()=="Video")
		{	
			$("#Plugin_Alarme_Photo" ).slideToggle( "slow", function() {	
			});
			$("#Plugin_Alarme_Video" ).slideToggle( "slow", function() {
			});
		}
	});
});


function plugin_alarme_test_Capture()
{
	if($("select option:selected").val()=="Photo")
	{	
		if ($('#Plugin_Alarme_Resolution_H').val()=="")
		{
			alert ('Le champ Résolution Hauteur est vide');
			return false;
		}
		
		if ($('#Plugin_Alarme_Resolution_L').val()=="")
		{
			alert ('Le champ Résolution Largeur est vide');
			return false;
		}
		$('#submitAlarme_Camera_Test').text("Capture en cour...");
		plugin_alarme_chargement("xhrAlarme");
		$('#xhrAlarme').load('action.php',{
			action:'plugin_alarme_test_Camera',
			type:'Photo',
			Plugin_Alarme_Resolution_H:$('#Plugin_Alarme_Resolution_H').val(),
			Plugin_Alarme_Resolution_V:$('#Plugin_Alarme_Resolution_V').val(),
			Plugin_Alarme_CameraOption:$('#Plugin_Alarme_CameraOption').val(),
			Plugin_Alarme_CameraCopyDirectory:$('#Plugin_Alarme_CameraCopyDirectory').val()
			}, function() {
				$('#submitAlarme_Camera_Test').text("Capture terminée!")
				setTimeout(
				function()
				{
				  $('#submitAlarme_Camera_Test').text("Tester la capture");
				}, 3000)
			}
		);
	};
	if($("select option:selected").val()=="Video")
	{
		if ($('#Plugin_Alarme_Resolution_vid_H').val()=="")
		{
			alert ('Le champ Résolution Hauteur est vide');
			return false;
		}
		
		if ($('#Plugin_Alarme_Resolution_vid_L').val()=="")
		{
			alert ('Le champ Résolution Largeur est vide');
			return false;
		}
		
		if ($('#Plugin_Alarme_TimeToCapture').val()=="")
		{
			alert ('Le champ Temps de capture est vide');
			return false;
		}
		
		$('#submitAlarme_Camera_Test').text("Capture en cour...");
		plugin_alarme_chargement("xhrAlarme");
		$('#xhrAlarme').load('action.php',{
			action:'plugin_alarme_test_Camera',
			type:'Video',
			Plugin_Alarme_Resolution_H:$('#Plugin_Alarme_Resolution_vid_H').val(),
			Plugin_Alarme_Resolution_V:$('#Plugin_Alarme_Resolution_vid_V').val(),
			Plugin_Alarme_TimeToCapture:$('#Plugin_Alarme_TimeToCapture').val(),
			Plugin_Alarme_CameraOption:$('#Plugin_Alarme_CameraOption_vid').val(),
			Plugin_Alarme_CameraCopyDirectory:$('#Plugin_Alarme_CameraCopyDirectory_vid').val()
			}, function() {
				$('#submitAlarme_Camera_Test').text("Capture terminée!")
				setTimeout(
				function()
				{
				  $('#submitAlarme_Camera_Test').text("Tester la capture");
				}, 3000)
				
		});
	}
}

$(function(){
	$('#submitAlarme_Camera_Test').click(function() {
		plugin_alarme_test_Capture();
	});
});

function plugin_alarme_add_alarme_camera(){
	if($("select option:selected").val()=="Photo")
	{	
		if ($('#Plugin_Alarme_Resolution_H').val()=="")
		{
			alert ('Le champ Résolution Hauteur est vide');
			return false;
		}
		
		if ($('#Plugin_Alarme_Resolution_L').val()=="")
		{
			alert ('Le champ Résolution Largeur est vide');
			return false;
		}
		$('#submitAlarme_Camera_Add').text("Sauvegarde en cour...");
		plugin_alarme_chargement("plugin_alarme_save_span");
		$('#plugin_alarme_save_span').load('action.php',{
			action:'plugin_alarme_add_Camera',
			type:'Photo',
			Plugin_Alarme_Resolution_H:$('#Plugin_Alarme_Resolution_H').val(),
			Plugin_Alarme_Resolution_V:$('#Plugin_Alarme_Resolution_V').val(),
			Plugin_Alarme_CameraOption:$('#Plugin_Alarme_CameraOption').val(),
			Plugin_Alarme_CameraCopyDirectory:$('#Plugin_Alarme_CameraCopyDirectory').val()
			}, function() {
				$('#submitAlarme_Camera_Add').text("Enregistrer");
				$('#plugin_alarme_save_span').fadeIn();
				$('#plugin_alarme_save_span').delay(5000);
				$('#plugin_alarme_save_span').fadeOut();
		});
	}
	if($("select option:selected").val()=="Video")
	{
		if ($('#Plugin_Alarme_Resolution_vid_H').val()=="")
		{
			alert ('Le champ Résolution Hauteur est vide');
			return false;
		}
		
		if ($('#Plugin_Alarme_Resolution_vid_L').val()=="")
		{
			alert ('Le champ Résolution Largeur est vide');
			return false;
		}
		
		if ($('#Plugin_Alarme_TimeToCapture').val()=="")
		{
			alert ('Le champ Temps de capture est vide');
			return false;
		}
		$('#submitAlarme_Camera_Add').text("Sauvegarde en cour...");
		plugin_alarme_chargement("plugin_alarme_save_span");
		$('#plugin_alarme_save_span').load('action.php',{
			action:'plugin_alarme_add_Camera',
			type:'Video',
			Plugin_Alarme_Resolution_H:$('#Plugin_Alarme_Resolution_vid_H').val(),
			Plugin_Alarme_Resolution_V:$('#Plugin_Alarme_Resolution_vid_V').val(),
			Plugin_Alarme_TimeToCapture:$('#Plugin_Alarme_TimeToCapture').val(),
			Plugin_Alarme_CameraOption:$('#Plugin_Alarme_CameraOption_vid').val(),
			Plugin_Alarme_CameraCopyDirectory:$('#Plugin_Alarme_CameraCopyDirectory_vid').val()
			}, function() {
				$('#submitAlarme_Camera_Add').text("Enregistrer");
				$('#plugin_alarme_save_span').fadeIn();
				$('#plugin_alarme_save_span').delay(5000);
				$('#plugin_alarme_save_span').fadeOut();
		});
	}
}

$(function(){
	$('#submitAlarme_Camera_Add').click(function() {
		plugin_alarme_add_alarme_camera();
	});
});

function plugin_alarme_delete_alarme_camera(name){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_camera',
	name:name
		}, function() {
	});
};

function plugin_alarme_add_alarme_cameraIP(){
	
		if ($('#Plugin_Alarme_DriveDirectory').val()=="")
		{
			alert ('Le champ Drive est vide');
			return false;
		}
		
		if ($('#Plugin_Alarme_RepoDirectory').val()=="")
		{
			alert ('Le champ Répèrtoire source est vide');
			return false;
		}
		$('#submitAlarme_Camera_Add').text("Sauvegarde en cour...");
		plugin_alarme_chargement("plugin_alarme_save_span");
		$('#plugin_alarme_save_span').load('action.php',{
			action:'plugin_alarme_add_CameraIP',
			Plugin_Alarme_DriveDirectory:$('#Plugin_Alarme_DriveDirectory').val(),
			Plugin_Alarme_RepoDirectory:$('#Plugin_Alarme_RepoDirectory').val(),
			Plugin_Alarme_StoreDirectory:$('#Plugin_Alarme_StoreDirectory').val(),
			Plugin_Alarme_SendEmail:$('#Plugin_Alarme_SendEmail').val(),
			Plugin_Alarme_SendSms:$('#Plugin_Alarme_SendSms').val(),
			
			}, function() {
				$('#submitAlarme_Camera_Add').text("Enregistrer");
				$('#plugin_alarme_save_span').fadeIn();
				$('#plugin_alarme_save_span').delay(5000);
				$('#plugin_alarme_save_span').fadeOut();
		});

	
}

$(function(){
	$('#submitAlarme_CameraIP_Add').click(function() {
		plugin_alarme_add_alarme_cameraIP();
	});
});


//Onglet Action URL
function plugin_alarme_test_URL()
{
	if ($('#Plugin_Alarme_ActionURL').val()=="")
	{
		alert ('Le champ URL est vide');
		return false;
	}
	plugin_alarme_chargement("plugin_alarme_test_span");
	$('#plugin_alarme_test_span').load('action.php',{
		action:'plugin_alarme_test_URL',
		actionUrl:encodeURIComponent($('#Plugin_Alarme_ActionURL').val())
		}, function() {
		$('#plugin_alarme_test_span').fadeIn();
		$('#plugin_alarme_test_span').delay(5000);
		$('#plugin_alarme_test_span').fadeOut();
	});
}

$(function(){
	$('#submitAlarme_test_URL').click(function() {
		plugin_alarme_test_URL();
	});
});

function plugin_alarme_test_actionsUrl_ponctuel(id)
{
	$("#plugin_alarme_test_actionsUrl"+id).toggleClass('fa fa-refresh').toggleClass('fa fa-spinner fa-spin');
	$('#plugin_alarme_test_spanId'+id).load('action.php',{
		action:'plugin_alarme_test_URL',
		id:id
		}, function() {
		$("#plugin_alarme_test_actionsUrl"+id).toggleClass('fa fa-spinner fa-spin').toggleClass('fa fa-refresh');
		$('#plugin_alarme_test_spanId'+id).fadeIn();
		$('#plugin_alarme_test_spanId'+id).delay(5000);
		$('#plugin_alarme_test_spanId'+id).fadeOut();
	});
}

function plugin_alarme_addURL()
{
if ($('#Plugin_Alarme_ActionURL').val()=="")
	{
		alert ('Le champ URL est vide');
		return false;
	}
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_URL',
		type:$('#Plugin_Alarme_TypeURL').val(),
		actionUrl:$('#Plugin_Alarme_ActionURL').val()
		}, function() {
		$('#Plugin_Alarme_ActionURL').val('');
	});
};

$(function(){
	$('#submitAlarme_AddActions_URL').click(function() {
		plugin_alarme_addURL();
	});
});

function plugin_alarme_delete_Url(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_Url',
	id:id
	});
};

//Onglet Action Shell
function plugin_alarme_test_Shell()
{
	if ($('#Plugin_Alarme_ActionShell').val()=="")
	{
		alert ('Le champ Commande Shell est vide');
		return false;
	}
	plugin_alarme_chargement("plugin_alarme_test_span");
	$('#plugin_alarme_test_span').load('action.php',{
		action:'plugin_alarme_test_Shell',
		actionShell:encodeURIComponent($('#Plugin_Alarme_ActionShell').val())
		}, function() {
		$('#plugin_alarme_test_span').fadeIn();
		$('#plugin_alarme_test_span').delay(5000);
		$('#plugin_alarme_test_span').fadeOut();
	});
}

$(function(){
	$('#submitAlarme_test_Shell').click(function() {
		plugin_alarme_test_Shell();
	});
});

function plugin_alarme_test_actionsShell_ponctuel(id)
{
	$("#plugin_alarme_test_actionsShell"+id).toggleClass('fa fa-refresh').toggleClass('fa fa-spinner fa-spin');
	$('#plugin_alarme_test_spanId'+id).load('action.php',{
		action:'plugin_alarme_test_Shell',
		id:id
		}, function() {
		$("#plugin_alarme_test_actionsShell"+id).toggleClass('fa fa-spinner fa-spin').toggleClass('fa fa-refresh');
		$('#plugin_alarme_test_spanId'+id).fadeIn();
		$('#plugin_alarme_test_spanId'+id).delay(5000);
		$('#plugin_alarme_test_spanId'+id).fadeOut();
	});
}

function plugin_alarme_addShell()
{
if ($('#Plugin_Alarme_ActionShell').val()=="")
	{
		alert ('Le champ Commande Shell est vide');
		return false;
	}
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_Shell',
		actionShell:$('#Plugin_Alarme_ActionShell').val()
		}, function() {
		$('#Plugin_Alarme_ActionShell').val('');
	});
};

$(function(){
	$('#submitAlarme_AddActions_Shell').click(function() {
		plugin_alarme_addShell();
	});
});

function plugin_alarme_delete_Shell(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_Shell',
	id:id
	});
};

//Onglet Widget
function plugin_alarme_updateRefreshPhoto(obj)
{
	var button = $(obj);
	var input = button.prev("input");
	var icon = button.find("i");
	
	$.post( "action.php",
	{ 
	  action: "plugin_alarme_updateRefresh",
	  champs: input.attr("id"),
	  value: input.val()
	},
		function() {
			icon.addClass('active');
			setTimeout(
				function()
				{
				  icon.removeClass('active');
				}, 3000
			);
		}
    );
};


$(function(){
	$('#submitAlarme_AddRelay').click(function() {
		plugin_HomeCheckRelay_save();
	});
});


function plugin_HomeCheckRelay_save()
{
	
	if ($('#descriptionGenericRelay').val()=="")
	{
		alert ('Le champ description est vide');
		return false;
	}
	if ($('#macGenericRelay').val()=="")
	{
		alert ('Le champ adresse MAC est vide');
		return false;
	}
	
	isSwitch=$('#isSwitch').val();

	plugin_alarme_chargement("xhrAlarme");
	
	$('#xhrAlarme').load('action.php',{
		action:'HomeCheck_save_Relay',
		id:$('#id').val(),
		descriptionGenericRelay:$('#descriptionGenericRelay').val(),
		ipGenericRelay:$('#ipGenericRelay').val(),
		macGenericRelay:$('#macGenericRelay').val(),
		isSwitch:isSwitch,
		idGenericRelay:$('#idGenericRelay').val(),
		onGenericRelay:$('#onGenericRelay').val(),
		offGenericRelay:$('#offGenericRelay').val(),
		stopGenericRelay:$('#stopGenericRelay').val(),
		st1:$('#st1').val(),
		st2:$('#st2').val(),
		st3:$('#st3').val(),
		st4:$('#st4').val(),
		st5:$('#st5').val(),
		st6:$('#st6').val(),
		}, function() {
		$('#descriptionGenericRadio').val();
		$('#ipGenericRelay').val();
		$('#macGenericRelay').val();
		$('#isSwitch').val();
		$('#idGenericRelay').val();
		$('#onGenericRelay').val();
		$('#offGenericRelay').val();
		$('#stopGenericRelay').val();
		$('#st1').val();
		$('#st2').val();
		$('#st3').val();
		$('#st4').val();
		$('#st5').val();
		$('#st6').val();
	});
};

$(function(){
	$('#submitAlarme_AddRadio').click(function() {
		plugin_HomeCheckRadio_save();
	});
});


function plugin_HomeCheckRadio_save()
{
	
	if ($('#descriptionGenericRadio').val()=="")
	{
		alert ('Le champ description est vide');
		return false;
	}
	
	if ($('#radioCodeGenericIsAlarm').val()=="Yes") {
		isalarm=1;
	} else {
		isalarm=0;
	}
	
	if ($('#sensorTxTyp').val()=="Presence") {
		sensorTxTyp=1;
	} else if ($('#sensorTxTyp').val()=="Ouverture") {
		sensorTxTyp=2;
	} else if ($('#sensorTxTyp').val()=="Interrupteur") {
		sensorTxTyp=3;
	} else {
		sensorTxTyp=0;
	}
	
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'HomeCheck_save_Radio',
		id:$('#id').val(),
		descriptionGenericRadio:$('#descriptionGenericRadio').val(),
		radioCodeGenericRadioOn:$('#radioCodeGenericRadioOn').val(),
		radioCodeGenericRadioOff:$('#radioCodeGenericRadioOff').val(),
		radioCodeGenericIsAlarm:isalarm,
		sensorTxTyp:sensorTxTyp,
		onGenericRadio:$('#onGenericRadio').val(),
		offGenericRadio:$('#offGenericRadio').val(),
		SensorType:$('#SensorType').val(),
		radiolink:$('#relaiaction').val(),
		DelaySensor:$('#DelaySensor').val(),
		LumiSensor:$('#LumiSensor').val(),
		}, function() {
		$('#descriptionGenericRadio').val();
		$('#radioCodeGenericRadioOn').val();
		$('#radioCodeGenericRadioOff').val();
		$('#radioCodeGenericIsAlarm').val();
		$('#sensorTxTyp').val();
		$('#onGenericRadio').val();
		$('#offGenericRadio').val();
		$('#SensorType').val();
		$('#relaiaction').val();
		$('#DelaySensor').val();
		$('#LumiSensor').val();
	});
};

function plugin_alarm_testcode(detectbtn,text_field,type) {
	
	if ($("#"+text_field).val()=="")
	{
		alert ('Le code est vide...');
		return false;
	}
	
	code=$("#"+text_field).val();
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_testcode',
		code:code,
		type:type
		}, function() {
		code:code;
		type:type;
	});
	//location.reload();
}


function plugin_alarm_detectcode(detectbtn,text_field,type){
	$(detectbtn).attr("disabled",true);
	$(detectbtn).addClass("btn-warning");
	
	if(type == "SensorRXRADIO"){
		url = "action.php?action=HomeCheck_ReceiverTestDetect";
	}
	if(type == "SensorTXRADIO"){
		url = "action.php?action=HomeCheck_ReceiverTestDetect";
	}
	alert('Attention, la reception standard est arrêtée durant 20s');
	plugin_alarme_chargement("xhrAlarme");
	$.ajax({
		url: url
	}).done(function(answer) {
		answer = answer.trim();
		switch(answer){
			case "Check Permissions":
			alert("Impossible de récupérer un code radio \n Vérifier les permissions, dans Préférences -> Relai RCSwitch");
			$(detectbtn).addClass("btn-danger");
			$(detectbtn).removeClass("btn-warning");
			break;

			case "Wrong GPIO":
			alert("Impossible de trouver un récepteur radio sur la pin défini, changer de pin dans Préférences -> Relai RCSwitch");
			$(detectbtn).addClass("btn-danger");
			$(detectbtn).removeClass("btn-warning");
			break;

			default:
			$("#"+text_field).val(answer);
			$(detectbtn).attr("disabled",false);
			$(detectbtn).removeClass("btn-warning");
			alert("done");
			break;
		}
		console.log(answer);
	});
	
}

function plugin_sync_ip(text_field) {
	
	var delayInMilliseconds = 3000; // 
	
	if(!confirm('Êtes vous sûr de vouloir tout synchroniser?')) return;
	plugin_alarme_chargement("xhrAlarme");
	url = "action.php?action=HomeCheck_SyncAndGetip";
	$.ajax({
		url: url,
		type : 'GET',
		}).done(function(answer) {
			setTimeout(function() {
			  location.reload();
			}, delayInMilliseconds);
			alert("Ok, Synchonisation effectuée");
			
	});	
}

function plugin_sync_relay(text_field) {
	
	plugin_alarme_chargement("xhrAlarme");
		
		url = "action.php?action=HomeCheck_UpdRays";
		$.ajax({
		url: url,
		type : 'GET',
		}).done(function(answer) {
			//location.reload();
			alert("Ok");
	});	
}

function plugin_sync_gsm(text_field) {
	
	plugin_alarme_chargement("xhrAlarme");
		
	url = "action.php?action=HomeCheck_UpdGsm";
	$.ajax({
	url: url,
	type : 'GET',
	}).done(function(answer) {
			//location.reload();
			alert("Check Signal N to Log +CSQ N,99");
	});
}

function plugin_sync_Yee(text_field) {
	
	id=$('#id').val();
	if (id=="") {
		alert("Attention, Enregistrer d'abord le relai avant la synchronisation, puis editer le");
		return false;
	}
	try {	
		color=$('#st1').val();
		//color=color.substring(1)
		intensity=$('#st2').val();
		
		plugin_alarme_chargement("xhrAlarme");
			
		url = "action.php?action=HomeCheck_Sync_Yee";
		$.ajax({
		url: url,
		type : 'GET',
		data : "id=" + id + "&color=" + color + "&intens=" + intensity,
		}).done(function(answer) {
			//location.reload();
			answer = answer.trim();
			//$("#"+text_field).val(answer);
			console.log(answer);
				
		});
	} catch(e) {
		alert(e);	
  }
}

function plugin_gethashcode(text_field,code){
	
	
	if ($('#id').val()=="") {
		alert("Attention, Enregistrer d'abord le relai avant la synchronisation, puis editer le");
		return false;
	}
	try {	
		var secret=code;
		
		// check if the secret has the correct length
		if(secret.length != 10) {
			alert("Secret must be 10 characters");
			return;
		}
		
		// create HEX array
		var char_array = secret.split('');
		var charcode_array = char_array.map(function (c) { return c.charCodeAt(0); });
		var hex_array=""; // '{';
		for(i = 0; i < charcode_array.length; i++) {
			//if(i > 0) hex_array += ', ';
			hex_array += '0x' + charcode_array[i].toString(16);
		}
		//hex_array += '}';
		
		plugin_alarme_chargement("xhrAlarme");
		
		url = "action.php?action=HomeCheck_Sync_Relay";
		$.ajax({
		url: url,
		type : 'GET',
		data : "id=" + $('#id').val() + "&pass=" + secret,
		}).done(function(answer) {
			//location.reload();
			answer = answer.trim();
			$("#"+text_field).val(answer);
			console.log(answer);
			
	});
	
	} catch(e) {
		alert(e);	
  }
  
}

function plugin_TimeOut(engine,delay) {
	
	var x=setTimeout(function() {
		$('#xhrAlarme').load('action.php',{
		action:'HomeCheckRadio_manual_change_state',
		engine:engine,
		state:0
		}, function() {
		code:code;
		type:type;
		});
	},delay);
	
	return x;
}

//Ajout / Modification IPCAM
function Homecheck_ipcam_save(element){
	var form = $(element).closest('fieldset');
 	var data = form.toData();
 	data.action = 'HomeCheck_ipcam_save_camera'
	$.action(data,
		function(response){
			alert(response.message);
			form.find('input').val('');
			location.reload();
		}
	);
}

//Supression
function plugin_ipcam_delete(id,element){

	if(!confirm('Êtes vous sûr de vouloir faire ça ?')) return;
	$.action(
		{
			action : 'HomeCheck_ipcam_delete_camera', 
			id: id
		},
		function(response){
			$(element).closest('tr').fadeOut();
		}
	);

}

function plugin_Alarme_ipcam_brand(element){
    var selected_index = element.selectedIndex;
    //alert(element.options[selected_index].value);
	$('#patternCamera').val(element.options[selected_index].value);
}

//Import

function plugin_HomeCheck_backupAll(element) {
	
	url = "action.php?action=plugin_HomeCheck_backup_all";
	$.ajax({
		url: url,
		type : 'GET',
		}).done(function(answer) {
			//alert("Ok");
	});

}


function plugin_HomeCheck_restoreAll(element){
	
	if(!confirm('Êtes vous sûr de vouloir faire ça ?')) return;
	url = "action.php?action=plugin_HomeCheck_restore_all";
	$.ajax({
		url: url,
		type : 'GET',
		}).done(function(answer) {
			alert("Ok");
	});
	
}

function plugin_HomeCheck_import(element){
	var form = $('.import');
 	var data = form.toData();
	
	data.action = 'HomeCheck_import_HomeCheck';
	$.action(data,
		function(response){
			alert(response.message);
			form.find('input').val('');
			location.reload();
		}
	);
}

function plugin_HomeCheck_radio_import(element){
	var form = $('.import');
 	var data = form.toData();
	
	data.action = 'plugin_HomeCheck_radio_import';
	$.action(data,
		function(response){
			alert(response.message);
			form.find('input').val('');
			location.reload();
		}
	);
}


function plugin_HomeCheck_relay_import(element){
	var form = $('.import');
 	var data = form.toData();
	
	data.action = 'plugin_HomeCheck_relay_import';
	$.action(data,
		function(response){
			alert(response.message);
			form.find('input').val('');
			location.reload();
		}
	);
}

