#!/usr/bin/python
# -*-coding:Utf-8 -*

from libWpa_cli_mod import *

if __name__ == "__main__":
	wpa_cli_mod()