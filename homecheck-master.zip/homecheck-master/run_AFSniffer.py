#!/usr/bin/python
# -*-coding:Utf-8 -*

import time
import os
import tempfile
import urllib
import urllib2
import datetime
import sys

if len(sys.argv)>1:
	
	val=sys.argv[1]
	file = open("test.txt", "a")
	file.write(val+"\n") 
	file.close()  
	action="HomeCheck_ReceiverDetect"
	command = "http://127.0.0.1:8080/action.php?action="+action+"&code="+val
	try:
		json_commands = urllib2.urlopen(command)
	#Handle invalid IP
	except IOError, e:
		print("Invalid IP")

