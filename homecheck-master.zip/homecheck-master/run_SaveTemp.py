#!/usr/bin/python
# -*-coding:Utf-8 -*

import ConfigParser
import urllib2
import json
import os
import sys
import time 
import optparse
import shutil

parser = optparse.OptionParser("ExecCmd.py [options] cmdline")
parser.add_option("-t", "--temp", type="string", dest="temp",default="0")
parser.add_option("-f", "--feel", type="string", dest="tfeel",default="0")
parser.add_option("-d", "--humi", type="string", dest="humi",default="0")
parser.add_option("-m", "--moment", type="string", dest="moment",default="0")
parser.add_option("-c", "--code", type="string", dest="code",default="0")
    
(options, args) = parser.parse_args()


cmdline = args[0]

if options.temp:
		temp = options.temp
else:
	temp=0

if options.tfeel:
	tfeel = options.tfeel
else:
	tfeel=0

if options.humi:
	humidity=options.humi

if options.moment:
	updhisd=int(options.moment)
	
if options.code:
	acode=options.code
		
if cmdline<>'0':
	ip=cmdline
	
	command = "http://"+ip+"/{{"+acode+"}}"
	try:
		json_commands = urllib2.urlopen(command)
	except IOError, e:
		print("Invalid")
else:
		
	afilename='history_h.txt'
	while afilename!='':
		fname=os.path.dirname(os.path.realpath(__file__))+os.sep+afilename
		if os.path.isfile(fname):
			f=open(os.path.dirname(os.path.realpath(__file__))+os.sep+afilename,'r')
			datas = f.readlines()
			f.close()
		else:
			data=[[0,0,0],[0,0,0],[0,0,0]]
		f=open(os.path.dirname(os.path.realpath(__file__))+os.sep+afilename,'w')
		i=0
		for data in datas:
			i+=1
			lines=data.split()
			if i==1:
				lines.append(temp)
			elif i==2:
				lines.append(tfeel)
			else:
				lines.append(humidity)
			if afilename<>'history_all.txt':
				lines.pop(0)
			for line in lines:
				f.write(line+' ')
			f.write('\n')
		f.close()
		if updhisd==1:
			afilename='history_d.txt'
			updhisd=0
		else:
			if afilename<>'history_all.txt':
				afilename='history_all.txt'
			else:
				afilename=''


