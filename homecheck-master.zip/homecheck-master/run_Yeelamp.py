#!/usr/bin/python
# -*-coding:Utf-8 -*
from libYeelamp import *

if __name__ == '__main__':	
	yeelamp()