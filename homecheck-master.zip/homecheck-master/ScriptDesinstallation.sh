#!/bin/sh
sudo pkill AlarmeDetector
