<?php

function plugin_alarme_onglet($onglet,$sousOnglet)
{
	if(isset($onglet))
	{
		?>
		<div class="span9 userBloc">
			<span class="span9 plugin_swv_titre">
				<h1>Configuration</h1>
				<p>DomoCom, lier des detecteurs et des actions résultantes</p>
				
			</span>
		</div>
		<div class="span9 userBloc">
			<ul class="nav nav-tabs nav-justified">
				<li <?php if($onglet=="ADAlarme"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=ADAlarme&sousblock=AlarmeGeneral">Configuration </a></li>
				<li <?php if($onglet=="Sensor"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Sensor&sousblock=SensorRXRADIO">Déclencheurs/détecteurs</a></li>	
				<li <?php if($onglet=="Actions"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Actions&sousblock=ActionsGroup">Actions</a></li>
				<li <?php if($onglet=="Donnees"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Donnees&sousblock=ReleveTemp">Données</a></li>
				<li <?php if($onglet=="SnapShot"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=SnapShot&sousblock=SnapShot">SnapShot</a></li>
				
			</ul>
			<?php
			if($onglet=="ADAlarme")
			{
				?>
				<ul class="nav nav-pills nav-justified">
				<li <?php if($sousOnglet=="AlarmeGeneral"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=ADAlarme&sousblock=AlarmeGeneral">Etat global</a></li>
				<li <?php if($sousOnglet=="GestionMembres"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=ADAlarme&sousblock=GestionMembres">Membres</a></li>
				<li <?php if($sousOnglet=="AlarmeGPIO"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=ADAlarme&sousblock=AlarmeGPIO">GPIO</a></li>
				<li <?php if($sousOnglet=="AlarmeURL"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=ADAlarme&sousblock=AlarmeURL">URL</a></li>
				<li <?php if($sousOnglet=="BackupCamIP"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=ADAlarme&sousblock=BackupCamIP">Backup Camera IP </a></li>
				<li <?php if($sousOnglet=="CameraIP"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=ADAlarme&sousblock=CameraIP">Camera IP</a></li>
				<li <?php if($sousOnglet=="ConfigWifi"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=ADAlarme&sousblock=ConfigWifi">Config Wifi</a></li>
				<li <?php if($sousOnglet=="Backup"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=ADAlarme&sousblock=Backup">Sauvegarde</a></li>
				<li <?php if($sousOnglet=="Update"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=ADAlarme&sousblock=Update">Update</a></li>
				</ul>
				<?php
			}
			if($onglet=="Sensor")
			{
				?>
				<ul class="nav nav-pills nav-justified">
				<li <?php if($sousOnglet=="SensorRXRADIO"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Sensor&sousblock=SensorRXRADIO">DECLENCHEUR RADIO</a></li>
				<li <?php if($sousOnglet=="SensorTXRADIO"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Sensor&sousblock=SensorTXRADIO">DETECTEUR RADIO</a></li>
				<li <?php if($sousOnglet=="SensorRELAY"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Sensor&sousblock=SensorRELAY">RELAIS WIFI</a></li>
				<li <?php if($sousOnglet=="SensorGPIO"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Sensor&sousblock=SensorGPIO">GPIO</a></li>
				<li <?php if($sousOnglet=="SensorURL"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Sensor&sousblock=SensorURL">URL</a></li>
				
				</ul>
				<?php
			}
			if($onglet=="Actions")
			{
				?>
				<ul class="nav nav-pills nav-justified">
				<li <?php if($sousOnglet=="ActionsGroup"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Actions&sousblock=ActionsGroup">Actions Groupées</a></li>
				<li <?php if($sousOnglet=="ActionsProg"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Actions&sousblock=ActionsProg">Actions Programmées</a></li>
				<li <?php if($sousOnglet=="ActionsLumi"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Actions&sousblock=ActionsLumi">Actions Conditionnelles</a></li>
				<li <?php if($sousOnglet=="ActionsEmail"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Actions&sousblock=ActionsEmail">Email</a></li>
				<li <?php if($sousOnglet=="ActionsCameraIP"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Actions&sousblock=ActionCameraIP">Alerte Camera IP</a></li>
				<li <?php if($sousOnglet=="ActionsURL"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Actions&sousblock=ActionsURL">URL</a></li>
				<li <?php if($sousOnglet=="ActionsGPIO"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Actions&sousblock=ActionsGPIO">GPIO</a></li>
				<li <?php if($sousOnglet=="ActionsShell"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Actions&sousblock=ActionsShell">Shell</a></li>

				</ul>
				<?php
			}
			if($onglet=="Donnees")
			{
				?>
				<ul class="nav nav-pills nav-justified">
				<li <?php if($sousOnglet=="ReleveTemp"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Donnees&sousblock=ReleveTemp">Température</a></li>
				</ul>
				
				<?php
			}
			if($onglet=="SnapShot")
			{
				?>
				<ul class="nav nav-pills nav-justified">
				<li <?php if($sousOnglet=="SnapShot"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=SnapShot&sousblock=SnapShot">SnapShot</a></li>
				</ul>
				
				<?php
			}
			
			if($onglet=="Widget")
			{
				?>
				<ul class="nav nav-pills nav-justified">
				<li <?php if($sousOnglet=="WidgetGeneral"){echo 'class="active"';} ?>><a href="index.php?module=Home_Check&block=Widget&sousblock=WidgetGeneral">Général</a></li>
				</ul>
				<?php
			}
			?>
		</div>
		<?php
	}
}

//Page Configuration
function plugin_alarme_setting_page() {
	global $myUser,$_,$conf;
	
	//si une page envoie une erreur, affichage de celle-ci
	if(isset($_['module']) && $_['module']=='Home_Check'){
		echo $_['error'];
	}
	//Page Alarme
	if(isset($_['module']) && $_['module']=='Home_Check' && $_['block'] =='ADAlarme' && $_['sousblock'] =='AlarmeGeneral') {
		
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","AlarmeGeneral");
			
			$people=HomeCheck_whois(0);
			
			$alarme_conf = new AlarmeConf("r");
			$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_timetoStart"));
			$delai=	$alarme_conf->getValue();
			
			$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));
			$alarmeActive=$alarme_conf->getValue();
			Switch ($alarmeActive)
				{
				case "0":
					$retour ="Inactive";
					break;
				case "1":
					$retour = 'Surveillance Active';
					break;	
				case "2":
					$retour = 'Alarme enclenchée!';
					break;		
				default:
					$retour ='Etat inconnu';
					break;
				} 
			?>
				<div class="span9 userBloc">
					<div class="left">
						<br/>
						<form>
							<fieldset>
								<legend>Personnes présentes </legend>
								<label for="plugin_alarme_timetoStart">Home Check: <?php echo $people; ?></label>
								
								<legend>Temps d'activation de la surveillance/déclenchement de l'alarme (seconde) </legend>
								<label for="plugin_alarme_timetoStart">Paramétré depuis DomoCom: <?php echo $delai; ?></label> 
								
								<legend>Etat de l'alarme </legend>
								<label for="plugin_alarme_timetoStart">Etat des alarmes: <?php echo $retour; ?></label>
								
								
								<legend>Etat des Récepteurs </legend>
								<?php
								$alarme_Manager = new AlarmeSensorRadio("r");
								$alarmes = $alarme_Manager->loadAll(array('type'=>"SensorRXRADIO"));
								?>	
								
								<table class="table table-striped table-bordered table-hover">
								<thead>
									<tr>
										<th width=100>Description</th>
										<th width=100>Etat</th>
									</tr>
								</thead>

								<?php 
								foreach($alarmes as $alarme) {
								 ?>
									<tr>
										<td><?php echo $alarme->getDescription();?></td>
										
										<?php $etat=($alarme->state!=0) ? "Actif" : "Inactif";?>			
										<td width=100><?php echo $etat;?></td>
									</tr>
								<?php } ?>
								</table>
								
								<legend>Etat des Relais Wifi </legend>
								<?php
								$alarme_Manager = new AlarmeRelay("r");
								$alarmes = $alarme_Manager->populate();
								?>	
								
								<table class="table table-striped table-bordered table-hover">
								<thead>
									<tr>
										<th width=100>Description</th>
										<th width=100>Etat</th>
									</tr>
								</thead>

								<?php 
								foreach($alarmes as $alarme) {
									if ($alarme->isSwitch != 0) {
									$etat=GetRelayState($alarme->state);
									
								 ?>
									<tr>
										<td><?php echo $alarme->getDescription();?></td>
										
										<?php $etat;?>			
										<td width=100><?php echo $etat;?></td>
									</tr>
								<?php } } ?>
								</table>
               
							</fieldset>
						</form>
		
					</div>
				</div>
			<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' && $_['block'] =='ADAlarme' && $_['sousblock'] =='GestionMembres') {
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","GestionMembres");
			$HomeCheckManager = new Home_Check();
			//$HomeChecks = $HomeCheckManager->populate();
			$selected =  new Home_Check();
			/*
			$table = new Home_Check();
			$table->drop();
			
			$table1 = new Home_Check();
			$table1->create();
			*/
			//Si on est en mode modification
			if (isset($_['id'])) {
				$selected = $HomeCheckManager->getById($_['id']);
			} else {
				$selected->imei=uniqid();
			}
			?>
	 
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<a name="TopPage"></a>
					<h2><i class="fa fa-book"></i> Gestion des membres</h2>
					<button type="button" 
					onClick="location.href='index.php?module=Home_Check&block=ADAlarme&sousblock=GestionMembres#BottomPage'" class="btn">Ajouter Membre</button> 
					
					<legend  >Personnes enregistrées</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadPersonnes();
						?>
					</div>
					
					<a name="BottomPage"></a>
					
					<legend>Ajouter/Editer Membre</legend>

                    <div class="left">

					<label for="nameHomeCheck">Nom</label>
					<input type="hidden" id="id" value="<?php echo $selected->id; ?>">
					<input type="text" id="nameHomeCheck" value="<?php echo $selected->name; ?>" placeholder="Arthur..."/>
					
					<label for="descriptionHomeCheck">Description</label>
					<input type="text"  value="<?php echo $selected->description; ?>" id="descriptionHomeCheck" placeholder="Papa " />

					<label for="IMEIHomeCheck">IMEI associé</label>
					<input type="text" value="<?php echo $selected->imei; ?>" name="IMEIHomeCheck" id="IMEIHomeCheck" placeholder="identifie une personne..." />
					<label for="ISADMINHomeCheck">Est Admin</label>
					<!--<input type="number" value="<?php echo $selected->isadmin; ?>" name="ISADMINHomeCheck" id="ISADMINHomeCheck" placeholder="1 si admin,0 sinon" /> -->
					<select name="ISADMINHomeCheck" id="ISADMINHomeCheck">
								<option <?php if ($selected->isadmin == 1 ) echo 'selected'; ?> value="Yes">Yes</option>
								<option <?php if ($selected->isadmin == 0 ) echo 'selected'; ?> value="No">No</option>
								</select>
					
					<label for="PASSHomeCheck">Mot de passe (Numerique uniquement)</label>
					<input type="number" value="<?php echo $selected->password; ?>" name="PASSHomeCheck" id="PASSHomeCheck" placeholder="que des chiffres" />
					
					
					<label for="MobileHomeCheck">Numéro de portable format +330</label>
					<input type="text" value="<?php echo $selected->nummobile; ?>" name="MobileHomeCheck" id="MobileHomeCheck" placeholder="Pour envoie SMS" />
					
					<label for="EmailHomeCheck">Adresse email</label>
					<input type="text" value="<?php echo $selected->email; ?>" name="EmailHomeCheck" id="EmailHomeCheck" placeholder="Pour envoie email" />
					
					<label for="IsClientServHomeCheck">Client Fixe Console</label>
					<!--<input type="number" value="<?php echo $selected->isclientserv; ?>" name="IsClientServHomeCheck" id="IsClientServHomeCheck" placeholder="Client fixe pour relai sms" /> -->
					<select name="IsClientServHomeCheck" id="IsClientServHomeCheck">
								<option <?php if ($selected->isclientserv == 1 ) echo 'selected'; ?> value="Yes">Yes</option>
								<option <?php if ($selected->isclientserv == 0 ) echo 'selected'; ?> value="No">No</option>
								</select>
								
					<label for="Location"><b>Position MCC_MNC_LAC_CID:</b> <?php echo $selected->location; ?></label>
					
					<div class="input-append">
                                <span onclick="plugin_alarm_detectpos(this)" class="btn">Localiser</span>
								<span onclick="window.open('http://cellphonetrackers.org/gsm/gsm-tracker.php','_blank');" class="btn">Geolocaliser</span>
								<span onclick="window.open('http://maps.google.com/maps?q=Point@%LOC','_blank');" class="btn">Maps</span>
                    </div>
					
					<?php
					 $tempDir = sys_get_temp_dir();
					 $codeContents="Domo-Com;";
					 if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') {
						$codeContents.="https://";
					} else {
						$codeContents.="http://";
					}
					 $codeContents .=$_SERVER['HTTP_HOST'].";";
					 $codeContents .= $myUser->getToken().";"; 
					 $codeContents .=$selected->imei.";";
					 $codeContents .=$selected->isadmin.";";	
					 $codeContents .=$selected->password.";";
					 $codeContents .=$selected->nummobile.";";
					 $codeContents .=$selected->email.";";
					 //echo $codeContents;
					 // we need to generate filename somehow,  
					 // with md5 or with database ID used to obtains $codeContents... 
					 $fileName = 'qrres.png'; 
					  
					 $pngAbsoluteFilePath = dirname(__FILE__)+"/img/".$fileName; 
					 $urlRelativeFilePath = dirname(__FILE__)+"/img/".$fileName;
					 QRcode::png($codeContents, $pngAbsoluteFilePath); 
					 rename($pngAbsoluteFilePath,$urlRelativeFilePath);
					 echo '<img src="'.$urlRelativeFilePath.'" />'; 
					?>



					<!--<p><a href=http://cellphonetrackers.org/gsm/gsm-tracker.php target="_blank" >GeoLocaliser </a></p> -->
					
					<label for="IPLOCALE"><b>IP locale :</b> <?php echo $selected->ip; ?></label>
					<label for="ISATHomeCheck"><b>Présence locale : </b><?php echo $selected->state; ?></label>
					
                     <div class="clear"></div>
                     <br/>
					 <button type="button" id="plugin_AddHomeCheck" class="btn">Enregistrer</button> 
					 <br><br>
					
										
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='ADAlarme' && $_['sousblock'] =='AlarmeVocales')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","AlarmeVocales");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<h2><i class="fa fa-book"></i> Explications</h2>
					<p>Vous pouvez enregistrer une commande vocale d'activation et de désactivation de la surveillance </p>
					<p>Celles-ci sont facultatives</p>
					<p>Pour les commandes vocales de désactivation, il est préférable d'utiliser des phrases complexes comme un mot de passe.</p>
					<p>La commande vocales faisant partie des commandes vocales que Yana doit écouter, elle est visible dans l'inventaire des commandes vocales du Dashboard et sur les clients Yana</p>
						<legend>Cette commande permet d'activer l'alarme</legend>
						<label for="CommandeVocaleOn">Commande vocale d'activation de la surveillance  :</label>
						<?php echo $conf->get('VOCAL_ENTITY_NAME').' : '; ?><textarea rows="4" cols="50" name="CommandeVocaleOn" id ="CommandeVocaleOn" value="" placeholder="active l'alarme de la maison"/></textarea>
						<br>
						<button type="button" id="submitAlarme_AddCommandes_VocaleOn" class="btn">Enregistrer</button>
						<br><br>
						<legend>Factultatif : cette commande permet d'arréter de la surveillance </legend>
		
						<label for="CommandeVocaleOff">Factultatif : Commande vocale d'arrét de l'alarme :</label>
						<?php echo $conf->get('VOCAL_ENTITY_NAME').' : ';?><textarea rows="4" cols="50" name="CommandeVocaleOff" id ="CommandeVocaleOff" value="" placeholder="cette phrase pour désactiver l'alarme de la maison est impossible à trouver."/></textarea>
						<br><br>
						<button type="button" id="plugin_alarme_addCommande_VocaleOff" class="btn">Enregistrer</button>
					<br><br>
					<legend  >Commandes vocales enregistrées</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadCommandes_Vocales();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='ADAlarme' && $_['sousblock'] =='AlarmeGPIO')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","AlarmeGPIO");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<form>
						<fieldset>
							<legend>Vous pouvez paramétrer ici les GPIO qui pourront activer ou désactiver la surveillance en changeant d'état.</legend>
							<p><i class="fa fa-exclamation-triangle"></i> Il faut activer ou désactiver une fois la surveillance pour que les interrupts se mettent en place.</p>
							<p>Si le RPI redémarre, les interrupts ne sont plus exécutées, cependant, les URL fontionnent.</p>
							
							<input type="hidden" name="SensorType" id="SensorType" value="SensorADGPIO"/>
							<label for="descriptionADGPIO">Description du périphérique:</label>
							<input type="text" name="descriptionADGPIO" id ="descriptionADGPIO" value="" placeholder="Digicode, lecteur d'empreintes, RFID etc.."/>
							
							<label for="numADGPIO"> Numéro du GPIO (WiringPi) :</label>
							<input type="number" name="numADGPIO" id ="numADGPIO" value="" placeholder="1,2,3 etc.."/>
							<button type="button" id="submitAlarme_AddADSensor" class="btn">Enregistrer</button>
						</fieldset>
					</form>
					<legend>GPIO surveillé pour l'activation ou la désactivation de la surveillance </legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadADSensor();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='ADAlarme' && $_['sousblock'] =='AlarmeURL')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","AlarmeURL");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br>
					<legend>Vous pouvez activer ou désactiver la surveillance depuis un autre périphérique, en éxécutant une URL.</legend>
					<p>Pour des questions de sécurité, ces URL ne sont pas disponible directement, il faudra fournir le token :</p>
					URL d'activation de la surveillance  :
					<code>
						<?php
						echo 'http://'.$_SERVER['SERVER_ADDR'].'/yana-server/action.php?action=Plugin_Alarme_Start_Activation&token='.$myUser->getToken();
						?>
					</code>
					<br>
					URL de désactivation de la surveillance  :
					<code>
						<?php
						echo 'http://'.$_SERVER['SERVER_ADDR'].'/yana-server/action.php?action=Plugin_Alarme_Start_Desactivation&token='.$myUser->getToken();
						?>
					</code>
					<br>
					URL pour switcher, si la surveillance est activé, elle est arrétée, si elle est arrétée, ca l'active  :
					<code>
						<?php
						echo 'http://'.$_SERVER['SERVER_ADDR'].'/yana-server/action.php?action=Plugin_Alarme_Start_Switch&token='.$myUser->getToken();
						?>
					</code>
					<br><br>
					<p>Ces URL sont aussi accéssible sans token, si la requette vient de l'addresse IP Local 127.0.0.1.</p>
				</div>
			</div>
		<?php
		}
	} 
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='ADAlarme' && $_['sousblock'] =='BackupCamIP')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","BackupCamIP");
			
			$alarme_conf = new AlarmeConf("r");
			$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_DriveDirectory"));
			$DriveDirectory = $alarme_res->getValue();
			$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_RepoDirectory")); 
			$RepoDirectory = $alarme_res->getValue();
			$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_StoreDirectory"));
			$StoreDirectory = $alarme_res->getValue();
			$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_SendSms"));
			$issms = $alarme_res->getValue();
			$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_SendEmail"));
			$send_email = $alarme_res->getValue();
					
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<p>Les alertes sont déclenchées si l'alarme est active</p>
					<p>Si l'alarme n'est pas active, les fichiers sont supprimés</p>
					<p> L'activation de l'application sur votre compte google est nécessaire: <a href=https://script.google.com/macros/s/AKfycbzNK3BymU3O9bLi75ubBxg3OP-ORpZ7127ChWaLvJvugGV7Jr2r/exec target="_blank" >BackupCamIp_PI </a></p>
					<p>(Authentification google necessaire pour sauvegarder vos paramètres)</p>
					<p><?php if (!file_exists('/usr/bin/backupcamip')) { ?>
						<p> BackupCamIp non installé: <a href="https://github.com/backupcamip/backupcamip_pi.git" target="_blank" > Installation </a></p> 
					<?php } ?>
					<br/>
		
					<form>
						<fieldset>
							<legend>Paramètres BackupCamIp</legend>
							
								<input type="hidden" name="Plugin_Alarme_Drive" id ="Plugin_Alarme_Drive" value="getfromgoogle"/>
								
								<label for="Plugin_Alarme_RepoDirectory">Répèrtoire Source de stockage local des Images/Videos:</label>
								<input type="text" name="Plugin_Alarme_RepoDirectory" id ="Plugin_Alarme_RepoDirectory" value="<?php echo $RepoDirectory;?>" placeholder="/mnt/videos"/>
								
								<label for="Plugin_Alarme_StoreDirectory">Répèrtoire sauvegarde locale (facultatif) : </label>
								<input type="text" name="Plugin_Alarme_StoreDirectory" id ="Plugin_Alarme_StoreDirectory" value="<?php echo $StoreDirectory;?>" placeholder="/media/photo/"/>
								
								<label for="Plugin_Alarme_DriveDirectory">Répèrtoire Source de stockage Google Drive : </label>
								<input type="text" name="Plugin_Alarme_DriveDirectory" id ="Plugin_Alarme_DriveDirectory" value="<?php echo $DriveDirectory;?>" placeholder="/media/photo/"/>
									
								<label for="Plugin_Alarme_SendEmail">Envoie Email avec capture si detection: </label>
								<select name="Plugin_Alarme_SendEmail" id="Plugin_Alarme_SendEmail">
								<option <?php if ($send_email == "Yes" ) echo 'selected'; ?> value="Yes">Yes</option>
								<option <?php if ($send_email == "No" ) echo 'selected'; ?> value="No">No</option>
								</select>
								
								<label for="Plugin_Alarme_SendSms">Envoie SMS si alerte et active alarme: </label>
								<select name="Plugin_Alarme_SendSms" id="Plugin_Alarme_SendSms">
								<option <?php if ($issms == "Yes" ) echo 'selected'; ?> value="Yes">Yes</option>
								<option <?php if ($issms == "No" ) echo 'selected'; ?> value="No">No</option>
								</select>
								<br/>
								<br/>
							
							<button type="button" id="submitAlarme_CameraIP_Add" class="btn">Enregistrer</button>
							<span id="plugin_alarme_save_span"></span>
							<br/>
						</fieldset>	
						
					</form>
					
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='ADAlarme' && $_['sousblock'] =='CameraIP')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","CameraIP");
            
             /*
			$table1 = new IPCamera();
			$table1->drop();
			
			$table1 = new IPCamera();
			$table1->create();
			 */
             
			if(!$myUser) throw new Exception('Vous devez être connecté pour effectuer cette action');
			$cameraManager = new IPCamera();
			$cameras = $cameraManager->populate();
			$roomManager = new Room();
			$rooms = $roomManager->loadAll(array('state'=>'0'));
			$selected =  new IPCamera();
			$selected->pattern = 'http://{{login}}:{{password}}@{{ip}}/videostream.cgi';
			//Si on est en mode modification
			if (isset($_['id']))
				$selected = $cameraManager->getById($_['id']);
                echo $selected->brand;
				?>
				<div class="span9 userBloc">
                
				<h1>Camera</h1>
				<p>Gestion des cameras IP</p>  

				<fieldset>
					<legend>Ajouter/Modifier une camera</legend>

					<div class="left">

						<label for="labelCamera">Nom</label>
						<input type="hidden" id="id" value="<?php echo $selected->id; ?>">
						<input type="text" id="labelCamera" value="<?php echo $selected->label; ?>" placeholder="Sonde du salon"/>
				
						<label for="ipCamera">IP/Adresse du stream</label>
						<input type="text" value="<?php echo $selected->ip; ?>" id="ipCamera" placeholder="ex : 192.168.11.27:87" />
						
						<label for="loginCamera">Login</label>
						<input type="text" value="<?php echo $selected->login; ?>" id="loginCamera" placeholder="" />
						
						<label for="passwordCamera">Password</label>
						<input type="text" value="<?php echo $selected->password; ?>" id="passwordCamera" placeholder="" />
						
						<label>Marque de camera</label>
						<select onchange="plugin_Alarme_ipcam_brand(this)" id="brandCamera">
						<?php foreach(IPCamera::brands() as $brand=>$pattern): ?>
							<option <?php if ($selected->pattern == $pattern){echo "selected";} ?> value="<?php echo $pattern; ?>"><?php echo $brand; ?> </option>
						<?php endforeach;?>
						</select>


						<label for="patternCamera">Adresse de visualisation</label>
						<small>Adresse complète vers le streaming de votre camera, les balises entre {{}} seront remplacée par les valeurs des champs ci dessus.</small>

						<input type="text" class="input-xxlarge" value="<?php echo $selected->pattern; ?>" id="patternCamera" placeholder="http://{{login}}:{{password}}@{{ip}}/videostream.cgi" />
						
						<label for="locationCamera">Pièce de la maison</label>
						<select id="locationCamera">
							<?php foreach($rooms as $room){ ?>
							<option <?php if ($selected->location == $room->getId()){echo "selected";} ?> value="<?php echo $room->getId(); ?>"><?php echo $room->getName(); ?></option>
							<?php } ?>
						</select>
					   
					</div>
					<div class="clear"></div>
					<br/><button onclick="Homecheck_ipcam_save(this)" class="btn">Enregistrer</button>
				</fieldset>
				<br/>
				<legend>Camera</legend>
					
					<div id="xhrAlarme">
						<?php
						echo load_alarme_CameraIP();
						?>
					</div>
			</div>
			<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='ADAlarme' && $_['sousblock'] =='ConfigWifi')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","ConfigWifi");
            
			if(!$myUser) throw new Exception('Vous devez être connecté pour effectuer cette action');
			
			$roomManager = new Room();
			$rooms = $roomManager->loadAll(array('state'=>'0'));
			
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<p>Renseigner les informations du réseau wifi</p>
					<p>Ces informations ne sont pas sauvergardées, elles sont utilisées pour configurer le systeme.</p>
					<form>						
						<fieldset>
							<legend>Paramètres WIFI</legend>
							<input type="hidden" name="wifiTypeName" id="wifiTypeId" value="wifi"/>
							<span id="plugin_alarme_test_span" style="display:none;"></span>
							
							<button type="button" 
							onClick="plugin_alarme_test_wifi(1)" class="btn">Liste réseaux</button> 
							<span id="plugin_alarme_test_span" style="display:none;"></span>
							
							<button type="button" 
							onClick="plugin_alarme_test_wifi(2)" class="btn">Etat réseau</button> 
							<span id="plugin_alarme_test_span" style="display:none;"></span>
							
							<button type="button" 
							onClick="plugin_alarme_test_wifi(3)" class="btn">Ajouter Réseau</button> 
							<span id="plugin_alarme_test_span" style="display:none;"></span>
							
							<br/><br/>
							
							<label for="wifiUserId">SSID réseau:</label>
							<input type="text" name="wifiUserId" id ="wifiUserId" value=""/>
							
							<label for="wifiPass">Mot de passe:</label>
							<input type="text" name="wifiPass" id ="wifiPass" value=""/>
							
							<label for="wifiPass">Resultat</label>
							<span id="plugin_alarme_test_span3" style="display:none;"></span>
							<div id="xhrAlarme">
								
							</div>
							
						</fieldset>	
					</form>	
					
				</div>
			</div>
		<?php		
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='ADAlarme' && $_['sousblock'] =='Backup')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","Backup");
			//goto a;
			$afile = fopen(dirname(__FILE__).'//HomeCheck_Backup.txt', 'w+');
			fputs($afile,"// Membres \n");
			fputs($afile,"\n");
			
			$response=array();
			$HomeCheckManager = new Home_Check();
			$exports = $HomeCheckManager->populate();
			fputs($afile, json_encode($exports)); 
			fputs($afile,"\n");
			fputs($afile,"\n");
			$response['membres']=$exports;
			
			fputs($afile,"// Camera Ip \n");
			fputs($afile,"\n");
			$cameraManager = new IPCamera();
			$exports = $cameraManager->populate();
			fputs($afile, json_encode($exports)); 
			fputs($afile,"\n");
			fputs($afile,"\n");
			$response['ipcameras']=$exports;
			
			fputs($afile,"// Relais Radios \n");
			fputs($afile,"\n");
			$alarm_Manager = new AlarmeSensorRadio("r");
			$exports=$alarm_Manager->populate();
			fputs($afile, json_encode($exports)); 
			fputs($afile,"\n");
			fputs($afile,"\n");
			$response['relaisradio']=$exports;
			
			fputs($afile,"// Relais Wifi \n");
			fputs($afile,"\n");
			$RadioManager = new AlarmeRelay();
			$exports = $RadioManager->populate();
			fputs($afile, json_encode($exports)); 
			fputs($afile,"\n");
			fputs($afile,"\n");
			$response['relaiswifi']=$exports;
			
			fclose($afile);
			$json_data=json_encode($response);
			//echo $json_data;
			file_put_contents(dirname(__FILE__).'//HomeCheck.json', $json_data);
			a:
			if(!$myUser) throw new Exception('Vous devez être connecté pour effectuer cette action');
			?>
			
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<legend>Sauvegarder/Restaurer configuration</legend>
					<p>Attention Données sensibles</p>
										
					<form enctype="multipart/form-data" action="action.php?action=plugin_HomeCheck_backup_all" method="post">
					Sauvegarder Configuration : <input type="submit" name="submit" value="Sauvergarder" />
					</form>
					
					<form enctype="multipart/form-data" action="action.php?action=plugin_HomeCheck_Upload" method="post">
					  <!-- MAX_FILE_SIZE doit précéder le champ input de type file -->
					  <input type="hidden" name="MAX_FILE_SIZE" value="30000" />
					  <!-- Le nom de l'élément input détermine le nom dans le tableau $_FILES -->
					  Restaurer Configuration : <input name="userfile" type="file" />
					  <input type="submit" value="Restaurer" />
					</form>
				</div>
			</div>
				<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='ADAlarme' && $_['sousblock'] =='Update')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","Update");
		
			if(!$myUser) throw new Exception('Vous devez être connecté pour effectuer cette action');
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<form>
					<fieldset>
					<legend>Mise à jour HomeCheck</legend>
					<button type="button" onclick="plugin_upd_src(this)" class="btn">Mise à jour Version</button>
					<div id="xhrAlarme">
						
					</div>
                    </fieldset>
                    <br/>
					</form>
					
				</div>
			</div>

			<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Sensor' && $_['sousblock'] =='SensorRXRADIO')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Sensor","SensorRXRADIO");
			// recepteurs: relais lumiere, alarme ...
			$RadioManager = new AlarmeSensorRadio();
			$Radios = $RadioManager->populate();
			$selected =  new AlarmeSensorRadio();
			
			//Si on est en mode modification
			if (isset($_['id'])) {
				$selected = $RadioManager->getById($_['id']);
			}
			$token=$myUser->getToken();
			//$secret = substr($myUser->getToken(), 0, 10); 
			//$time=time();
			//echo $time;
			
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<legend>Déclencheurs Enregistrés</legend>
					<a name="TopPage"></a>
					<button type="button" 
					onClick="location.href='index.php?module=Home_Check&block=Sensor&sousblock=SensorRXRADIO#BottomPage'" class="btn">Ajouter Déclencheur</button> 
					
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadSensorRadio("SensorRXRADIO");
						?>
					</div>
					
					
                    <legend>Ajouter/Modifier un relai radio</legend>
					<a name="BottomPage"></a>
                    <div class="left">
						
						<input type="hidden" id="id" value="<?php echo $selected->id; ?>">
						<input type="hidden" name="SensorType" id="SensorType" value="SensorRXRADIO"/>
                        <label for="descriptionGenericRadio">Description</label>
                        <input type="text"  value="<?php echo $selected->description; ?>" id="descriptionGenericRadio" placeholder="Relais sous le canapé…" />
							<legend> Relai communication direct </legend>
                            <label for="radioCodeGenericRadioOn">Code radio ON</label>
                            <input type="text" value="<?php echo $selected->radiocodeOn; ?>" name="radioCodeGenericRadioOn" id="radioCodeGenericRadioOn" placeholder="1:1234" />
                            <div class="input-append">
                                <span onclick="plugin_alarm_detectcode(this,'radioCodeGenericRadioOn','SensorRXRADIO')" class="btn">Scan Code</span>
								<span onclick="plugin_alarm_testcode(this,'radioCodeGenericRadioOn','SensorRXRADIO')" class="btn">Test Code</span>
                            </div>
							
							<label for="radioCodeGenericRadioOff">Code radio OFF</label>
                            <input type="text" value="<?php echo $selected->radiocodeOff; ?>" name="radioCodeGenericRadioOff" id="radioCodeGenericRadioOff" placeholder="1:1234" />
							<div class="input-append">
                                <span onclick="plugin_alarm_detectcode(this,'radioCodeGenericRadioOff','SensorRXRADIO')" class="btn">Scan Code</span>
								<span onclick="plugin_alarm_testcode(this,'radioCodeGenericRadioOff','SensorRXRADIO')" class="btn">Test Code</span>
                            </div>
							
							<legend> Paramètre généraux </legend>
							<label for="radioCodeGenericIsAlarm">Relai Alarme (Sirène etc)</label>
                            <!--<input type="text" value="<?php echo $selected->isalarm; ?>" name="radioCodeGenericIsAlarm" id="radioCodeGenericIsAlarm" placeholder="1:Oui 0:Non" /> -->
							<select name="radioCodeGenericIsAlarm" id="radioCodeGenericIsAlarm">
								<option <?php if ($selected->isalarm == 1 ) echo 'selected'; ?> value="Yes">Yes</option>
								<option <?php if ($selected->isalarm == 0 ) echo 'selected'; ?> value="No">No</option>
								</select>
					
							
                            <label for="onGenericRadio">Commande vocale "ON" associée</label>
                            <input type="text" value="<?php echo $selected->onCommand; ?>" name="onGenericRadio" id="onGenericRadio"  placeholder="Allume la lumière, Ouvre le volet…"/>

                            <label for="offGenericRadio">Commande vocale "OFF" associée</label>
                            <input type="text" value="<?php echo $selected->offCommand; ?>" name="offGenericRadio" id="offGenericRadio" placeholder="Eteinds la lumière, Ferme le volet…"/>
                            
							
                        </div>
						<div class="clear"></div>
						<br/>
						
                        <br/><button type="button" id="submitAlarme_AddRadio" class="btn">Enregistrer</button>
                    
					
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Sensor' && $_['sousblock'] =='SensorTXRADIO')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Sensor","SensorTXRADIO");
			// emetteurs: detecteur presence...
			/*
			$table = new AlarmeSensorRadio();
			$table->drop();
			
			$table1 = new AlarmeSensorRadio();
			$table1->create();
			*/
			$RadioManager = new AlarmeSensorRadio();
			$Radios = $RadioManager->loadAll(array('type'=>"SensorRXRADIO"));
			$selected =  new AlarmeSensorRadio();
			
			$RelayManager = new AlarmeRelay();
			$Relays = $RelayManager->populate();
			
			//Si on est en mode modification
			if (isset($_['id'])) {
				$selected = $RadioManager->getById($_['id']);
				//echo $selected->linkradio;
			}
			?>
			<div class="span9 userBloc">
				<div class="left">
					<legend>Détecteurs Enregistrés</legend>
					<a name="TopPage"></a>
					<button type="button" 
					onClick="location.href='index.php?module=Home_Check&block=Sensor&sousblock=SensorTXRADIO#BottomPage'" class="btn">Ajouter Détecteurs</button> 
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadSensorRadio("SensorTXRADIO");
						?>
					</div>
					
					<br/>
					<form>
					<fieldset>
                    <legend>Ajouter/Modifier un relai radio</legend>
					<a name="BottomPage"></a>
                    <div class="left">
						<input type="hidden" name="SensorType" id="SensorType" value="SensorTXRADIO"/>
						<input type="hidden" id="id" value="<?php echo $selected->id; ?>">
                        <label for="descriptionGenericRadio">Description</label>
                        <input type="text"  value="<?php echo $selected->description; ?>" id="descriptionGenericRadio" placeholder="Relais sous le canapé…" />

                            <label for="radioCodeGenericRadioOn">Code radio ON</label>
                            <input type="text" value="<?php echo $selected->radiocodeOn; ?>" name="radioCodeGenericRadioOn" id="radioCodeGenericRadioOn" placeholder="1:1234" />
                            <div class="input-append">
                                <span onclick="plugin_alarm_detectcode(this,'radioCodeGenericRadioOn','SensorTXRADIO')" class="btn">Scan Code</span>
                            </div>
							
							<label for="radioCodeGenericRadioOff">Code radio OFF</label>
                            <input type="text" value="<?php echo $selected->radiocodeOff; ?>" name="radioCodeGenericRadioOff" id="radioCodeGenericRadioOff" placeholder="1:1234" />
							<div class="input-append">
                                <span onclick="plugin_alarm_detectcode(this,'radioCodeGenericRadioOff','SensorTXRADIO')" class="btn">Scan Code</span>
                            </div>
							
							<label for="isSwitch">Type de detecteur</label>
							<select name="sensorTxTyp" id="sensorTxTyp">
								<option <?php if ($selected->sensorTxTyp == 3 ) echo 'selected'; ?> value="Interrupteur">Interrupteur</option>
								<option <?php if ($selected->sensorTxTyp == 2 ) echo 'selected'; ?> value="Ouverture">Ouverture</option>
								<option <?php if ($selected->sensorTxTyp == 1 ) echo 'selected'; ?> value="Presence">Présence</option>
								<option <?php if ($selected->sensorTxTyp == 0 ) echo 'selected'; ?> value="Autre">Autre</option>
								</select>
								
							<legend>Facultatif Relai associé, se déclenche quel que soit l'état de l'alarme </legend>
							<select name="relaiaction" id="relaiaction">
							
							<option value="-1">- - - Choisissez un Relai - - -</option>
							
							<?php
							foreach($Radios as $Radio) {
							?>
							<option <?php if ($selected->linkradio == "TX".$Radio->getId()){echo "selected";} ?> value="<?php echo("TX".$Radio->id); ?>"><?php echo($Radio->description); ?></option>
							<?php }							 
							?> 
							
							<?php
							foreach($Relays as $Relay) {
								if ($Relay->isSwitch==3 || $Relay->isSwitch==5) {
								?>
								<option <?php if ($selected->linkradio == "RW".$Relay->getId()){echo "selected";} ?> value="<?php echo("RW".$Relay->id); ?>"><?php echo($Relay->description); ?></option>
								<?php }	
							}
							?> 
							</select>
							
							<label for="DelaySensor">Temps d'activité du Relai (seconde), 0 jamais désactivé   :</label>
							<input type="number" name="DelaySensor" id ="DelaySensor" value="<?php echo $selected->delay; ?>" placeholder="0 jamais désactivé"/>
							
							<label for="LumiSensor">Seuil de luminosité (lux), 0 sans seuil:</label>
							<input type="number" name="LumiSensor" id ="LumiSensor" value="<?php echo empty($selected->lumi)?0:$selected->lumi; ?>" placeholder="0 sans seuil"/>
							
							<input type="hidden" name="onGenericRadio" id="onGenericRadio" value=""/>
							<input type="hidden" name="offGenericRadio" id="offGenericRadio" value=""/>
							
                        </div>

                        <div class="clear"></div>
                        <br/><button type="button" id="submitAlarme_AddRadio" class="btn">Enregistrer</button>
                    
                    </fieldset>
                    <br/>
					</form>
					
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Sensor' && $_['sousblock'] =='SensorRELAY')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Sensor","SensorRELAY");
			// emetteurs: detecteur presence...
			 /*
			$table1 = new AlarmeRelay();
			$table1->drop();
			
			$table1 = new AlarmeRelay();
			$table1->create();
			 */
	
			$RadioManager = new AlarmeRelay();
			$Radios = $RadioManager->populate();
			$selected =  new AlarmeRelay();
			$secret=substr($myUser->getToken(),-10);
			//echo $secret;
			$conf->put('secret',$secret);
			
			
			//Si on est en mode modification
			if (isset($_['id'])) {
				$selected = $RadioManager->getById($_['id']);
				//echo $selected->linkradio;
			}
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<form>
					<fieldset>
					<legend>Relais Wifi enregistrés</legend>
					<p>Synchro Auto toutes les 2 heures</p>
					<a name="TopPage"></a>
					<button type="button" 
					onClick="location.href='index.php?module=Home_Check&block=Sensor&sousblock=SensorRELAY#BottomPage'" class="btn">Ajouter Détecteurs</button>	
					<button type="button" onclick="plugin_sync_ip(this)" class="btn">Synchroniser les IPs</button>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadRelay();
						?>
					</div>
					
                    <legend>Ajouter/Modifier un relai WIFI</legend>
					<a name="BottomPage"></a>
                    <div class="left">
						
						<input type="hidden" id="id" value="<?php echo $selected->id; ?>">
                        <label for="descriptionGenericRelay">Description</label>
                        <input type="text"  value="<?php echo $selected->description; ?>" id="descriptionGenericRelay" placeholder="Relais sous le canapé…" />
						
						<label for="ipGenericRelay">Adresse IP detectée</label>
						<input type="text" value="<?php echo $selected->IPadress; ?>" name="ipGenericRelay" id="ipGenericRelay"  placeholder=""/>
						
						<label for="macGenericRelay">Adresse MAC obligatoire</label>
						<input type="text" value="<?php echo $selected->macaddr; ?>" name="macGenericRelay" id="macGenericRelay"  placeholder="AA:BB:CC:DD:EE:FF"/>
						
						<label for="isSwitch">Type de relai</label>
						<select name="isSwitch" id="isSwitch">
								<option <?php if ($selected->isSwitch == 1 ) echo 'selected'; ?> value="1">DomoSwitch</option>
								<option <?php if ($selected->isSwitch == 0 ) echo 'selected'; ?> value="0">Relai 433Mhz</option>
								<option <?php if ($selected->isSwitch == 2 ) echo 'selected'; ?> value="2">Relai Alarme</option>
								<option <?php if ($selected->isSwitch == 3 ) echo 'selected'; ?> value="3">Relai Inter</option>
								<option <?php if ($selected->isSwitch == 4 ) echo 'selected'; ?> value="4">Relai GSM</option>
								<option <?php if ($selected->isSwitch == 5 ) echo 'selected'; ?> value="5">Weelight</option>
								<option <?php if ($selected->isSwitch == 6 ) echo 'selected'; ?> value="6">BW-SHP6</option>
								</select>
						
						<?php if ($selected->isSwitch == 2 || $selected->isSwitch == 3 ) { ?>
						<label for="idGenericRelay">Id relai</label>
						<input type="number" value="<?php echo $selected->iddevice; ?>" name="idGenericRelay" id="idGenericRelay"  placeholder="0,1,2..."/>
						<?php } ?>
						
						<?php if ($selected->isSwitch == 5 ) { ?>
							<label for="idGenericRelay">Couleur</label>
							<input type="text" value="<?php echo $selected->st1; ?>" name="st1" id="st1" STYLE='background-color : <?php echo $selected->st1;?>' />
							<div class="input-append">
							<button class="jscolor
								{valueElement:'st1', styleElement:'st1'}">
								Click here to pick a color
							</button>
							</div>
							<label for="idGenericRelay">Intensité</label>
							<input type="number" value="<?php echo $selected->st2; ?>" name="st2" id="st2" min="0" max="100"/>
							
						<?php } ?>
						
						<script>
						function update(picker) {
							var s=document.getElementById('st1')
							s.value=picker.toHEXString();
							s.style.backgroundColor =picker.toHEXString();
						}
						</script>
						
						<?php if ($selected->isSwitch == 1 || $selected->isSwitch == 3 || $selected->isSwitch == 5 || $selected->isSwitch == 6) { ?>
						<legend> Commande Vocale Relai </legend>
						<label for="onGenericRelay">Commande vocale "ON" associée</label>
						<input type="text" value="<?php echo $selected->onCommand; ?>" name="onGenericRelay" id="onGenericRelay"  placeholder="Ouvre le volet…"/>

						<label for="offGenericRelay">Commande vocale "OFF" associée</label>
						<input type="text" value="<?php echo $selected->offCommand; ?>" name="offGenericRelay" id="offGenericRelay" placeholder="Ferme le volet…"/>
						
						<label for="stopGenericRelay">Commande vocale "ARRET" associée</label>
						<input type="text" value="<?php echo $selected->stopCommand; ?>" name="stopGenericRelay" id="stopGenericRelay" placeholder="Stop volet…"/>
						
						<?php } ?>
						
                        <div class="clear"></div>
                        <br/><button type="button" id="submitAlarme_AddRelay" class="btn">Enregistrer</button>
                         
						<br/>
						<br/>
						<?php if ($selected->isSwitch == 1 ) { ?>
						<legend> Relai DomoSwitch Synchronisation </legend>
						<label for="SyncGenericRelay"> Hors Tension, Placez interrupteur position haute, puis mettre sous tension DomoSwitch</label>
						<label for="relaysynchro">Status Synchro</label>
						<input type="text" class="input-xxlarge" value=""" name="relaysynchro" id="relaysynchro" placeholder="Resultat synchro"/>
						<div class="input-append">
							<span onclick="plugin_gethashcode('relaysynchro','<?php echo $secret; ?>',this)" class="btn">Synchroniser</span>
						</div>
						<label for="SyncGenericRelay"> Placez interrupteur position basse si la synchro est réussie</label>
						<?php } elseif ($selected->isSwitch == 0 ) { ?>
						<legend> Relai Synchronisation </legend>
						<label for="SyncRelay"> Synchronise les detecteurs avec les relais 433Mhz</label>
						<div class="input-append">
							<span onclick="plugin_sync_relay(this)" class="btn">Synchroniser</span>
						</div>
						<?php } elseif ($selected->isSwitch == 4 ) { ?>
						<legend> GSM Synchronisation </legend>
						<label for="SyncGsm"> Synchronise les relais GSM</label>
						<div class="input-append">
							<span onclick="plugin_sync_gsm(this)" class="btn">Synchroniser</span>
						</div>
						<?php } elseif ($selected->isSwitch == 5 ) { ?>
						<legend> Yeelight Synchronisation </legend>
						<label for="SyncYee"> Synchronise l'ampoule</label>
						<div class="input-append">
							<span onclick="plugin_sync_Yee(this)" class="btn">Synchroniser</span>
						</div>
						<?php } ?>
						
                    </fieldset>
                    <br/>
					</form>
					
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Sensor' && $_['sousblock'] =='SensorGPIO')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Sensor","SensorGPIO");
			/*
			$table1 = new AlarmeSensor();
			$table1->drop();
			
			$table1 = new AlarmeSensor();
			$table1->create();
			*/
			
			$alarme_conf = new AlarmeConf("r");
			$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_timetoStart"));
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<form>
						<fieldset>
							<legend>GPIO Enregistrés</legend>
							<input type="hidden" name="SensorType" id="SensorType" value="SensorGPIO"/>
							<label for="descriptionSensor">Description du détecteur :</label>
							<input type="text" name="descriptionSensor" id ="descriptionSensor" value="" placeholder="Détecteur de mouvement, etc.."/>
							
							<legend> Commande Vocale </legend>
							<label for="onGpio">Commande vocale "ON" associée</label>
							<input type="text" value="" name="onGpio" id="onGpio"  placeholder="Ouvre le volet…"/>

							<label for="offGpio">Commande vocale "OFF" associée</label>
							<input type="text" value="" name="offGpio" id="offGpio" placeholder="Ferme le volet…"/>
						
							<label for="numGPIO"> Numéro du GPIO (BCM) :</label>
							<input type="number" name="numGPIO" id ="numGPIO" value="" placeholder="1,2,3 etc.."/>
							<button type="button" id="submitAlarme_AddSensor" class="btn">Enregistrer</button>
							
						</fieldset>
					</form>
					<legend>Déclencheurs/détecteurs</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadSensor();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	//page Déclencheur URL
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Sensor' && $_['sousblock'] =='SensorURL')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Sensor","SensorURL");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br>
					<legend>Vous pouvez déclencher l'alarme depuis un autre périphérique, en éxécutant une URL</legend>
					<p>Pour des questions de sécurité, cette URL n'est pas disponible directement, il faudra fournir le token :</p>
					<code>
						<?php
						echo 'http://'.$_SERVER['SERVER_ADDR'].'/yana-server/action.php?action=Plugin_Alarme_Start_Action&token='.$myUser->getToken();
						?>
					</code>
					<br><br>
					<p>Cette URL est aussi accéssible sans token si la requette vient de l'addresse IP Local 127.0.0.1, donc un programme local</p>
				</div>
			</div>
		<?php
		}
	}

	//Page "Actions SMS"
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Actions'&& $_['sousblock'] =='ActionsSMS')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsSMS");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<p>Enregistrez les sms à envoyer en cas d'alerte, cette fonctionnalité est disponible pour les utilisateurs Free mobile</p>
					<p>Si vous êtes chez cet opérateur, vous pouvez activer dans les options de votre compte "Notification par sms" et récupérer le mot de passe ainsi que l'identifiant utilisateur.</p>					
					<form>						
						<fieldset>
							<legend>Envoie de sms lors d'une détection</legend>
							<input type="hidden" name="AlarmeTypeName" id="AlarmeTypeId" value="SMS"/>
							<label for="AlarmeUserId">Identifiant utilisateur (free mobile):</label>
							<input type="text" name="AlarmeUserName" id ="AlarmeUserId" value=""/>
							
							<label for="AlarmePassId">Mot de passe (free mobile):</label>
							<input type="text" name="AlarmePassName" id ="AlarmePassId" value=""/>
							
							<label for="AlarmeMsgId">Message à envoyer (free mobile):</label>
							<?php echo $conf->get('VOCAL_ENTITY_NAME'); ?>
							<input type="text" name="AlarmeMsgName" id ="AlarmeMsgId" value=""/>
							<button type="button" id="submitAlarme_test_SMS" class="btn">Tester SMS</button>
							<span id="plugin_alarme_test_span" style="display:none;"></span>
							<br/><br/>
							<button type="button" id="submitAlarme_AddActions_SMS" class="btn">Enregistrer</button>
						</fieldset>	
					</form>	
					<legend  >Envoie de SMS configuré</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadActions_SMS();
						?>
					</div>
				</div>
			</div>
		<?php		
		}
	}
	
	//Page "Actions group"
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Actions' && $_['sousblock'] =='ActionsGroup')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsGroup");
			
			/*
			$table = new ActionGroup();
			$table->create();
		
			$table = new ActionCollection();
			$table->create();
			
			$table = new ActionGroup();
			$table->drop();
			
			$table = new ActionCollection();
			$table->drop();
			*/
			
			$GroupManager = new ActionGroup();
			$selected =  new ActionGroup();
			
			$RadioManager = new AlarmeSensorRadio();
			$Radios = $RadioManager->loadAll(array('type'=>"SensorRXRADIO"));
			
			$RelayManager = new AlarmeRelay();
			$Relays = $RelayManager->populate();
			
			//Si on est en mode modification
			if (isset($_['id'])) {
				$selected = $GroupManager->getById($_['id']);
				//echo $selected->linkradio;
			}
			?>
			<div class="span9 userBloc">
				<div class="left">
					<legend>Groupes Enregistrés</legend>
					<a name="TopPage"></a>
					<button type="button" 
					onClick="location.href='index.php?module=Home_Check&block=Actions&sousblock=ActionsGroup#BottomPage'" class="btn">Ajouter Groupe</button> 
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadActionGroup();
						?>
					</div>
					
					<br/>
					<form>
					<fieldset>
                    <legend>Ajouter/Modifier un Groupe</legend>
					<a name="BottomPage"></a>
                    <div class="left">
						
						<input type="hidden" id="id" value="<?php echo $selected->id; ?>">
                        <label for="descriptionGroup">Description</label>
                        <input type="text"  value="<?php echo $selected->description; ?>" id="descriptionGroup" placeholder="nom du groupe…" />

                            <label for="actiongroupOn">Action ON</label>
                            <input type="text" value="<?php echo $selected->onCommand; ?>" name="actiongroupOn" id="actiongroupOn" placeholder="allume..." />
                           
							
							<label for="actiongroupOff">Action OFF</label>
                            <input type="text" value="<?php echo $selected->offCommand; ?>" name="actiongroupOff" id="actiongroupOff" placeholder="Eteint..." />
						
							
							<legend>Objets associés</legend>
							<select name="relaiaction" id="relaiaction">
							
							<option value="-1">- - - Choisissez un Relai - - -</option>
							
							<?php
							foreach($Radios as $Radio) {
							?>
							<option value="<?php echo("TX".$Radio->id); ?>"><?php echo($Radio->description); ?></option>
							<?php }							 
							?> 
							
							<?php
							foreach($Relays as $Relay) {
								if ($Relay->isSwitch==1 || $Relay->isSwitch==3 || $Relay->isSwitch==5 || $Relay->isSwitch==6) {
								?>
								<option value="<?php echo("RW".$Relay->id); ?>"><?php echo($Relay->description); ?></option>
								<?php }	
							}
							?> 
							</select>
							
							<div class="input-append">
							<span onclick="submitAlarme_AddActionItemGroup(this)" class="btn">Ajouter</span>
							</div>
							
							<?php
							if (isset($_['id'])) {
								plugin_alarme_LoadActionfromGroup($selected->id);
							}
							?> 
                        </div>

                        <div class="clear"></div>
                        <br/><button type="button" id="submitAlarme_AddActionGroup" class="btn">Enregistrer</button>
                    
                    </fieldset>
                    <br/>
					</form>
					
				</div>
			</div>
		<?php
		}
	}
	//Page "Actions prog"
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Actions' && $_['sousblock'] =='ActionsProg')
	{
		// (aide pour paramétrer https://crontab.guru)
		if($myUser!=false)
		{
			/*$table = new ExecCmd();
			$table->drop();
			
			$table = new ExecCmd();
			$table->create();
			*/
			plugin_alarme_onglet("Actions","ActionsProg");
			$ProgManager = new ExecCmd();
			
			list($host,$port) = explode(':',$_SERVER['HTTP_HOST']);
			//'http://'.$host.':'.$_SERVER['SERVER_PORT'].
			//$actionUrl = $_SERVER['REQUEST_URI'];
			$actionUrl = substr($actionUrl,0,strpos($actionUrl , '?'));
			
			Plugin::callHook("vocal_command", array(&$response,$actionUrl));
			
			//echo $response['commands'][0][command];
			//echo $response['commands'][0][url];
			//$json = json_encode($response);
			//echo ($json=='[]'?'{}':$json);
			//Si on est en mode modification
			if (isset($_['id'])) {
				$selected = $GroupManager->getById($_['id']);
				//echo $selected->linkradio;
			}
			
			/*<label for="appt">Choose a time/Heure précise:</label>
					<input type="time" id="appt" name="appt"
						   min="0:00" max="23:00" required>
						   */
			?>
			
			<div class="span9 userBloc">
				<div class="left">
					<legend>Actions Programmées Enregistrées</legend>
					
					<a name="TopPage"></a>
					<button type="button" 
					onClick="location.href='index.php?module=Home_Check&block=Actions&sousblock=ActionsProg#BottomPage'" class="btn">Ajouter Action</button> 
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadActionProg(1);
						?>
					</div>
					
					<br/>
					<form>
					<fieldset>
                    <legend>Ajouter une Action</legend>

					</br>
					<a name="BottomPage"></a>
                    <div class="left">
						
					<input type="hidden" id="id" value="<?php echo $selected->id; ?>">
					<label for="descriptionGroup">Description</label>
					<input type="text"  value="<?php echo $selected->description; ?>" id="descriptionProg" placeholder="nom du groupe…" />

					<label for="tripstart">Start date/Date départ:</label>
					<input type="date" id="tripstart" name="tripstart" value="">
					<br/>		
					<label for="tripend">End date/Date fin:</label>
					<input type="date" id="tripend" name="tripend" value="">
					<br/>		
							

					<label for="start">Month/Mois:</label>
					<select name="month" id="month" multiple="multiple">
					<option value="-1">All</option>
					<option value="1">January</option>
					<option value="2">February</option>
					<option value="3">March</option>
					<option value="4">April</option>
					<option value="5">May</option>
					<option value="6">June</option>
					<option value="7">July</option>
					<option value="8">Augest</option>
					<option value="9">September</option>
					<option value="10">October</option>
					<option value="11">November</option>
					<option value="12">December</option>
					</select>
					
					<label for="start">Week/Semaine:</label>
					 <select name="week" id="week" multiple="multiple" >
					<option value="-1">All</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
					<option value="16">16</option>
					<option value="17">17</option>
					<option value="18">18</option>
					<option value="19">19</option>
					<option value="20">20</option>
					<option value="21">21</option>
					<option value="22">22</option>
					<option value="23">23</option>
					<option value="24">24</option>
					<option value="25">25</option>
					<option value="26">26</option>
					<option value="27">27</option>
					<option value="28">28</option>
					<option value="29">29</option>
					<option value="30">30</option>
					<option value="31">31</option>
					<option value="32">32</option>
					<option value="33">33</option>
					<option value="34">34</option>
					<option value="35">35</option>
					<option value="36">36</option>
					<option value="37">37</option>
					<option value="38">38</option>
					<option value="39">39</option>
					<option value="40">40</option>
					<option value="41">41</option>
					<option value="42">42</option>
					<option value="43">43</option>
					<option value="44">44</option>
					<option value="45">45</option>
					<option value="46">46</option>
					<option value="47">47</option>
					<option value="48">48</option>
					<option value="49">49</option>
					<option value="50">50</option>
					<option value="51">51</option>
					<option value="52">52</option>
					<option value="53">53</option>
					</select>
					
					<label for="start">Weekday/Jour de semaine:</label>
					<select name="weekday" id="weekday" multiple="multiple">
					<option value="-1">All</option>
					<option value="1">Sunday</option>
					<option value="2">Monday</option>
					<option value="3">Tuesday</option>
					<option value="4">Wednesday</option>
					<option value="5">Thursday</option>
					<option value="6">Friday</option>
					<option value="7">Saturday</option>
					</select>
					
					<label for="start">Day of month/Jour du mois:</label>
					<select name="day" id="day" multiple="multiple">
					<option value="-1">All</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
					<option value="16">16</option>
					<option value="17">17</option>
					<option value="18">18</option>
					<option value="19">19</option>
					<option value="20">20</option>
					<option value="21">21</option>
					<option value="22">22</option>
					<option value="23">23</option>
					<option value="24">24</option>
					<option value="25">25</option>
					<option value="26">26</option>
					<option value="27">27</option>
					<option value="28">28</option>
					<option value="29">29</option>
					<option value="30">30</option>
					<option value="31">31</option>
					</select>
					
	
					
					<div title="Every/Toutes les Heures">
					<div>
					<input type="checkbox" id="everyhour" name="everyhour" unchecked>
					</div>
					<label for="start">Hour/Heure:</label>
					<select name="hour" id="hour" multiple="multiple" >
					<option value="-1">All</option>
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
					<option value="16">16</option>
					<option value="17">17</option>
					<option value="18">18</option>
					<option value="19">19</option>
					<option value="20">20</option>
					<option value="21">21</option>
					<option value="22">22</option>
					<option value="23">23</option>
					</select>
	
					
					
					</br>
					<div title="Every/Toutes les Minutes">
					<div>
					<input type="checkbox" id="everyminute" name="everyminute" unchecked>
					<label for="everyminute">Minutes</label>
					</div>
					<select name="minute" id="minute" multiple="multiple" >
					<option value="-1">All</option>
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
					<option value="16">16</option>
					<option value="17">17</option>
					<option value="18">18</option>
					<option value="19">19</option>
					<option value="20">20</option>
					<option value="21">21</option>
					<option value="22">22</option>
					<option value="23">23</option>
					<option value="24">24</option>
					<option value="25">25</option>
					<option value="26">26</option>
					<option value="27">27</option>
					<option value="28">28</option>
					<option value="29">29</option>
					<option value="30">30</option>
					<option value="31">31</option>
					<option value="32">32</option>
					<option value="33">33</option>
					<option value="34">34</option>
					<option value="35">35</option>
					<option value="36">36</option>
					<option value="37">37</option>
					<option value="38">38</option>
					<option value="39">39</option>
					<option value="40">40</option>
					<option value="41">41</option>
					<option value="42">42</option>
					<option value="43">43</option>
					<option value="44">44</option>
					<option value="45">45</option>
					<option value="46">46</option>
					<option value="47">47</option>
					<option value="48">48</option>
					<option value="49">49</option>
					<option value="50">50</option>
					<option value="51">51</option>
					<option value="52">52</option>
					<option value="53">53</option>
					<option value="54">54</option>
					<option value="55">55</option>
					<option value="56">56</option>
					<option value="57">57</option>
					<option value="58">58</option>
					<option value="59">59</option>
					</select>
					
					</br>
						
					<legend>Action associée</legend>
					<select name="relaiaction" id="relaiaction">
					<option value="-1">- - - Choisissez une Action - - -</option>
					<?php
					foreach($response['commands'] as $res) {
					?>
					<option value="<?php echo($res[url]); ?>"><?php echo($res[command]); ?></option>
					<?php }							 
					?> 
					</select>
					
				</div>
                        <div class="clear"></div>
                        <br/><button type="button" id="submitAlarme_AddActionProg" class="btn">Enregistrer</button>
                    
                    </fieldset>
                    <br/>
					</form>
					
				</div>
			</div>
		<?php
		}
	}
	//Page "Actions Lumi"
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Actions' && $_['sousblock'] =='ActionsLumi')
	{
		if($myUser!=false)
		{
			/*$table = new ExecCmd();
			$table->drop();
			
			$table = new ExecCmd();
			$table->create();
			*/
			$RelayManager = new AlarmeRelay();
			$Relays = $RelayManager->loadAll(array('isswitch'=>0));

			plugin_alarme_onglet("Actions","ActionsLumi");
			$ProgManager = new ExecCmd();
			
			list($host,$port) = explode(':',$_SERVER['HTTP_HOST']);
			//'http://'.$host.':'.$_SERVER['SERVER_PORT'].
			//$actionUrl = $_SERVER['REQUEST_URI'];
			$actionUrl = substr($actionUrl,0,strpos($actionUrl , '?'));
			
			Plugin::callHook("vocal_command", array(&$response,$actionUrl));

			?>
			<div class="span9 userBloc">
				<div class="left">
					<legend>Actions Enregistrées </legend>
					<a name="TopPage"></a>
					<button type="button" 
					onClick="location.href='index.php?module=Home_Check&block=Actions&sousblock=ActionsLumi#BottomPage'" class="btn">Ajouter Action</button> 
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadActionProg(2);
						?>
					</div>
					
					<br/>
					<form>
					<fieldset>
                    <legend>Ajouter une Action</legend>
					</br>
					<a name="BottomPage"></a>
                    <div class="left">
						
					<input type="hidden" id="id" value="<?php echo $selected->id; ?>">
					<label for="descriptionGroup">Description</label>
					<input type="text"  value="<?php echo $selected->description; ?>" id="descriptionProg" placeholder="nom du groupe…" />
					
					</br>
					<label for="relaiscr">Module de référence de la mesure</label>
					<select name="relaiscr" id="relaiscr">
					<option value="-1">- - - Choisissez une module - - -</option>
					<?php
					foreach($Relays as $Relay) {
						if ($Relay->isSwitch==0) {
						?>
						<option value="<?php echo($Relay->id); ?>"><?php echo($Relay->description); ?></option>
						<?php }	
					}
					?> 
					</select>
					
					<br/>	
					<div title="exemple entre 22h et 1h, mettre 22:01">
					<label for="interv">Intervalle Heure Début : Heure Fin de la condition :</label>
					<label for="note">(si non renseignée evaluée toute la journée i.e 0:23)</label>
					<input type="time" id="interv" name="interv" value="">
					<br/>		
					
					<div title="Action si supérieur ou inférieur au seuil">
					<label for="senslumi">Condition de l'action</label>
							<select name="senslumi" id="senslumi">
								<option value="up">Si mesure supérieure à</option>
								<option value="down">Si mesure inférieure à</option>
								</select>						
					
					<div title="Lu sur le module">
					<label for="slumi">Seuil de mesure de la condition:</label>
					<input type="number" id="slumi" name="slumi" value="">
					
					<div title="Si grande, action déclenchée rapidement quand le seuil atteint">
					<label for="intmin">Fréquence de mesure dans l'Intervalle(min 5/max 59 minutes):</label>
					<input type="number" id="intmin" name="intmin" value="" min=5 max=59>
					<br/>	
					
					<div title="Actions disponibles">
					<legend>Action associée</legend>
					<select name="relaiactionlumi" id="relaiactionlumi">
					<option value="-1">- - - Choisissez une Action - - -</option>
					<?php
					foreach($response['commands'] as $res) {
					?>
					<option value="<?php echo($res[url]); ?>"><?php echo($res[command]); ?></option>
					<?php }							 
					?> 
					</select>
					
				</div>
                        <div class="clear"></div>
                        <br/><button type="button" id="submitAlarme_AddActionLumi" class="btn">Enregistrer</button>
                    
                    </fieldset>
                    <br/>
					</form>
					
				</div>
			</div>
		<?php
		}
	}
	//Page "Actions Email"
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Actions' && $_['sousblock'] =='ActionsEmail')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsEmail");
			
			?>
			<div class="span9 userBloc">
				<br/>
				<p>Enregistrez les adresses emails à contacter en cas d'alerte.</p>
				<div class="left">
					<form>						
						<fieldset>
							<legend>Envoie d'Email supplémentaire lors d'une detection (hors admin)</legend>
							
							<input type="hidden" name="AlarmeTypeName" id="AlarmeTypeId" value="Email"/>
							
							<label for="EmailExp">Email destinaire:</label>
							<input type="text" name="EmailExp" id ="EmailExp" value="" placeholder="monami@fac.fr"/>
							
							<br/><br/>
							<button type="button" id="submitAlarme_AddActions_Email" class="btn">Enregistrer</button>
						</fieldset>
					</form>
				
				<legend>Envoie d'Email configuré</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadActions_Email();
						?>
					</div>
				</div>					
			</div>
		<?php
		}		
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Actions' && $_['sousblock'] =='ActionsGPIO')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsGPIO");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<p>Déclenchez une liste de GPIO en cas d'alerte, celles-ci pouvant alimenter/déclancher des hauts parleurs, des relais, des lanceurs de haches, etc... </p>
					
					<form action="action.php?action=plugin_alarme_test_email" method="POST">						
						<fieldset>
							<legend>Changement d'un GPIO en cas de détection</legend>
							<input type="hidden" name="AlarmeTypeName" id="AlarmeTypeId" value="GPIO"/>
							
							<label for="descriptionGPIO"> Description GPIO :</label>
							<input type="text" name="descriptionGPIO" id ="descriptionGPIO" value="" placeholder="Lanceur de haches, haut parleur, etc.."/>
							
							<label for="numGPIO"> Numéro du GPIO (WiringPi) :</label>
							<input type="number" name="numGPIO" id ="numGPIO" value="" placeholder="1,2,3 etc.."/>
							
							<label for="stateGPIO"> Etat du GPIO en cas d'alerte:</label>
							<input type="number" name="stateGPIO" id ="stateGPIO" value="" placeholder="0 ou 1"/>
							
							<button type="button" id="submitAlarme_test_GPIO" class="btn">Tester la bascule du GPIO</button>
							<br/>
							<span id="plugin_alarme_test_span"></span>
							<br/><br/>
							<button type="button" id="submitAlarme_AddActions_GPIO" class="btn">Enregistrer</button>
						</fieldset>
					</form>
					<legend  >GPIO Configuré</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadActions_GPIO();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Actions' && $_['sousblock'] =='ActionCamera')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsCamera");
			
			//chemin d'enregistrement des photos
			$alarme_conf = new AlarmeConf("r");
			$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraType"));
			$Type = $alarme_conf->getValue();
		
			$alarme_conf= $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResH"));
			$ResH = $alarme_conf->getValue();

			$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResV"));
			$ResV = $alarme_conf->getValue();
			
			$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraTime"));
			$Time = $alarme_conf->getValue();
			
			$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraOption"));
			$Option = $alarme_conf->getValue();
			
			$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraCopyDirectory"));
			$CopyDirectory = $alarme_conf->getValue();
			
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<p>Prendre des photos ou des videos en cas d'alerte</p>
					<p>Pour cela, la caméra doit déja étre configuré, comme dans le plugin Caméra  <i class="fa fa-question-circle fa-lg" id="IconeCameraInfobulle"></i></p>
					<div id="CameraInfobulle" style="display:none;" class="right">
					  <p>
						Avant de pouvoir utiliser ce plugin, vous devez avoir branché la caméra RPI, puis vous devez executer les commandes suivantes dans le terminal du raspberry pi :
						<br/><code>
							sudo apt-get update && sudo apt-get upgrade
						</code><br/>
						Puis tapez<br/>
						<code>
							sudo raspi-config 
						</code><br/>
						Puis allez dans "camera" et sélectionnez "enable", redemarrez et tapez<br/>
						<code>
							sudo usermod -a -G video www-data
						</code><br/>
						Puis<br/>
						<code>
							sudo echo 'SUBSYSTEM=="vchiq",GROUP="video",MODE="0660"' > /etc/udev/rules.d/10-vchiq-permissions.rules
						</code><br/>
						Et enfin<br/>
						<code>
							sudo chown -R www-data:www-data /var/www/yana-server/plugins/Home_Check/camera
						</code><br/>
							Redémarrez et c'est ok :)
						<br/>
							Auteur : Idleman Encore lui :)
					  </p>
					</div>
					<br/>
					<form>
						<fieldset>
							<legend>Camera</legend>
							<label for="Plugin_Alarme_Camera">Type de capture :</label>
							<select class="input-large" name="Plugin_Alarme_Camera" id="Plugin_Alarme_Camera">
								<option value="Photo"<?php if ($Type=="Photo"){ echo 'selected';}?> > Photo</option>
								<option value="Video"<?php if ($Type=="Video"){ echo 'selected';}?>>Video</option>
							</select>
							<div id="Plugin_Alarme_Photo" <?php if ($Type!="Photo"){ echo 'style="display:none;"';}?> class="right">
								<legend>Photo</legend>
								<label for="Plugin_Alarme_Resolution_V">Résolution largeur:</label>
								<input type="number" name="Plugin_Alarme_Resolution_V" id ="Plugin_Alarme_Resolution_V" value="<?php if ($Type=="Photo"){ echo $ResV;}?>" placeholder="400"/>
								
								<label for="Plugin_Alarme_Resolution_H">Résolution hauteur:</label>
								<input type="number" name="Plugin_Alarme_Resolution_H" id ="Plugin_Alarme_Resolution_H" value="<?php if ($Type=="Photo"){ echo $ResH;}?>" placeholder="400"/>
								
								<label for="Plugin_Alarme_CameraOption">Options Raspistill (facultatif):</label>
								<input type="text" name="Plugin_Alarme_CameraOption" id ="Plugin_Alarme_CameraOption" value="<?php if ($Type=="Photo"){ echo $Option;}?>" placeholder="-hf -vf ..."/>
								
								<label for="Plugin_Alarme_CameraCopyDirectory">Copier la photo sur un montage réseau : </label>
								<input type="text" name="Plugin_Alarme_CameraCopyDirectory" id ="Plugin_Alarme_CameraCopyDirectory" value="<?php if ($Type=="Photo"){ echo $CopyDirectory;}?>" placeholder="/media/photo/"/>

								<br/>
								<br/>
							</div>
							<div id="Plugin_Alarme_Video" <?php if ($Type!="Video"){ echo 'style="display:none;"';}?> class="right">
								<legend>Video</legend>
								
								<label for="Plugin_Alarme_Resolution_vid_V">Résolution largeur:</label>
								<input type="number" name="Plugin_Alarme_Resolution_vid_V" id ="Plugin_Alarme_Resolution_vid_V" value="<?php if ($Type=="Video"){ echo $ResV;}?>" placeholder="400"/>
								
								<label for="Plugin_Alarme_Resolution_vid_H">Résolution hauteur:</label>
								<input type="number" name="Plugin_Alarme_Resolution_vid_H" id ="Plugin_Alarme_Resolution_vid_H" value="<?php if ($Type=="Video"){ echo $ResH;}?>" placeholder="400"/>

								<label for="Plugin_Alarme_TimeToCapture">Temps de capture (en milliseconde):</label>
								<input type="number" name="Plugin_Alarme_TimeToCapture" id ="Plugin_Alarme_TimeToCapture" value="<?php if ($Type=="Video"){ echo $Time;}?>" placeholder="5000"/>
								
								<label for="Plugin_Alarme_CameraOption_vid">Options Raspivid (facultatif):</label>
								<input type="text" name="Plugin_Alarme_CameraOption_vid" id ="Plugin_Alarme_CameraOption_vid" value="<?php if ($Type=="Video"){ echo $Option;}?>" placeholder="-hf -vf ..."/>
							
								<label for="Plugin_Alarme_CameraCopyDirectory_vid">Copier la vidéo sur un montage réseau : </label>
								<input type="text" name="Plugin_Alarme_CameraCopyDirectory_vid" id ="Plugin_Alarme_CameraCopyDirectory_vid" value="<?php if ($Type=="Video"){ echo $CopyDirectory;}?>" placeholder="/media/video/" />
							</div>
							
							<button type="button" id="submitAlarme_Camera_Test" class="btn">Tester la capture</button><span id="plugin_alarme_test_span"></span>
							<br/><br/>
							<button type="button" id="submitAlarme_Camera_Add" class="btn">Enregistrer</button>
							<span id="plugin_alarme_save_span"></span>
							<br/>
						</fieldset>	
					</form>
					
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadCamera();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Actions' && $_['sousblock'] =='ActionCameraIP')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsCameraIP");
			
			$alarme_conf = new AlarmeConf("r");
			$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_DriveDirectory"));
			$DriveDirectory = $alarme_res->getValue();
			$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_RepoDirectory")); 
			$RepoDirectory = $alarme_res->getValue();
			$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_StoreDirectory"));
			$StoreDirectory = $alarme_res->getValue();
			$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_SendSms"));
			$issms = $alarme_res->getValue();
			$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_SendEmail"));
			$send_email = $alarme_res->getValue();
					
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<p>Les alertes sont déclenchées si l'alarme est active</p>
					<p>Si l'alarme n'est pas active, les fichiers sont supprimés</p>
					<p> L'activation de l'application sur votre compte google est nécessaire: <a href=http://www.backupcamip.com//Accueil/domocom target="_blank" >BackupCamIp_PI </a></p>
					<p><?php if (!file_exists('/usr/bin/backupcamip')) { ?>
						<p> BackupCamIp non installé: <a href="https://github.com/backupcamip/backupcamip_pi.git" target="_blank" > Installation </a></p> 
					<?php } ?>
					<br/>
		
					<form>
						<fieldset>
							<legend>Paramètres BackupCamIp</legend>
							
								<input type="hidden" name="Plugin_Alarme_Drive" id ="Plugin_Alarme_Drive" value="getfromgoogle"/>
								
								<label for="Plugin_Alarme_RepoDirectory">Répèrtoire Source de stockage local des Images/Videos:</label>
								<input type="text" name="Plugin_Alarme_RepoDirectory" id ="Plugin_Alarme_RepoDirectory" value="<?php echo $RepoDirectory;?>" placeholder="/mnt/videos"/>
								
								<label for="Plugin_Alarme_StoreDirectory">Répèrtoire sauvegarde locale (facultatif) : </label>
								<input type="text" name="Plugin_Alarme_StoreDirectory" id ="Plugin_Alarme_StoreDirectory" value="<?php echo $StoreDirectory;?>" placeholder="/media/photo/"/>
								
								<label for="Plugin_Alarme_DriveDirectory">Répèrtoire Source de stockage Google Drive : </label>
								<input type="text" name="Plugin_Alarme_DriveDirectory" id ="Plugin_Alarme_DriveDirectory" value="<?php echo $DriveDirectory;?>" placeholder="/media/photo/"/>
									
								<label for="Plugin_Alarme_SendEmail">Envoie Email avec capture si detection: </label>
								<select name="Plugin_Alarme_SendEmail" id="Plugin_Alarme_SendEmail">
								<option <?php if ($send_email == "Yes" ) echo 'selected'; ?> value="Yes">Yes</option>
								<option <?php if ($send_email == "No" ) echo 'selected'; ?> value="No">No</option>
								</select>
								
								<label for="Plugin_Alarme_SendSms">Envoie SMS si alerte et active alarme: </label>
								<select name="Plugin_Alarme_SendSms" id="Plugin_Alarme_SendSms">
								<option <?php if ($issms == "Yes" ) echo 'selected'; ?> value="Yes">Yes</option>
								<option <?php if ($issms == "No" ) echo 'selected'; ?> value="No">No</option>
								</select>
								<br/>
								<br/>
							
							<button type="button" id="submitAlarme_CameraIP_Add" class="btn">Enregistrer</button>
							<span id="plugin_alarme_save_span"></span>
							<br/>
						</fieldset>	
					</form>
					
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Actions' && $_['sousblock'] =='ActionsURL')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsURL");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<form>
						<fieldset>
							<legend>Ces URL seront executées en cas d'alerte</legend>
							<input type="hidden" name="Plugin_Alarme_TypeURL" id="Plugin_Alarme_TypeURL" value="ActionUrl"/>
							<input type="text"name="Plugin_Alarme_ActionURL" id ="Plugin_Alarme_ActionURL" value="" placeholder="http://192.168.0.1/yana-server/index.php"/>
							<button type="button" id="submitAlarme_test_URL" class="btn">Tester l'URL</button>
							<br>
							<span id="plugin_alarme_test_span"></span>
							<br>
							<button type="button" id="submitAlarme_AddActions_URL" class="btn">Enregistrer</button>
						</fieldset>	
					</form>
					<legend  >URL enregistrées</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadActionsURL();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
		elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Actions' && $_['sousblock'] =='ActionsShell')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsShell");
			
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<form>
						<fieldset>
							<legend>Vous pouvez rentrer des actions Shell ici, elles seront exécutées en cas d'alerte</legend>
							<p>Les commandes sont exécutées par l'interface, donc par l'utilisateur www-data, cet utilisateur à des droits restreints sur le système..
							</p>
							<input type="hidden" name="Plugin_Alarme_TypeShell" id="Plugin_Alarme_TypeShell" value="ActionShell"/>
							<input type="text"name="Plugin_Alarme_ActionShell" id ="Plugin_Alarme_ActionShell" value="" placeholder="/usr/local/bin/monExec"/>
							<button type="button" id="submitAlarme_test_Shell" class="btn">Tester la commande Shell</button>
							<br>
							<span id="plugin_alarme_test_span"></span>
							<br>
							<button type="button" id="submitAlarme_AddActions_Shell" class="btn">Enregistrer</button>
						</fieldset>	
					</form>
					<legend  >Commandes Shell enregistrées</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadActionsShell();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='Donnees' && $_['sousblock'] =='ReleveTemp')
	{
		if($myUser!=false) {
			plugin_alarme_onglet("Donnees","ReleveTemp");
			?>
			<div class="span9 userBloc">
				<div class="left">
				<h1>Capteurs & Temperature</h1>

				<br /><legend>Historique des 12 derniers jours</legend>
					<style type="text/css"> 
					canvas{
						width: 100% !important;
						height: auto !important;
					}
				  </style>
				<small>Relev&eacute;s pris à midi</small>
				<canvas id="temperature_d" width="800" height="250"></canvas>
				<?php
			

				if ($file = fopen(__DIR__.'/history_d.txt', "r")) {
					$i=0;
					while(!feof($file)) {
						$i++;
						$line = fgets($file);
						if ($i==1) $data1=explode(" ", $line);
						if ($i==2) $data2=explode(" ", $line);
						if ($i==3) $data3=explode(" ", $line);
						# do same stuff with the $line
					}
					fclose($file);
				}
				//$data = file_get_contents(__DIR__.'/history_d.txt');
				//$data = explode(" ", $data);
				?>
			
				<script>
				
				//Chart.defaults.global.responsive = true;
				//Chart.defaults.global.legend.display = true;
				//Chart.defaults.global.tooltips.enabled = true;
				var tempdData = {
						labels : [<?php for($i=11; $i>=0; $i--) { echo "\"" . date('d/m', strtotime('-'.$i.' day')) . "\", "; }?>],
						datasets : [
								{
								label: "temperature",
								fillColor : "rgba(65,25,225,0.4)",
								strokeColor : "#B40404",
								pointColor : "#4169E1",
								pointStrokeColor : "#9DB86D",
								data : [<?php for($i=0; $i<12; $i++) { echo $data1[$i]. ", "; } ?>]
								},
								{
								label: "Humidite",
								fillColor : "rgba(255,255,255,0.4)",
								strokeColor : "#B40404",
								pointColor : "#FFFFFF",
								pointStrokeColor : "#9DB86D",
								data : [<?php for($i=0; $i<12; $i++) { echo $data3[$i] . ", "; } ?>]
								}
						]
				}
				var options={
					responsive: true,
					maintainAspectRatio: true,
					beginAtZero:false,
					scales: {
						yAxes: [{
							ticks: {
								beginAtZero:false
							}
						}]
					},
					legend: {
					display: true,
					labels: {
						fontColor: 'rgb(255, 99, 132)'
					}
					},
					title: {
							display: true,
							text: 'Custom Chart Title'
						}
					
				};
				var temperature_d = document.getElementById('temperature_d').getContext('2d');
				new Chart(temperature_d).Line(tempdData,options);
				
				</script><br /><br /><br />

				<legend>Historique des 12 derni&egrave;res heures</legend>
					
					<canvas id="temperature_h" width="800" height="250"></canvas>
					<?php
					if ($file = fopen(__DIR__.'/history_h.txt', "r")) {
						$i=0;
						while(!feof($file)) {
							$i++;
							$line = fgets($file);
							if ($i==1) $data1=explode(" ", $line);
							if ($i==2) $data2=explode(" ", $line);
							if ($i==3) $data3=explode(" ", $line);
							# do same stuff with the $line
						}
						fclose($file);
					}
					//$data = file_get_contents(__DIR__.'/history_h.txt');
					//$data = explode(" ", $data);
					?>
					<script>
					var temphData = {
							labels : [<?php for($i=11; $i>=0; $i--) { echo "\"" . date('H', strtotime('-'.$i.' hour')) . "h\", "; }?>],
							datasets : [
								{
								label: "temperature",
								fillColor : "rgba(65,25,225,0.4)",
								strokeColor : "#B40404",
								pointColor : "#4169E1",
								pointStrokeColor : "#9DB86D",
								data : [<?php for($i=0; $i<12; $i++) { echo $data1[$i] . ", "; } ?>]
								},
								{
								label: "Humidite",
								fillColor : "rgba(255,255,255,0.4)",
								strokeColor : "#B40404",
								pointColor : "#FFFFFF",
								pointStrokeColor : "#9DB86D",
								data : [<?php for($i=0; $i<12; $i++) { echo $data3[$i] . ", "; } ?>]
								}
						]
					}
					var temperature_h = document.getElementById('temperature_h').getContext('2d');
					
					new Chart(temperature_h).Line(temphData,options);
					
					</script><br /><br /><br />
					
					<br /><legend>Historique Global </legend>
					<style type="text/css"> 
					canvas{
						width: 100% !important;
						height: auto !important;
					}
				  </style>
			
				<canvas id="temperature_a" width="800" height="250"></canvas>
				<?php
				if ($file = fopen(__DIR__.'/history_all.txt', "r")) {
					$i=0;
					while(!feof($file)) {
						$i++;
						$line = fgets($file);
						if ($i==1) $data1=explode(" ", $line);
						if ($i==2) $data2=explode(" ", $line);
						if ($i==3) $data3=explode(" ", $line);
						# do same stuff with the $line
					}
					fclose($file);
				}
				
				?>
				
				
				<script>
				var tempdData = {
						labels : [<?php for($i=count($data1)-2; $i>=0; $i--) { echo "\"" . date('H', strtotime('-'.($i%24).' hour')) . "h\", "; }?>],
						datasets : [
								{
								label: "temperature",
								fillColor : "rgba(65,25,225,0.4)",
								strokeColor : "#B40404",
								pointColor : "#4169E1",
								pointStrokeColor : "#9DB86D",
								data : [<?php for($i=0; $i<count($data1); $i++) { echo $data1[$i]. ", "; } ?>]
								},
								{
								label: "Humidite",
								fillColor : "rgba(255,255,255,0.4)",
								strokeColor : "#B40404",
								pointColor : "#FFFFFF",
								pointStrokeColor : "#9DB86D",
								data : [<?php for($i=0; $i<count($data1); $i++) { echo $data3[$i] . ", "; } ?>]
								}
						]
				}
				var options={
					responsive: true,
					maintainAspectRatio: true,
					beginAtZero:false,
					scales: {
						yAxes: [{
							ticks: {
								beginAtZero:false
							}
						}]
					},
					legend: {
					display: true,
					labels: {
						fontColor: 'rgb(255, 99, 132)'
					}
					},
					title: {
							display: true,
							text: 'Custom Chart Title'
						}
					
				};
				var temperature_d = document.getElementById('temperature_a').getContext('2d');
				new Chart(temperature_d).Line(tempdData,options);
				
				</script><br /><br /><br />
				
				</div>
			</div>
			<?php	
			
			
		}
	}
	elseif(isset($_['module']) && $_['module']=='Home_Check' &&$_['block'] =='SnapShot' && $_['sousblock'] =='SnapShot')
	{
		if($myUser!=false) {
			plugin_alarme_onglet("SnapShot","SnapShot");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<form>
						<fieldset>
							<legend>SnapShot Camera</legend>
							<?php
							
							/** settings **/
							$images_dir = dirname(__FILE__).'/photos/';
							$thumbs_dir = dirname(__FILE__).'/thumbs/';
							
							$files = glob($images_dir.'/*'); 
							foreach($files as $file){ // iterate files
							  if(is_file($file))
								unlink($file); // delete file
							}
							
							$files = glob($thumbs_dir.'/*'); 
							foreach($files as $file){ // iterate files
							  if(is_file($file))
								unlink($file); // delete file
							}
							
							$relpath="./plugins/HomeCheck/photos/";
							//$relpath="./plugins/HomeCheck/gallery-images/";
							
							$alarme_conf = new AlarmeConf();
							$alarme_conf = $alarme_conf->load(array('conf'=>"Plugin_Alarme_RepoDirectory"));
							$dirsrc=$alarme_conf->getValue();
							
							//echo $dirsrc;
							$image_files=listFiles($dirsrc);
							if (count($image_files)) {
								foreach($image_files as $file){ // iterate files
									$path_parts = pathinfo($file);
									$mime=mime_content_type($file);
									//echo $path_parts['dirname'], "\n";
									//echo $path_parts['basename'], "\n";
									//echo $path_parts['extension'], "\n";
									//echo $path_parts['filename'], "\n";
									echo $file." ".$mime." ".strpos($mime, 'image')==true."</br>";
									//echo $mime." ".strpos($mime, "image")==true;
									if(is_image($file))
										copy($file,$images_dir.'/'.$path_parts['basename']); 
										//echo $images_dir.'/'.$path_parts['basename'];
								}
							}
							
							// /plugins/HomeCheck/photos/
							$thumbs_width = 300;
							$images_per_row = 3;
							
							/** generate photo gallery **/
							
							$image_files = get_files($images_dir);
							if(count($image_files)) {
								$index = 0;
								try {
									foreach($image_files as $index=>$file) {
										$index++;
										$thumbnail_image = $thumbs_dir.$file;
										if(!file_exists($thumbnail_image)) {
											$extension = get_file_extension($thumbnail_image);
											if($extension) {
												make_thumb($images_dir.$file,$thumbnail_image,$thumbs_width);
											}
										}
										
										$pos = strpos($thumbnail_image, "plugins");
										$relpaththumb=substr($thumbnail_image,$pos);
										
										echo '<a href="',$relpath.$file,'" class="photo-link smoothbox" rel="gallery"><img src="',$relpaththumb,'" /></a>';
										if($index % $images_per_row == 0) { echo '<div class="clear"></div>'; }
									}
								} catch (Exception $e) {
									echo 'Exception: ',  $e->getMessage(), "\n";
								}
								echo '<div class="clear"></div>';
							}
							else {
								echo '<p>There are no images in this gallery.</p>';
							}
							
							?>
						</fieldset>	
					</form>
					
				</div>
			</div>
				
		<?php
		}
	}		
	elseif(isset($_['module']) && $_['module']=='Home_Check' && $_['block'] =='Widget' && $_['sousblock'] =='WidgetGeneral')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Widget","WidgetGeneral");
			?>
			
			
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<form>
						<fieldset>
							<legend>Vous pouvez rentrer des actions Shell ici, elles seront exécutées en cas d'alerte</legend>
							<p>Les commandes sont exécutées par l'interface, donc par l'utilisateur www-data, cet utilisateur à des droits restreints sur le système..
							</p>
							<input type="hidden" name="Plugin_Alarme_TypeShell" id="Plugin_Alarme_TypeShell" value="ActionShell"/>
							<input type="text"name="Plugin_Alarme_ActionShell" id ="Plugin_Alarme_ActionShell" value="" placeholder="/usr/local/bin/monExec"/>
							<button type="button" id="submitAlarme_test_Shell" class="btn">Tester la commande Shell</button>
							<br>
							<span id="plugin_alarme_test_span"></span>
							<br>
							<button type="button" id="getOP" class="btn">Enregistrer</button>
						</fieldset>	
					</form>
					
				</div>
			</div>
				
		<?php
		}
	}
}

?>