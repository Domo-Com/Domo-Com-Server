<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/

class AlarmeSensorRadio extends SQLiteEntity
{
	public $state;
	public $delay;
	public $description;
	public $id;
	public $sensorTxTyp;
	protected $TABLE_NAME = 'plugin_AlarmeSensorRadio';
	protected $CLASS_NAME = 'AlarmeSensorRadio';
	protected $object_fields = 
	array(
		'id'=>'key',
		'type'=>'string',
		'description'=>'string',
		'onCommand'=>'string',
		'offCommand'=>'string',
		'radiocodeOn'=>'string',
		'radiocodeOff'=>'string',
		'sensorTxTyp'=>'int',
		'isalarm'=>'int',
		'linkradio'=>"string",
		'state'=>"int",
		'delay'=>"int",
		'lumi'=>'int',
	);

	
	function __construct($tag="rw")
	{
		parent::__construct($tag);
	}
	
	function getId()
	{
		return $this->id;
	}
	
	function setId($id)
	{
		$this->id = $id;
	}
	
	function getType()
	{
		return $this->type;
	}

	function setType($type)
	{
		$this->type = $type;
	}
	
		function getString(){
		return $this->string;
	}

	function setString($string){
		$this->string = $string;
	}

	function getInteger(){
		return $this->integer;
	}

	function setInteger($integer){
		$this->integer = $integer;
	}

	function getDelay()
	{
		return $this->delay;
	}
	
	function setDelay($delay)
	{
		$this->delay = $delay;
	}
	
	function getDescription()
	{
		return $this->description;
	}
	
	function setDescription($description)
	{
		$this->description = $description;
	}
	
	function getState()
	{
		return $this->state;
	}
	
	function setState($state)
	{
		$this->state=$state;
	}
	
	function getNumGPIO()
	{
		return $this->numGPIO;
	}

	function setNumGPIO($numGPIO)
	{
		$this->numGPIO = $numGPIO;
	}
}
?>