<?php

/*
 @nom: Camera
 @auteur: Idleman (idleman@idleman.fr)
 @description:  Classe de gestion des camera IP
 */

class IPCamera extends SQLiteEntity{

	public $id,$location,$label,$ip,$login,$password,$pattern;
	protected $TABLE_NAME = 'plugin_Alarme_ipcam_camera';
	protected $CLASS_NAME = 'IPCamera';
	protected $object_fields = 
	array(
		'id'=>'key',
		'label'=>'string',
		'ip'=>'string',
		'login'=>'string',
		'password'=>'string',
		'location'=>'string',
		'pattern'=>'string',
        'brand'=>'string',
	);

	function __construct($tag='rw'){
		parent::__construct($tag);
	}

	//Ajoutez votre modèle de caméra et son url d'appel vidéo ici
	//N'hésitez pas a partager votre ajout sur https://github.com/ldleman/yana-server/issues/new afin d'en faire profiter la communauté
	public static function brands(){
		return array(
		"Scricam" => 'http://{{login}}:{{password}}@{{ip}}/videostream.cgi',
		"Foscam fi8908" => 'http://{{ip}}/videostream.cgi?user={{login}}&pwd={{password}}&resolution=32&rate=0',
		"Dlink 5222l" => 'http://{{login}}:{{password}}@{{ip}}/video/mjpg.cgi',
		"Wanscam HW0036" => 'http://{{ip}}/videostream.cgi?user={{login}}&pwd={{password}}',
		"PiCam" => 'http://{{login}}:{{password}}@{{ip}}/webcam',
		"Autre" => 'http://{{login}}:{{password}}@{{ip}}');
	}
	

}

?>