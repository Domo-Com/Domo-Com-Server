<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/

class HMCollection extends SQLiteEntity
{
	private $items = array();

	protected $TABLE_NAME = 'plugin_ActionCollection';
	protected $CLASS_NAME = 'HMCollection';
	protected $object_fields = 
	array(
		'id'=>'key',
		'type'=>'string',
		'description'=>'string',
		'linkradio'=>"string",
		'state'=>"int",
		'delay'=>"int",
		'lumi'=>'int',
		'iddevice'=>'int',
		'macaddr'=>'string',
		'st1'=>'string',
		'st2'=>'string',
		'st3'=>'string',
		'st4'=>'string',
		'st5'=>'string',
		'st6'=>'string',
	);

	
	function __construct($tag="rw")
	{
		parent::__construct($tag);
	}
		
}
?>