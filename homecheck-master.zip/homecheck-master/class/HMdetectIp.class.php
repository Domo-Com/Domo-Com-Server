<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description homecheckIP.
*/

class detectIP extends SQLiteEntity
{
	public $ip;
	public $mac;
	public $owner;
	protected $TABLE_NAME = 'homecheckIP';
	protected $CLASS_NAME = 'detectIP';
	protected $object_fields = 
	array(
		'id'=>'key',
		'ip'=>'string',
		'mac'=>'string',
		'owner'=>'string',
	);

	function __construct($tag="rw")
	{
		parent::__construct($tag);
	}
	
	function getId()
	{
		return $this->id;
	}
	
	function setId($id)
	{
		$this->id = $id;
	}

	
	function getIp()
	{
		return $this->ip;
	}

	function setIp($ip)
	{
		$this->ip = $ip;
	}

	
		function getMac()
	{
		return $this->mac;
	}

	function setMac($mac)
	{
		$this->mac = $mac;
	}
}
?>