<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/

//Ce fichier permet de gerer vos donnees en provenance de la base de donnees

//Il faut changer le nom de la classe ici (je sens que vous allez oublier)
class Home_Check extends SQLiteEntity{

	public $name;
    public $description;
    public $imei;
    public $id;
    public $state; //Pour rajouter des champs il faut ajouter les variables ici...
	public $isadmin;
	public $password;
	public $nummobile;
	public $alarm;
	public $email;
	public $ip;
	public $isclientserv;
	public $location;
	
	protected $TABLE_NAME = 'plugin_Home_Check'; 	//Penser a mettre le nom du plugin et de la classe ici
	protected $CLASS_NAME = 'Home_Check';
	protected $object_fields =
    array( // Ici on définit les noms des champs sql de la table et leurs types
        'name'=>'string',
        'imei'=>'string',
        'description'=>'string',
        'icon'=>'string',
        'isadmin'=>'int',
		'password'=>'int',
        'state'=>'int',
		'alarm'=>'int',
		'isclientserv'=>'int',
		'nummobile'=>'string',
		'email'=>'string',
		'ip'=>'string',
		'location'=>'string',
        'id'=>'key'
        );
	
	function __construct(){
		parent::__construct();
	}
//Methodes pour recuperer et modifier les champs (set/get)
	function setId($id){
		$this->id = $id;
	}
	
	function getId(){
		return $this->id;
	}

	function getString(){
		return $this->string;
	}

	function setString($string){
		$this->string = $string;
	}

	function getInteger(){
		return $this->integer;
	}

	function setInteger($integer){
		$this->integer = $integer;
	}

}

?>
