<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/

class AlarmeRelay extends SQLiteEntity
{
	public $IPadress;
	public $state;
	public $onCommand;
	public $offCommand;
	public $stopCommand;
	public $isSwitch;
	public $iddevice;
	public $macaddr;
	public $st1;
	public $st2;
	public $st3;
	public $st4;
	public $st5;
	public $st6;
	protected $TABLE_NAME = 'plugin_AlarmeRelay';
	protected $CLASS_NAME = 'AlarmeRelay';
	protected $object_fields = 
	array(
		'id'=>'key',
		'description'=>'string',
		'state'=>'int',
		'room'=>'int',
		'icon'=>'string',
		'IPadress'=>'string',
		'onCommand'=>'string',
		'offCommand'=>'string',
		'stopCommand'=>'string',
		'isSwitch'=>'int',
		'iddevice'=>'int',
		'macaddr'=>'string',
		'st1'=>'string',
		'st2'=>'string',
		'st3'=>'string',
		'st4'=>'string',
		'st5'=>'string',
		'st6'=>'string',
	);

	
	function __construct($tag="rw")
	{
		parent::__construct($tag);
	}
	
	function getId()
	{
		return $this->id;
	}
	
	function setId($id)
	{
		$this->id = $id;
	}
	
	function getType()
	{
		return $this->type;
	}

	function setType($type)
	{
		$this->type = $type;
	}
	
		function getDescription()
	{
		return $this->description;
	}

	function setDescription($description)
	{
		$this->description = $description;
	}
	
	
	function getNumGPIO()
	{
		return $this->numGPIO;
	}

	function setNumGPIO($numGPIO)
	{
		$this->numGPIO = $numGPIO;
	}
}
?>