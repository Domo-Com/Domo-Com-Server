<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/

class AlarmeGPIO extends SQLiteEntity
{
	protected $TABLE_NAME = 'plugin_AlarmeGPIO';
	protected $CLASS_NAME = 'AlarmeGPIO';
	protected $object_fields = 
	array(
		'id'=>'key',
		'descriptionGPIO'=>'string',
		'numGPIO'=>'int',
		'stateGPIO'=>'int'
	);

	
	function __construct($tag="rw")
	{
		parent::__construct($tag);
	}
	
	function getId()
	{
		return $this->id;
	}
	
	function setId($id)
	{
		$this->id = $id;
	}
	
		function getDescriptionGPIO()
	{
		return $this->descriptionGPIO;
	}

	function setDescriptionGPIO($descriptionGPIO)
	{
		$this->descriptionGPIO = $descriptionGPIO;
	}
	
	
	function getNumGPIO()
	{
		return $this->numGPIO;
	}

	function setNumGPIO($numGPIO)
	{
		$this->numGPIO = $numGPIO;
	}
	
	function getStateGPIO()
	{
		return $this->stateGPIO;
	}

	function setStateGPIO($stateGPIO)
	{
		$this->stateGPIO = $stateGPIO;
	}

	
	
}
?>