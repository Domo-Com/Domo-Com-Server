<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/

class AlarmeConf extends SQLiteEntity
{
	protected $TABLE_NAME = 'plugin_AlarmeConf';
	protected $CLASS_NAME = 'AlarmeConf';
	protected $object_fields = 
	array(
		'id'=>'key',
		'conf'=>'string',
		'value'=>'string'
	);
	
	function __construct($tag="rw")
	{
		parent::__construct($tag);
	}
	
	function getId()
	{
		return $this->id;
	}
	
	function setId($id)
	{
		$this->id = $id;
	}
	
	function getConf()
	{
		return $this->conf;
	}

	function setConf($conf)
	{
		$this->conf = $conf;
	}
	
	function getValue()
	{
		return $this->value;
	}

	function setValue($value)
	{
		$this->value = $value;
	}
}
?>