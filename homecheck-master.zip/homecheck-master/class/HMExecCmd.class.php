<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/

class ExecCmd extends SQLiteEntity 
{
	public $id;
	public $description;
	public $cmdline;
	public $ulr;
	public $pid;
	public $delay;
	public $typ;
	public $pic;
	public $status;
	public $st1;
	public $st2;
	public $st3;
	public $st4;
	
	protected $TABLE_NAME = 'plugin_ExecCmd';
	protected $CLASS_NAME = 'ExecCmd';
	protected $object_fields = 
	array(
		'id'=>'key',
		'description'=>'string',
		'cmdline'=>'string',
		'url'=>'string',
		'pid'=>"string",
		'delay'=>"int",
		'pic'=>"string",
		'typ'=>"int",
		'status'=>"string",
		'st1'=>"string",
		'st2'=>"string",
		'st3'=>"string",
		'st4'=>"string",
	);
	
    function __construct($tag="rw")
	{
		parent::__construct($tag);
	}
    
    function check_if_running($pid){
        $command = 'ps -p '.$pid;
        exec($command,$op);
        if (!isset($op[1]))echo "FALSE";
        else echo "True!";
    }
    public function status($pid){
        $command = 'ps -p '.$pid;
        exec($command,$op);
        if (!isset($op[1]))return false;
        else return true;
    }
    
    public function stop($pid){
        $command = 'kill '.$pid;
        exec($command);
        if ($this->status($pid) == false)echo "TRUE";
        else echo "FALSE";
    }
    
    public function runCom($commandToRun){
        //$command = 'nohup '.$commandToRun.' > /dev/null 2>&1 & echo $!';
		$pid=exec($commandToRun . ' > /dev/null 2>&1 & echo $!'); 
		
        //exec($command ,$op);
        //return (int)$op[0]; //Return PID
		return (int) $pid;
    }
    
    public function launch($cmd){
		
        //python command
        $command = $cmd;
        $processID = $this->__runCom($command);
        echo "Current PID: " . $processID;
        
    }
}
?>