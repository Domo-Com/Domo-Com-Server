<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/

class ActionGroup extends SQLiteEntity
{
	public $IPadress;
	public $state;
	public $onCommand;
	public $offCommand;
	public $stopCommand;
	public $isSwitch;
	public $iddevice;
	public $macaddr;
	public $st1;
	public $st2;
	public $st3;
	public $st4;
	public $st5;
	public $st6;
	protected $TABLE_NAME = 'plugin_actiongroup';
	protected $CLASS_NAME = 'ActionGroup';
	protected $object_fields = 
	array(
		'id'=>'key',
		'description'=>'string',
		'state'=>'int',
		'room'=>'int',
		'icon'=>'string',
		'IPadress'=>'string',
		'onCommand'=>'string',
		'offCommand'=>'string',
		'stopCommand'=>'string',
		'isSwitch'=>'int',
		'iddevice'=>'int',
		'macaddr'=>'string',
		'st1'=>'string',
		'st2'=>'string',
		'st3'=>'string',
		'st4'=>'string',
		'st5'=>'string',
		'st6'=>'string',
	);

	
	function __construct($tag="rw")
	{
		parent::__construct($tag);
	}
	
	function getId()
	{
		return $this->id;
	}
	
	function setId($id)
	{
		$this->id = $id;
	}
	
}
?>