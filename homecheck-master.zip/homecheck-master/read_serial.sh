#!/bin/sh
if ps -ef | grep -v grep | grep read_serial.py ; then
        exit 0
else
        sudo python /var/www/yana-server/plugins/HomeCheck/read_serial.py &
        exit 0
fi

