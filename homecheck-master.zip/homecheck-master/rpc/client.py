"""
This is an example RPC client that connects to the RPyC based scheduler service.

It first connects to the RPyC server on localhost:12345.
Then it schedules a job to run on 2 second intervals and sleeps for 10 seconds.
After that, it unschedules the job and exits.
"""

from time import sleep
import optparse
import rpyc
import sys
import json
import HTMLParser
import urllib
import urllib2


def _method_info_from_argv(argv=None):
	"""Command-line -> method call arg processing.

	- positional args:
			a b -> method('a', 'b')
	- intifying args:
			a 123 -> method('a', 123)
	- json loading args:
			a '["pi", 3.14, null]' -> method('a', ['pi', 3.14, None])
	- keyword args:
			a foo=bar -> method('a', foo='bar')
	- using more of the above
			1234 'extras=["r2"]'  -> method(1234, extras=["r2"])

	@param argv {list} Command line arg list. Defaults to `sys.argv`.
	@returns (<method-name>, <args>, <kwargs>)
	"""
	cmd=argv[1].split(",")
	
	method_name, arg_strs = argv[0], cmd
	
	args = []
	kwargs = {}
	for s in arg_strs:
		if s.count('=') == 1:
			key, value = s.split('=', 1)
		else:
			key, value = None, s
		try:
			value = json.loads(value) 
		except ValueError:
			pass
		if key:
			kwargs[key] = value
		else:
			args.append(value)
	return method_name, args, kwargs
	
parser = optparse.OptionParser("client.py [options] cmdline")
parser.add_option("-a", "--add", type="int", dest="add",default=0)
parser.add_option("-l", "--list", type="int", dest="list",default=0)
parser.add_option("-d", "--delete", type="int", dest="delete",default=0)
parser.add_option("-g", "--moment", type="int", dest="get",default=0)
parser.add_option("-p", "--pause", type="int", dest="pause",default=0)
parser.add_option("-r", "--resume", type="int", dest="resume",default=0)


(options, args) = parser.parse_args()

conn = rpyc.connect('localhost', 12345)

if options.add:
	if options.add==1:
		method_name, args, kwargs = _method_info_from_argv(args)
		h = HTMLParser.HTMLParser()
		s = h.unescape(method_name)
		#print method_name, args, kwargs
		job = conn.root.add_job('server:print_text', 'cron', args=[s], **kwargs)
		print job.id

	elif options.add==2:
		try:
			pic=args[2] # light level
			relaysrc=args[3] # source id to mesure light
			argi=args[:2]
			
			method_name, args, kwargs = _method_info_from_argv(argi)
			h = HTMLParser.HTMLParser()
			s = h.unescape(method_name)
			
			#method_name=args[0] #url of action to exe
			#cmd=args[1] # cron info

			job = conn.root.add_job('server:action_lumi', 'cron', args=[s,pic,relaysrc], **kwargs)
			print job.id
		except Exception as e:
			command = "http://127.0.0.1:8080/action.php?action=FonctionLog&log=error"
			urllib2.urlopen(command)
			
if options.list:
	print conn.root.get_jobs()
	
if options.delete:
	jobid=args[0]
	conn.root.remove_job(jobid)

if options.get:
	jobid=args[0]
	job=conn.root.get_job(jobid)
	print job.next_run_time 

if options.pause:
	jobid=args[0]
	job=conn.root.pause_job(jobid)
	print job.id
	
if options.resume:
	jobid=args[0]
	job=conn.root.resume_job(jobid)