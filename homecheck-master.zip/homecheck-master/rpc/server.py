"""
This is an example showing how to make the scheduler into a remotely accessible service.
It uses RPyC to set up a service through which the scheduler can be made to add, modify and remove
jobs.

To run, first install RPyC using pip. Then change the working directory to the ``rpc`` directory
and run it with ``python -m server``.

https://apscheduler.readthedocs.io/en/stable/userguide.html

"""
import time
import os
import tempfile
import urllib
import urllib2
import datetime
import sys
import time
import rpyc
from rpyc.utils.server import ThreadedServer
import HTMLParser
from apscheduler.schedulers.background import BackgroundScheduler
import logging
import urllib
import cgi
from logging.handlers import RotatingFileHandler



level=logging.WARNING
cwd = tempfile.gettempdir()
curdir=os.path.dirname(os.path.realpath(__file__))
alog=os.path.join(curdir, 'cronjob.log')

logging.basicConfig(filename=alog,level=level)
logging.getLogger('googleapiclient.discovery_cache').setLevel(logging.WARNING)

Rthandler = RotatingFileHandler(alog, maxBytes=1000000,backupCount=1)
Rthandler.setLevel(level)
formatter = logging.Formatter('%(asctime)-12s [%(levelname)s] %(message)s')  
Rthandler.setFormatter(formatter)

logging.getLogger('').addHandler(Rthandler)

# creation d un second handler qui va rediriger chaque ecriture de log
# sur la console
#stream_handler = logging.StreamHandler()
#stream_handler.setLevel(level)
#logger.addHandler(stream_handler)

'''
start server with  sudo python -m server &
'''

def my_listener(event):
    if event.exception:
        print('The job crashed :(')
    else:
        print('The job worked :)')

def action_lumi(action,threshold,modsrc):
	#url|threshold|modsrc

	#print action,threshold,modsrc
	logging.warning('Start at %s',datetime.datetime.now())
	
	try:
		lumi=0
		tmp=threshold.split("_")
		pic=int(tmp[1])
		side=tmp[0]

		#update lumi
		command = "http://127.0.0.1:8080/action.php?action=HomeCheck_GetTemp"
		json_commands = urllib2.urlopen(command)
		
		time.sleep(10)
		# get the lumi
		command = "http://127.0.0.1:8080/action.php?action=HomeCheck_GetPicModule&id="+modsrc

		lumi = urllib2.urlopen(command).read()
		h = HTMLParser.HTMLParser()
		lumi = h.unescape(lumi)
		lumi=int(lumi)
		logging.warning('Action ask pic %s %s Lumi %s' %(pic,side,lumi))
		
		gogo=False
		if side.upper()=="UP":
			if lumi>pic:
				gogo=True
		elif side.upper()=="DOWN":
			if lumi<pic:
				gogo=True
		
		if gogo==True:
			action=action+"&mode=AUTO"
			logging.warning('action Lumi %s',action)
			command = "http://127.0.0.1:8080/action.php"+action
			json_commands = urllib2.urlopen(command)
			#logging.warning(json_commands)
			
			ini=action.find("action=")
			end=action.find("token")
			s=action.replace("&"," ")
			s="Auto "+s[ini:end-1]
			s=urllib.quote(s)
			command = "http://127.0.0.1:8080/action.php?action=FonctionLog&log="+s
			json_commands = urllib2.urlopen(command)
			
		logging.warning('End at %s',datetime.datetime.now())
	
	except Exception as e:
		#h = HTMLParser.HTMLParser()
		ini=action.find("action=")
		end=action.find("token")
		#s=action[ini:end]
		#s=s.encode('utf-8')
		logging.warning('Error %s',e) 
		logging.error(str(sys.exc_info()))

			
def print_text(action):
	logging.warning('Start at %s',datetime.datetime.now())
	logging.warning('action prog %s',action)
	action=action+"&mode=AUTO"
	command = "http://127.0.0.1:8080/action.php"+action
	try:
		json_commands = urllib2.urlopen(command)
		
		ini=action.find("action=")
		end=action.find("token")
		s=action.replace("&"," ")
		s="Auto "+s[ini:end-1]
		s=urllib.quote(s)
		command = "http://127.0.0.1:8080/action.php?action=FonctionLog&log="+s
		json_commands = urllib2.urlopen(command)
	#Handle invalid IP
	except IOError, e:
		logging.warning('Error %s',e) 
		logging.error(str(sys.exc_info()))
		
	logging.warning('End at %s',datetime.datetime.now())

class SchedulerService(rpyc.Service):
    def exposed_add_job(self, func, *args, **kwargs):
        return scheduler.add_job(func, *args, **kwargs)

    def exposed_modify_job(self, job_id, jobstore=None, **changes):
        return scheduler.modify_job(job_id, jobstore, **changes)

    def exposed_reschedule_job(self, job_id, jobstore=None, trigger=None, **trigger_args):
        return scheduler.reschedule_job(job_id, jobstore, trigger, **trigger_args)

    def exposed_pause_job(self, job_id, jobstore=None):
        return scheduler.pause_job(job_id, jobstore)

    def exposed_resume_job(self, job_id, jobstore=None):
        return scheduler.resume_job(job_id, jobstore)

    def exposed_remove_job(self, job_id, jobstore=None):
        scheduler.remove_job(job_id, jobstore)

    def exposed_get_job(self, job_id):
        return scheduler.get_job(job_id)

    def exposed_get_jobs(self, jobstore=None):
        return scheduler.get_jobs(jobstore)
	def exposed_add_listener(self,func, *args):
		return scheduler.add_listener(func,*args)

if __name__ == '__main__':
    scheduler = BackgroundScheduler()
    url = 'sqlite:///db.sqlite'
    scheduler.add_jobstore('sqlalchemy', url=url)
    scheduler.start()
    #scheduler.add_listener(my_listener, "mask=EVENT_ALL")
    protocol_config = {'allow_public_attrs': True}
    server = ThreadedServer(SchedulerService, port=12345, protocol_config=protocol_config)
    try:
        server.start()
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        scheduler.shutdown()
