#!/bin/bash

git pull
sudo chown www-data:www-data *
sudo chmod 775 *
