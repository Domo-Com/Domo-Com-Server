#!/bin/sh

git pull
sudo chown -R www-data:www-data *
sudo chmod -R 775 *
sudo usermod -a -G video www-data
sudo echo 'SUBSYSTEM=="vchiq",GROUP="video",MODE="0660"' > /etc/udev/rules.d/10-vchiq-$
sudo apt-get install php7.0-gd
sudo apt-get -y install curl
sudo apt-get -y install gpac
sudo apt-get -y install php-curl
sudo pip install yeelight
sudo pip install python-Levenshtein
sudo apt-get install nmap
sudo apt-get install arp-scan
sudo pip install apscheduler
sudo pip install rpyc
cd /var/www/yana-server/plugins/HomeCheck/rpc/
sudo python -m server &

