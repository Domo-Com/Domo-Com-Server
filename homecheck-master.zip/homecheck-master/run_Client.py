#!/usr/bin/env python
# -*-coding:Utf-8 -*
import time
import socket
import os
import sys
import optparse
import shutil
import ConfigParser
import urllib2
import json
import signal

def handler(signum, frame):
	print "Forever is over!"
	raise Exception("end of time")

# Register the signal function handler
signal.signal(signal.SIGALRM, handler)
# Define a timeout for your function
signal.alarm(20)

parser = optparse.OptionParser("client.py [options] command")
parser.add_option("-d", "--dest", type="string", dest="client")
parser.add_option("-r", "--type", type="string", dest="relay")
    
(options, args) = parser.parse_args()
if len(args) != 1:
	parser.print_help()
	parser.error("incorrect number of arguments")

command = args[0]
isrelay=False
#command="test avec é"
command=command.decode('utf8')
print command.encode('utf8') 

if options.client:
	dest=options.client
else:
	exit(0)
if options.relay:
	isrelay=True
	relayTyp=options.relay

if not isrelay:
	port = 2048
	socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

	print "Connection on "+str(port)
	socket.connect((dest, port))
	socket.send(command.encode('utf-8'))

	socket.close()
	print "Close"
else:
	if relayTyp=="1":
		url = "http://"+dest+"/{{"+command+"}}"
	elif relayTyp=="2":
		url = "http://"+dest+"/"+command
	else:
		print("unknown")
	try:
		json_commands = urllib2.urlopen(url)
		print url
	except IOError, e:
		print("Invalid")
	except Exception, exc: 
		print exc

def deadline(timeout, *args):
	"""is a the decotator name with the timeout parameter in second"""
	def decorate(f):
		""" the decorator creation """
		def handler(signum, frame):
			""" the handler for the timeout """
			raise TimeoutException() #when the signal have been handle raise the exception
			
		def new_f(*args):
			""" the initiation of the handler, 
			the lauch of the function and the end of it"""
			signal.signal(signal.SIGALRM, handler) #link the SIGALRM signal to the handler
			signal.alarm(timeout) #create an alarm of timeout second
			res = f(*args) #lauch the decorate function with this parameter
			signal.alarm(0) #reinitiate the alarm
			return res #return the return value of the fonction
    
		new_f.__name__ = f.__name__
		return new_f


