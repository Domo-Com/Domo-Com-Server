#!/usr/bin/python
# -*-coding:Utf-8 -*
# https://sourceforge.net/p/raspberry-gpio-python/wiki/Examples/

import optparse
import shutil
import ConfigParser
import time
import os
import tempfile
import urllib
import urllib2
import datetime
import sys
import RPi.GPIO as GPIO


parser = optparse.OptionParser("run_gpio.py [options] command")
parser.add_option("-g", "--gpio", type="int", dest="gpio")

(options, args) = parser.parse_args()

command = args[0]  #LOW or HIGH
if options.gpio:
	numgpio=options.gpio
else:
	exit(0)

GPIO.setwarnings(False)

GPIO.setmode(GPIO.BCM)
GPIO.setup(numgpio,GPIO.OUT)

if command=="HIGH":
	GPIO.output(numgpio,GPIO.HIGH)
	print("HIGH")
elif command=="LOW":
	GPIO.output(numgpio,GPIO.LOW)
	print("LOW")
else:
	print("unknown")