#include <stdio.h>
#include <stdlib.h>
#include <sstream> 
#include <sys/wait.h>

/*
Par Alexandre Rault (alex.rault@laposte.net)
Licence : CC by nc sa
Version: 1

Programme pour arréter les interrupt des GPIO et aisni désactiver l'alarme.

Le programme est compilable avec la commande : 
g++ AlarmeStop.cpp -o AlarmeStop
sudo chown root:www-data AlarmeStop
sudo chmod 4777 AlarmeStop
 */

 
using namespace std;

int main(void) 
{
	if (setuid(0))
    {
        perror("setuid");
        return 1;
    }
	system("pkill AlarmeDetector");
	system("killall AlarmeDetector");
}