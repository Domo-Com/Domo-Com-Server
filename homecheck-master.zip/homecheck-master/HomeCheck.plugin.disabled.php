<?php
/*
@name Home_Check
@author alex f <contact@domo-com.fr>
@link http://domo-com.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/


define("SensorPresence", 1);
define("SensorOuverture", 2);
define("SensorInter", 3);
define("Relai433", 0);
define("DomoSwitch", 1);
define("RelaiAlarme", 2);
define("RelaiInter", 3);
define("RelaiGSM", 4);
define("Weelight", 5);
define('DEBUG', false);

require_once(dirname(__FILE__).'/class/HMalarmePeople.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeSensor.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeRelay.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeSensorRadio.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeSMS.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeEmail.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeGPIO.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeActionVocal.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeCommandeVocale.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeURL.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeShell.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeConf.class.php');
require_once(dirname(__FILE__).'/class/HMExecCmd.class.php');
require_once(dirname(__FILE__).'/class/HMCamera.class.php');
require_once(dirname(__FILE__).'/class/HMActionGroup.php');
require_once(dirname(__FILE__).'/class/HMActionCollection.php');
require_once(dirname(__FILE__).'/class/HMdetectIp.class.php');
require_once(dirname(__FILE__).'/qrcode/qrlib.php');
require_once(dirname(__FILE__).'/UIfunc.php');


$myVar=1;
//Création des commandes vocales d'activation ou de désactivation de l'alarmefunction Plugin_SwitchWireVocal_vocal_command(&$response,$actionUrl)

function Plugin_Alarme_vocal_command(&$response,$actionUrl)
{
	global $conf;
	$alarme_Manager = new AlarmeCommandeVocale("r");
	$alarmes = $alarme_Manager->populate();

	if($alarmes!= null)
	{
		foreach($alarmes as $alarme)
		{
			$response['commands'][] = array(
			'command'=>$conf->get('VOCAL_ENTITY_NAME').' '.htmlspecialchars_decode($alarme->getCommande(),ENT_QUOTES),
			'callback'=>'plugin_alarme_vocal_action',
			'parameters' => array(	"Type"=>$alarme->getType()),
			'url'=>$actionUrl.'?action=plugin_alarme_vocal_action&webservice=true&Type='.$alarme->getType(),
			'confidence'=>(float)$alarme->getConfidence());
		}
	}
	
	// sensor radio
	$genericRadioManager = new AlarmeSensorRadio();

    $genericRadios = $genericRadioManager->populate();
    foreach ($genericRadios as $genericRadio) {
		if (!$genericRadio->isalarm) {
			if (!empty($genericRadio->onCommand)) {
				$response['commands'][] = array(
					'command'=>$genericRadio->onCommand,
					'url'=>$actionUrl.'?action=HomeCheckRadio_vocal_change_state&engine='.$genericRadio->id.'&state=1',
					'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
			}
			if (!empty($genericRadio->offCommand)) {
				$response['commands'][] = array(
					'command'=>$genericRadio->offCommand,
					'url'=>$actionUrl.'?action=HomeCheckRadio_vocal_change_state&engine='.$genericRadio->id.'&state=0',
					'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
			}
		}
    }
	// sensor wifi
	$genericRelayManager = new AlarmeRelay();

    $genericRelays = $genericRelayManager->populate();
    foreach ($genericRelays as $genericRelay) {
		
		if (!empty($genericRelay->onCommand)) {
			$response['commands'][] = array(
				'command'=>$genericRelay->onCommand,
				'url'=>$actionUrl.'?action=HomeCheckRelay_vocal_change_state&engine='.$genericRelay->id.'&state=UP',
				'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
		}
		if (!empty($genericRelay->offCommand)) {
			$response['commands'][] = array(
				'command'=>$genericRelay->offCommand,
				'url'=>$actionUrl.'?action=HomeCheckRelay_vocal_change_state&engine='.$genericRelay->id.'&state=DOWN',
				'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
		}
		if (!empty($genericRelay->stopCommand)) {
			$response['commands'][] = array(
				'command'=>$genericRelay->stopCommand,
				'url'=>$actionUrl.'?action=HomeCheckRelay_vocal_change_state&engine='.$genericRelay->id.'&state=STOP',
				'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
		}
    }
	
	// group command

	$groupActionManager = new ActionGroup();
    $groupActions = $groupActionManager->populate();
    foreach ($groupActions as $groupAction) {
		
		if (!empty($groupAction->onCommand)) {
			$response['commands'][] = array(
				'command'=>$groupAction->onCommand,
				'url'=>$actionUrl.'?action=HomeCheckGroup_vocal_change_state&engine='.$groupAction->id.'&state=UP',
				'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
		}

		if (!empty($groupAction->offCommand)) {
			$response['commands'][] = array(
				'command'=>$groupAction->offCommand,
				'url'=>$actionUrl.'?action=HomeCheckGroup_vocal_change_state&engine='.$groupAction->id.'&state=DOWN',
				'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
		}
		if (!empty($groupAction->stopCommand)) {
			$response['commands'][] = array(
				'command'=>$groupAction->stopCommand,
				'url'=>$actionUrl.'?action=HomeCheckGroup_vocal_change_state&engine='.$groupAction->id.'&state=STOP',
				'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
		}
    }
	
	// gpio command
	
	$gpio_Manager = new AlarmeSensor();
	$gpioActions = $gpio_Manager->populate();

    foreach ($gpioActions as $gpioAction) {
		
		if (!empty($gpioAction->onCommand)) {
			$response['commands'][] = array(
				'command'=>$gpioAction->onCommand,
				'url'=>$actionUrl.'?action=HomeCheckGpio_vocal_change_state&engine='.$gpioAction->id.'&state=HIGH',
				'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
		}

		if (!empty($gpioAction->offCommand)) {
			$response['commands'][] = array(
				'command'=>$gpioAction->offCommand,
				'url'=>$actionUrl.'?action=HomeCheckGpio_vocal_change_state&engine='.$gpioAction->id.'&state=LOW',
				'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
		}
    }
	
	// miscelaneous
	$response['commands'][] = array(
				'command'=>"Etat des lieux",
				'url'=>$actionUrl.'?action=HomeCheckRelay_vocal_statehome',
				'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
	
	$response['commands'][] = array(
				'command'=>"météo",
				'url'=>$actionUrl.'?action=HomeCheck_vocal_weatherhome',
				'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
				
}

//Appel du nouveau client vocal, suite commande vocale activation ou désactivation
function plugin_alarme_vocal_action ($text,$confidence,$parameters,$myUser)
{
	switch ($parameters["Type"])
	{
		//Les actions suite au retour vocal
		case "On":
			Plugin_Alarme_Activation();

			break;
		
		case "Off":
			Plugin_Alarme_Desactivation();
			break;
	}
}

//Lancement de la routine, 
function Plugin_Alarme_Activation($src="none")
{
	$alarme_conf = new AlarmeConf();
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));
	$alarme_conf->setValue("1");
	$alarme_conf->save();

	//On stop les programme de detections
	plugin_alarme_load_stopSensor_GPIO();

	//relance des sensor mode AD (activation ou désactivation par GPIO)
	$alarme_Manager = new AlarmeSensor("r");
	$alarmes = $alarme_Manager->loadAll(array('type'=>'SensorADGPIO'));
	foreach($alarmes as $alarme)
	{
		plugin_alarme_load_sensor_GPIO($alarme->getNumGPIO(),0,0);
	}
	

	//lancement des sensor mode sensor (Détecteur branché sur GPIO)
	$alarme_Manager = new AlarmeSensor("r");
	$alarmes = $alarme_Manager->loadAll(array('type'=>'SensorGPIO'));
	
	$alarme_conf = new AlarmeConf("r");
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_timetoStart"));
	
	foreach($alarmes as $alarme)
	{
		plugin_alarme_load_sensor_GPIO($alarme->getNumGPIO(),$alarme_conf->getValue(),1);
	}
	
	if ($src!="domo") {
		HomeCheck_plugin_SendCli("action","startalarm");
		HomeCheck_plugin_SendGSM("action","startalarm");
	}
	return $erreur;
}

//Fonction appelée sur detection de presence
function Plugin_Alarme_Start_Action($Id=0,$MessageAlerte="alert GPIO")
{	
// Domocom attend plugin_alarme_Start avant de declencher les actions alarmes
	$param_conf = new AlarmeConf();
	
	$alarme_conf = $param_conf->load(array("conf"=>"plugin_alarme_Start"));
	$isalarmeActive=$alarme_conf->getValue();
	
	$alarme_confCli = $param_conf->load(array("conf"=>"Plugin_Alarme_Cli"));
	$alarmeActiveCli=$alarme_confCli->getValue();
	
	$alarme_Manager = new AlarmeSensorRadio("r");
	$alarme = $alarme_Manager->load(array('type'=>'SensorTXRADIO','id'=>$Id));
	
	if ($alarme->sensorTxTyp==SensorInter) { //inter
		$linkr=$alarme->linkradio;
		if (!empty($linkr) && $linkr!=-1) {
			$typsensor=$alarme->sensorTxTyp;
			Functions::log('Link inter  : '.$typsensor." ".$linkr);
			HomeCheck_Link_Action($linkr);
		}
		return;
	}
	Functions::log('On Detect Alarm Active : '.$isalarmeActive);
	if ($isalarmeActive=="1") {
		$isathome=HomeCheck_whois(1);
		if ($isathome==0) {	
			Functions::log('Alarm down counter:');
			HomeCheck_send_notification("Alert Alarm Detection","detect","Alert");
			$alarme_conf->setValue("21");
			$alarme_conf->save();
			$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_timetoStart"));
			$delay=$alarme_conf->getValue();
			
			//HomeCheck_plugin_SendCli("action",$MessageAlerte);
			//HomeCheck_plugin_SendGSM("action",$MessageAlerte);
			$cmd='python '.dirname(__FILE__).'/run_StartAlarm.py '.$delay;
			exec($cmd . " > /dev/null &"); 	
		}
		else if ($alarme->sensorTxTyp==2 and $alarmeActiveCli!=1) {
			HomeCheck_plugin_SendCli("info","Sensor ".$alarme->description." opened ");
			HomeCheck_plugin_SendGSM("info","Sensor ".$alarme->description." opened ");
		}
	}
	
	if ($alarmeActiveCli==1) {
		if ($alarme->sensorTxTyp==2) {
			HomeCheck_plugin_SendGsm("HomeCheck Alert","Sensor ".$alarme->description." opened");	
			HomeCheck_plugin_SendCli("info","HomeCheck Alert");
			HomeCheck_plugin_SendCli("action","wake");
			HomeCheck_plugin_SendCli("info","Sensor ".$alarme->description." opened");	
		}
	}
	// active les relai liée
	Plugin_HomeCheck_LinkAction($Id);
	//
	//$cmd='python '.dirname(__FILE__).'/ExecCmd.py /usr/bin/backupcamip';
	//exec($cmd . " > /dev/null &"); 		
}

function Plugin_HomeCheck_LinkAction($Id)
{
	$alarme_conf = new AlarmeConf("r");
	$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_Pic"));	
	$pic=intval($alarme_res->getValue());
	
	$sensor_Manager = new AlarmeSensorRadio("r");
	$sensor = $alarme_Manager->load(array('type'=>'SensorTXRADIO','id'=>$Id));
	
	if ($sensor->lumi!=0 && $pic>$sensor->lumi) {
		Functions::log('Link command bypass : '.$sensor->lumi." current pic ".$pic);
		return;
	}
	
	$heure = date('H', time());
	$meridiem=date('a', time());
	$moded=get_conf_value("plugin_homecheck_modeday");
	
	if ($moded=='night') {
		Functions::log('Link command bypass at night');
		return;
	}
	else {
		$linkr=$sensor->linkradio;
		$typsensor=$sensor->sensorTxTyp;
		$pref=substr($linkr, 0, 2);
		$linkr=substr($linkr, 2);
		//todo manage relay wifi
		if (!empty($linkr) && $linkr!=-1) {
			if ($pref=="TX") { 
				$linkradio=$alarme_Manager->getById($linkr);
				
				// si pas activé par detecteur
				if ($linkradio->state!=1) {
					Functions::log('Link command : '.$linkradio->id." ".$linkradio->state);
					if ($linkradio->state==0) {
						HomeCheckradio_plugin_change_state($linkradio->getId(),2);
					}
					$delay=$sensor->getDelay();
					if (!empty($delay)) {
						Plugin_CheckAndStop($linkradio->getId(),$delay);
					}
				}
			}
			elseif ($pref=="RW") {  //wifi relay TODO
			}
		}
	}
}

function Plugin_CheckAndStop($idr,$delay) {
	
	$cmd_Manager = new ExecCmd();
	$cmdactive = $cmd_Manager->load(array("description"=>$idr));
	
	if (!empty($cmdactive)) {
		$pid=$cmdactive->pid;
		
		if ($cmdactive->status($pid)) {
			$cmdactive->stop($pid);
		}
		if ($delay==0) return;
		
		$cmd = $cmdactive->cmdline;		
		$command='python '.dirname(__FILE__).'/run_ExecCmd.py -d '.$delay.' -e '.$idr.' '.$cmd;
		$pid=$cmdactive->runCom($command); 
	
		$cmdactive->pid=$pid;
		$cmdactive->save();
	}
	else {
		echo 'new';
		$cmdactive=new ExecCmd();
		//$cmd='python '.dirname(__FILE__).'/ExecCmd.py -e -d cmd;
		
		$cmdactive->description=$idr;
		$cmd="HomeCheckRadio_manual_change_state";
		$cmdactive->cmdline=$cmd;
		$cmdactive->delay=$delay;
		$command='python '.dirname(__FILE__).'/run_ExecCmd.py -d '.$delay.' -e '.$idr.' '.$cmd;
		//echo $command;
		$pid=$cmdactive->runCom($command);
		$cmdactive->pid=$pid;
		$cmdactive->save();
	}
	
}
// Declenche les actions si alarme pas desactivee
function Plugin_Alarme_Active_Action($manual=0)
{
	global $conf;
	header('Content-Type: text/html; charset=utf-8');
	
	//Modification de la surveillance
	$param_conf = new AlarmeConf();
	$alarme_conf = $param_conf->load(array("conf"=>"plugin_alarme_Start"));
	$alarm_isactive=$alarme_conf->getValue();
	// Verifie que l'alarme est encore active
	if ($manual==0) {
		if ($alarm_isactive=="0") {
			Functions::log('Alarm System was deactivated');
			return "0";
		} 
	}
	
	Functions::log('Trigger Alarm System:');
	$alarme_conf->setValue("2");
	$alarme_conf->save();
	
	//echo "Surveillance toujours active <br>";
	$radioAlarmCode=1;
	$relayAlarmCode=2;
	if (DEBUG):
	  $radioAlarmCode=10;
	  $relayAlarmCode=20;
	endif;
	
	// action sur les alarmes radios
	$alarme_Manager = new AlarmeSensorRadio("r");
	$alarmes = $alarme_Manager->loadAll(array('type'=>'SensorRXRADIO','isalarm'=>$radioAlarmCode));
	
	foreach($alarmes as $alarme)
	{
		HomeCheckradio_plugin_change_state($alarme->id,1);
	}
	
	// action sur les alarmes relais wifi
	$alarme_Manager = new AlarmeRelay("r");
	$alarmes = $alarme_Manager->loadAll(array('isSwitch'=>$relayAlarmCode));
	
	foreach($alarmes as $alarme)
	{
		$code="_".$alarme->iddevice;
		HomeCheckrelay_plugin_change_state($alarme->id,"UP",0,$code);
	}
	
	//Bascule des GPIO
	$alarme_Manager = new AlarmeGPIO("r");
	$alarmesGPIO = $alarme_Manager->populate();
	foreach($alarmesGPIO as $alarme)
	{
		try
		{
			$numGPIO=(int)$alarme->getNumGPIO();
			$stateGPIO=(int)$alarme->getStateGPIO();
			Gpio::mode($numGPIO,'out');
			Gpio::write($numGPIO,$stateGPIO);
			echo 'GPIO numéro : '.$numGPIO.', Basculé à l\'état : '.$stateGPIO.'<br>';
		}
		catch (Exception $e) 
		{
			echo 'Erreur lors de la bascule du GPIO numéro : '.$numGPIO.', erreur : '.$e->getMessage().'<br>';
		}
	}
		
	//Execution des URL
	$alarme_Manager = new AlarmeURL("r");
	$alarmesURL = $alarme_Manager->loadAll(array('type'=>'ActionUrl'));
	foreach($alarmesURL as $alarme)
	{
		try
		{
			if (function_exists('curl_version'))
			{
				//Si CURL est activé, tester l'URL
				$url=htmlspecialchars_decode($alarme->getUrl(),ENT_QUOTES);
				$ch = curl_init();
				curl_setopt($ch,CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_TIMEOUT, 5);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				if(curl_exec($ch))
				{
					echo 'URL exécutée : '.$url;
					echo ', Retour de l\'URL :'.curl_multi_getcontent($ch).'<br>';
				}
				else
				{
					echo 'Erreur lors de l\'exécution de l\'URL : '.curl_error($ch);
					echo '. Code d\'erreur HTML: '.curl_getinfo($ch, CURLINFO_HTTP_CODE).'<br>';
				}
				curl_close($ch);
			}
			else
			{
				echo 'Impossible de tester l\'URL de Yana-Server, "cURL" manquant sur ce RPI <br>';
			}
		}
		catch (Exception $e) 
		{
			echo 'Erreur lors de l\'envoye de l\'email au destinataire : '.$alarme->getEmailAddr() .', erreur : '.$e->getMessage().'<br>';
		}
	}
	
		//Envoie alerte
	HomeCheck_send_notification("System Alarm Activated","alarm","Alert");
	HomeCheck_plugin_SendCli("action","alerte intrusion");
	HomeCheck_plugin_SendGSM("action","alerte intrusion");
	
	//Execution des commandes Shell
	$alarme_Manager = new AlarmeShell("r");
	$alarme_Shell=$alarme_Manager->populate();
	foreach($alarme_Shell as $alarme)
	{
		try
		{
			$Shell=htmlspecialchars_decode($alarme->getShell(),ENT_QUOTES);
			$returnString = system($Shell,$returnState);
			if (!$returnState)
			{
				echo 'Commande Shell : "'.$alarme->getShell() .'" exécutée avec succés : ';
				print_r($returnString);
				echo '<br>';
			}
			else
			{
				echo 'Erreur lors de l\'exécution de la commande shell : '.$alarme->getShell() .', erreur : ';
				print_r($returnString);
				echo '<br>';
			}
		}
		catch (Exception $e) 
		{
			echo 'Erreur lors de l\'exécution de la commande shell : '.$alarme->getShell() .', erreur : '.$e->getMessage().'<br>';
		}
	}
	
	//Envoi des medias
	$cmd='python '.dirname(__FILE__).'/run_ExecCmd.py /usr/bin/backupcamip';
	exec($cmd . " > /dev/null &"); 	
	
}

function Plugin_Alarme_Desactivation($src="none")
{
	global $_,$myUser;
	
	Functions::log('Alarm Deactivated:');
	$alarme_conf = new AlarmeConf();
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));
	$alarme_conf->setValue("0");
	$alarme_conf->save();
	
	//On stop les programmes de detections
	plugin_alarme_load_stopSensor_GPIO();
	//relance des sensor mode AD (activation ou désactivation par GPIO)
	$alarme_Manager = new AlarmeSensor("r");
	$alarmes = $alarme_Manager->loadAll(array('type'=>'SensorADGPIO'));
	foreach($alarmes as $alarme)
	{
		plugin_alarme_load_sensor_GPIO($alarme->getNumGPIO(),"0","0");
	}

	//Si l'alarme à été déclenchée, il faut stoper les GPIO activé lors du déclenchemrent 
	$alarme_Manager = new AlarmeGPIO("r");
	$alarmesGPIO = $alarme_Manager->populate();
	foreach($alarmesGPIO as $alarme)
	{
		$numGPIO=(int)$alarme->getNumGPIO();
		$stateGPIO=((int)$alarme->getStateGPIO()== 1) ? 0 : 1;
		Gpio::mode($numGPIO,'out');
		Gpio::write($numGPIO,$stateGPIO);
	}
	
	// action sur les alarmes radios
	
	$alarme_Manager = new AlarmeSensorRadio("r");
	$alarmes = $alarme_Manager->loadAll(array('type'=>'SensorRXRADIO','isalarm'=>1));
	
	foreach($alarmes as $alarme)
	{
		HomeCheckradio_plugin_change_state($alarme->id,0);
	}
	
	// action sur les alarmes relais wifi
	$alarme_Manager = new AlarmeRelay("r");
	$alarmes = $alarme_Manager->loadAll(array('isSwitch'=>2));
	
	foreach($alarmes as $alarme)
	{
		$code="_".$alarme->iddevice;
		HomeCheckrelay_plugin_change_state($alarme->id,"STOP",0,$code);
	}
	
	
	if ($src!="domo") {
		$token=htmlspecialchars_decode($myUser->getToken(),ENT_QUOTES);
		HomeCheck_plugin_SendCli("ident",$token);
		sleep(1);
		HomeCheck_plugin_SendCli("action","stopalarm");
	}
	return $erreur;
}

function plugin_alarme_setting_menu(&$menuItems)
{
	global $_;
	$menuItems[] = array('sort'=>10,'content'=>'<a href="index.php?module=Home_Check&block=ADAlarme&sousblock=AlarmeGeneral"><i class="fa fa-list"></i> Home_check</a>');
	
	//echo '<li '.((isset($_['module']) && ($_['module']=='Home_Check'))?'class="active"':'').'><a //href="index.php?module=Home_Check&block=ADAlarme&sousblock=AlarmeGeneral"><i class="fa fa-angle-right"></i> //Home_Check </a></li>';
}

// exec action from linkid
function HomeCheck_Link_Action($linkid=0,$state="NONE",$auto=0) {	

	//Functions::log('Link inter  : '.$typsensor." ".$linkr);
	$pref=substr($linkid, 0, 2);
	$linkr=substr($linkid, 2);
	if (!empty($linkr) && $linkr!=-1) {
		if ($pref=="TX") { 
			//$sensor_Manager = new AlarmeSensorRadio("r");
			//$sensor = $sensor_Manager->getById($linkr);
			echo $sensor->description;
			if ($state!="NONE") {
				$action=($state=="UP" ? 1: 0);
			}
			else {
				$action=($sensor->state== 1 ? 0 : 1);
			}
			HomeCheckradio_plugin_change_state($linkr,$action);
		}
		elseif ($pref=="RW") {  //wifi relay
			$relay_Manager = new AlarmeRelay("r");
			$relay = $relay_Manager->getById($linkr);
			//Functions::log('Link Act: '.$relay->isSwitch." ".$state);
			if ($state!="NONE") {
				if ($relay->isSwitch!=1 && $state=="DOWN") $state="STOP";//3 pos only for domoswitch
				$action=$state;
			}
			else {
				$action=$relay->state== "1" ? "UP" : "DOWN";
			}
			//Functions::log('Action inter  : '.$relay->description." state ".$relay->state." action ".$action);
			HomeCheckRelay_plugin_change_state($linkr,$action,$auto,0);
		}
	}
	return;
}
	
	
	
//case action
function plugin_alarme_action()
{
	global $_,$myUser,$conf;
	switch($_['action'])
	{
		//Declenchement appel URL des actions d'alarme par 
		//Save ID
		
		case 'HomeCheck_GetParams':
			
			global $_,$myUser;
			
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r")) {
				$alarme_conf = new AlarmeConf("r");
				$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_DriveDirectory"));
				$DriveDirectory = $alarme_res->getValue();
				$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_RepoDirectory")); 
				$RepoDirectory = $alarme_res->getValue();
				$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_StoreDirectory"));
				$StoreDirectory = $alarme_res->getValue();
				$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_SendSms"));
				$send_sms = $alarme_res->getValue()=="Yes" ? "True":"False";
				$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_SendEmail"));
				$send_email = $alarme_res->getValue()=="Yes"?"True":"False";
				
				$alarme_Manager = new AlarmeEmail("r");
				$alarmes = $alarme_Manager->populate();
				foreach($alarmes as $alarme) { 
					$emailcc=$emailcc.$email.$alarme->getEmailExp().","; 
				}
				
				$People_Manager = new Home_Check("r");
				$Home_Check = $People_Manager->load(array('isadmin'=>1));
				$email=$Home_Check->email;
				
				$HomeCheckManager = new Home_Check("r");
	
				$HomeCheckserv = $HomeCheckManager->load(array('isclientserv'=>1));
				$smsip=$HomeCheckserv->ip;
		
				$alarme_Manager = new AlarmeSMS("r");
				$alarmes = $alarme_Manager->populate();
				foreach($alarmes as $alarme) {	
					$freeid=$alarme->getIdentifiant_user(); 
					$freepass=$alarme->getIdentifiant_mdp();
					$smsmsg=htmlspecialchars_decode('alerte:'.$alarme->getMessage(),ENT_QUOTES);
				}
				
				$alarmstatus=1; //HomeCheck_alarmStatus();
				$nbpeo=HomeCheck_whois(1);
				
				try {
					$response['response'][0]['root_folder'] =$DriveDirectory ;
					$response['response'][0]['import_file_path'] =$RepoDirectory;
					$response['response'][0]['archive_path'] = $StoreDirectory;
					$del=!empty($StoreDirectory) ? "False" : "True";
					$response['response'][0]['delete_file'] =$del;
					$response['response'][0]['freeid'] =$freeid;
					$response['response'][0]['freepass'] =$freepass;
					$response['response'][0]['send_email'] =$send_email;
					$response['response'][0]['issms'] =$send_sms;
					$response['response'][0]['smsip'] =$smsip;
					$response['response'][0]['smsmsg'] =$smsmsg;
					$response['response'][0]['recipient'] =$email;
					$response['response'][0]['recipientcc'] =$emailcc;
					$response['response'][0]['alarm_status'] =(int)$alarmstatus;
					$response['response'][0]['nbpeo_home'] =$nbpeo;
					
					
				} catch (Exception $e) {
					$response['response'][0]['result'] = $e->getMessage();
				}
				$json = json_encode($response);
				echo ($json=='[]'?'{}':$json);
			}
            break;
		
		case 'HomeCheck_GetSecurParams':
			
			global $_,$myUser;
			
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r")) {
				$alarme_conf = new AlarmeConf();
				$alarme_act = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));
				$alarmeActive=$alarme_act->getValue();
				$alarme_confCli = $alarme_conf->load(array("conf"=>"Plugin_Alarme_Cli"));
				$alarmeActiveCli=$alarme_confCli->getValue();
				
				$alarme_delayconf = $alarme_conf->load(array("conf"=>"plugin_alarme_timetoStart"));
				$delay=$alarme_delayconf->getValue();
			
				$People_Manager = new Home_Check("r");
				$user = $People_Manager->load(array('isadmin'=>1));
				$uuid=$user->imei;
				
				// alarm_active 0: OFF / 1 : system alarm monitoring on  / 2 alarm triggered
				// alarmeActiveCli 1 : notif on / 0 off
				try {
					$response['response'][0]['alarm_active'] =$alarmeActive;
					$response['response'][0]['alarm_delay'] =$delay;
					$response['response'][0]['notif_active'] =$alarmeActiveCli;
					$response['response'][0]['admin_id'] =$uuid;
				} catch (Exception $e) {
					$response['response'][0]['result'] = $e->getMessage();
				}
				$json = json_encode($response);
				echo ($json=='[]'?'{}':$json);
			}
            break;
		case 'HomeCheck_SetSecurParams':
			
			global $_,$myUser;
			
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r")) {
				
				$alarmeActive=($_['alarm_active']);
				$alarmeActiveCli=($_['notif_active']);
				$alarmDelay=($_['alarm_delay']);
				save_conf("plugin_alarme_Start",$alarmeActive);
				
				if (isset($alarmeActiveCli)) save_conf("Plugin_Alarme_Cli",$alarmeActiveCli);
				if (isset($alarmDelay)) save_conf("plugin_alarme_timetoStart",$alarmDelay);

				try {
					$response['response'][0]['result'] ="1"; 
				} catch (Exception $e) {
					$response['response'][0]['result'] = $e->getMessage();
				}
				$json = json_encode($response);
				echo ($json=='[]'?'{}':$json);
			}
            break;	
		case 'HomeCheck_UpdRays':
			HomeCheckradio_update_relays();
			break;
		case 'HomeCheck_UpdGsm':
			HomeCheckradio_update_Gsm();
			break;
		case 'HomeCheck_ByPass':
			$cod=$_['code'];
			$code="Byp".$cod;
			HomeCheckRelay_send_intr($code);
			if ($cod=="1") {
				save_conf("plugin_homecheck_modeday",'night');
			} else {
				save_conf("plugin_homecheck_modeday",'day');
			}
			
			break;
		
		case 'HomeCheck_updSrc':
			Functions::log('sync and update ip device');
			$tempDir = sys_get_temp_dir();

			$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"installHomeCheck\"");
			Functions::log("update src ".$return);			
			$return="maj effectuée";
			echo $return;
			
			break;
			
		case 'HomeCheck_SyncAndGetip':
			Functions::log('sync and update ip device');
			$tempDir = sys_get_temp_dir();

			//$temp=fopen("/tmp/homeaction.txt", "w");
			//fwrite($temp, $content);
			//fclose($temp);
			$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"run_Scanip.py -u 1 \"");
			Functions::log("SyncAndGetip ".$return);			
			$return="Synchro effectuée";
			echo $return;
			
			break;
		
		case 'HomeCheck_Getip':

			Functions::log('update ip device');
			$genericRelayManager = new AlarmeRelay();
			$genericRelays = $genericRelayManager->populate();
			echo "count ".count($genericRelays)."<br>";
			foreach ($genericRelays as $genericRelay) {
				$mac=$genericRelay->macaddr;
				echo $mac." ".$genericRelay->description."<br>";
				if ($mac<>"") {
					$ip=getdeviceIP($mac);
					echo "ip is ".$ip."<br>";
					if ($genericRelay->IPadress<>$ip) {
						Functions::log('update ip device: '.$mac." ".$ip);
						$genericRelay->IPadress=$ip;
						$genericRelay->save();
					}
				}
			}
			break;
			
		case 'HomeCheck_GetTemp':
			HomeCheckRelay_send_intr("Tmp");
			sleep(1);
			HomeCheckRelay_send_intr("Pic");
			//save_conf("homecheck_outtemp",$curtemp);
			//save_conf("homecheck_outhumidity",$curhumidity);
			//save_conf("homecheck_sunrise",$sunrise);
			//save_conf("homecheck_sunset",$sunset);
			

			break;
			
		case 'HomeCheck_GetPic':
			//HomeCheckradio_plugin_test_code(10001);
			HomeCheckRelay_send_intr("Pic");
			break;
		
		case 'HomeCheck_GetPicModule':
			$id=($_['id']);
			//echo $id;
			$RelayManager = new AlarmeRelay('r');
			$Relay = $RelayManager->load(array('id'=>$id));
			//if 0 error of reading
			//$res=($Relay->st3==0) ? 100 : $Relay->st3;
			$res=$Relay->st3;
			Functions::log('Get Pic from: '.$Relay->description ." Value ".$res);
			echo $res;
			//$json = json_encode($Relay->st3);
            //echo ($json=='[]'?'{}':$json);
			break;
			
		case 'HomeCheck_LetPic':
			
			$alarme_conf = new AlarmeConf("r");
			$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_Pic"));	
			$pic=intval($alarme_res->getValue());
			$json = json_encode($pic);
            echo ($json=='[]'?'{}':$json);
			break;
			
		case 'HomeCheck_SetPic':
			global $_,$myUser;
			// no more used
			$pic=intval($_['code']);
			
			Functions::log('Detect Lumi as  : '.$pic);
			
			$alarme_conf = new AlarmeConf();
			$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_Pic"));
			$alarme_res->setValue($pic);
			$alarme_res->save();
			
		
			break;
			
		case 'HomeCheck_testAlarm':
			$alarme_Manager = new AlarmeSensorRadio("r");
			$alarmes = $alarme_Manager->loadAll(array('type'=>'SensorRXRADIO','isalarm'=>1));
			
			foreach($alarmes as $alarme)
			{
				echo $alarme->description;
			}
			
			break;
			
        case 'plugin_save_HomeCheck':
			if($myUser->can('Home_Check','c') && isset($_['nameHomeCheck']))
             {
                    $HomeCheckManager = new Home_Check();
                    $Home_Check = !empty($_['id']) ? $HomeCheckManager->getById($_['id']): new Home_Check();
					
                    $Home_Check->name = $_['nameHomeCheck'];
                    $Home_Check->description = $_['descriptionHomeCheck'];
                    $Home_Check->imei = $_['IMEIHomeCheck'];
                    $Home_Check->state = $_['ISATHomeCheck'];
					$Home_Check->isadmin=$_['ISADMINHomeCheck'];
					$Home_Check->password=$_['PASSHomeCheck'];
					$Home_Check->nummobile=$_['MobileHomeCheck'];
					$Home_Check->email=$_['EmailHomeCheck'];
					$Home_Check->isclientserv=$_['IsClientServHomeCheck'];
					$Home_Check->room = 1;
					$Home_Check->alarm=0;
					$Home_Check->ip='';
					$Home_Check->location='';
                    $Home_Check->save();
                    
					UpdateLastMod();
					
					echo plugin_alarme_LoadPersonnes();
                }
			else
			{
				header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
            break;
		
		case 'HomeCheck_save_Relay':
			if($myUser->can('Home_Check','c') )
			 {
					$RadioManager = new AlarmeRelay();

					if (empty($_['descriptionGenericRelay'])) {
						throw new Exception("Le nom est obligatoire");
					}
				   
					$genericRadio = !empty($_['id']) ? $RadioManager->getById($_['id']): new AlarmeRelay();
					$genericRadio->description = $_['descriptionGenericRelay'];
					$genericRadio->IPadress = $_['ipGenericRelay'];
					$genericRadio->macaddr =strtoupper($_['macGenericRelay']);
					$genericRadio->isSwitch = $_['isSwitch'];
					$genericRadio->iddevice = $_['idGenericRelay'];
					$genericRadio->onCommand = $_['onGenericRelay'];
					$genericRadio->offCommand = $_['offGenericRelay'];
					$genericRadio->stopCommand = $_['stopGenericRelay'];
					$genericRadio->st1 = $_['st1'];
					$genericRadio->st2 = $_['st2'];
					$genericRadio->st3 = $_['st3'];
					$genericRadio->st4 = $_['st4'];
					$genericRadio->st5 = $_['st5'];
					$genericRadio->st6 = $_['st6'];
					$genericRadio->save();
					//$response['message'] = 'Relais enregistré avec succès';
					UpdateLastMod();
					echo plugin_alarme_LoadRelay();
			 };
			break;
		
		case 'HomeCheck_Sync_Relay':
			if($myUser->can('Home_Check','c') )
			 {
				 if (empty($_['id'])) {
						throw new Exception("ID est obligatoire");
					}
				   
				 $engine=$_['id'];
				 $code=$_['pass'];
				 $state="SYNC";
				 $response="Ok"; 
				 HomeCheckRelay_plugin_change_state($engine, $state,0,$code);
				 sleep(3);
				 $relay = new AlarmeRelay();
                 $relay = $relay->getById($engine);
			
				 if ($relay->state!="12") {
					 echo "Débrancher, Vérifier Position Haute et REbrancher DomoSwitch";
				 }
				 else {
					 echo "Success, Changer Interrupteur position Basse";
				 }
				  //plugin_alarme_LoadRelay();
			 }
			 break;
			 
		case 'HomeCheck_Sync_Yee':
			if($myUser->can('Home_Check','c') )
			 {
				if (empty($_['id'])) {
						throw new Exception("ID est obligatoire");
						
					}
				   
				$engine=$_['id'];
				$color=$_['color'];
				Functions::log("yeeini ".$color);
				$color=hex2rgb($color);
				$intens=$_['intens'];
				$response="Ok"; 
			
				$relay = new AlarmeRelay();
                $relay = $relay->getById($engine);
				$ip=$relay->IPadress;
				$cmd='python '.dirname(__FILE__).'/run_Yeelamp.py -c '.$color.' -b '.$intens." ".$ip;
				//Functions::log("yee ".$cmd);
				exec($cmd . " > /dev/null &"); 	
				echo "Success, changer Interrupteur position Neutre";
				
			 }
			 break;	 
			 
		case 'HomeCheck_save_Radio':
            if($myUser->can('Home_Check','c') )
             {
                    $RadioManager = new AlarmeSensorRadio();

                    if (empty($_['descriptionGenericRadio'])) {
                        throw new Exception("Le nom est obligatoire");
                    }
                   // if (!is_numeric($_['radioCodeGenericRadio'])) {
                   //     throw new Exception("Le code radio est obligatoire et doit être numerique");
                   // }

                    $genericRadio = !empty($_['id']) ? $RadioManager->getById($_['id']): new AlarmeSensorRadio();
					
					
                    $genericRadio->description = $_['descriptionGenericRadio'];
                    $genericRadio->type = $_['SensorType'];
                    $genericRadio->onCommand = $_['onGenericRadio'];
                    $genericRadio->offCommand = $_['offGenericRadio'];
                    
                    $genericRadio->radiocodeOn = $_['radioCodeGenericRadioOn'];
                    $genericRadio->radiocodeOff = $_['radioCodeGenericRadioOff'];
					$genericRadio->sensorTxTyp = $_['sensorTxTyp'];
					$genericRadio->isalarm = $_['radioCodeGenericIsAlarm'];
					$genericRadio->linkradio=$_['radiolink'];
					$genericRadio->delay=$_['DelaySensor'];
					$genericRadio->state=0;
					$genericRadio->lumi=$_['LumiSensor'];
					
                    $genericRadio->save();
					
					UpdateLastMod();
                    //$response['message'] = 'Relais enregistré avec succès';
					echo plugin_alarme_LoadSensorRadio($_['SensorType']);
			 };
            break;
		
		case 'HomeCheckRadio_Anet':
				Action::write(
					function ($_, &$response) {
						$error = HomeCheckradio_plugin_change_state($_['engine'], $_['state']);
						Plugin_CheckAndStop($_['engine'],0);
						if ($error) {
							$response['errors'][] = $error;
						}
					}
				);
			
            break;
		case 'HomeCheckSend_Cli':
			Action::write(
					function ($_, &$response) {
						HomeCheck_plugin_SendCli("info",$_['payload']);	
						sleep(1);
						if ($error) {
							$response['errors'][] = $error;
						}
					}
				);
			
            break;
		case 'HomeCheckSend_Gsm':
			Action::write(
					function ($_, &$response) {
						HomeCheck_plugin_SendGsm("info",$_['payload']);	
						sleep(1);
						if ($error) {
							$response['errors'][] = $error;
						}
					}
				);
			
            break;
		case 'HomeCheckRadio_manual_change_state':
				if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r")) {
							
				Action::write(
					function ($_, &$response) {
						$error = HomeCheckradio_plugin_change_state($_['engine'], $_['state']);
						Plugin_CheckAndStop($_['engine'],0);
						if ($error) {
							$response['errors'][] = $error;
						}
					}
				);
			}
            break;
			
		case 'HomeCheckRadio_vocal_change_state':
            global $_,$myUser;
			
            try {
                $response['responses'][0]['type'] = 'talk';
                if (!$myUser->can('Home_Check', 'u')) {
                    throw new Exception(
                        'Je ne vous connais pas, ou alors vous n\'avez pas le droit, je refuse de faire ça!'
                    );
                }
                HomeCheckradio_plugin_change_state($_['engine'], $_['state']);
				Plugin_CheckAndStop($_['engine'],0);
                $response['responses'][0]['sentence'] = Personality::response('ORDER_CONFIRMATION');
            } catch (Exception $e) {
                $response['responses'][0]['sentence'] = Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
            }
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
		
		case 'HomeCheck_get_relay_state':
			global $_,$myUser;
			$state=$_['state'];
			$ip=$_['ip'];
			$mac= strtoupper($_['mac']);
			Functions::log('Received from ESP: '.$ip.' mac '.$mac.' state:'.$state);
			
			$mac=substr($mac, -8);  //check last 3 bytes 
			$Relay_Manager = new AlarmeRelay("r");
			$relays = $Relay_Manager->populate();
			foreach ($relays as $relay) {
				if (substr($relay->macaddr, -8)==$mac)  break;
			}
			
			if ($relay==Null) {
				Functions::log("Err Relay mac ".$mac);
				break;
			}
			Functions::log("Relay desc ".$relay->description);
			
			if (substr($state,0,3)=='Cod') {
				$pos = strpos($state, '/');
				$code=substr($state,4,$pos-4);
				Functions::log('Detect Relay Code : '.$code);
				$detector=HomeCheck_GetReceiver($code);
				
				if ($detector!="RX" ) {
					if ($detector!=Null) {
						Functions::log('Detect command : '.$code);
						$MessageAlerte="Alert at ".$detector->getDescription();
						Plugin_Alarme_Start_Action($detector->getId(),$MessageAlerte);
					} else {
						Functions::log('Detect Unknown Code : '.$code);
					}
				}
			}
			elseif (substr($state,0,7) =="WifiCod") {
				Functions::log('Detect pres: '.$ip." ".$relay->description);
				HomeCheck_send_notification('Detect pres: '.$ip." ".$relay->description); 
				$MessageAlerte="Alert at ".$relay->description;
				Plugin_Alarme_Start_Action(0,$MessageAlerte);
			}
			elseif (substr($state,0,3) =="Inf") {
				Functions::log('Infos  : '.$state);
			}
			elseif (substr($state,0,3) =="Ini") {
				HomeCheckradio_update_relays();
			}
			elseif (substr($state,0,3)=='Pic') {
				$Pic=substr($state,4);
				$pic=intval($Pic);
			
				Functions::log('Detect Lumi as  : '.$pic);
				$relay->st3=$pic;
				$relay->save();
				
				$alarme_conf = new AlarmeConf();
				$alarme_res = $alarme_conf->load(array("conf"=>"Plugin_Alarme_Pic"));
				$alarme_res->setValue($pic);
				$alarme_res->save();
			}
			elseif (substr($state,0,3)=='Tmp') {
				$pos = strpos($state, '/');
				$temps=substr($state,4,$pos-4);
				$temp = explode("_", $temps);
				$humidity=substr($state,$pos+1,strlen($state));
				
				$relay->st1=$temp[0];
				$relay->st2=$humidity;
				$relay->save();
				
				save_conf('plugin_homecheck_temp',$temp[0]);
				save_conf('plugin_homecheck_feeltemp',$temp[1]);
				save_conf('plugin_homecheck_humidity',$humidity);
				$heure = date('H', time());
				$minute=date('i', time());
				$meridiem=date('a', time());
				$updh=0;
				if ($heure==12 and $meridiem=='pm' and $minute<5) {
					$updh=1;
				}
				$cmd='python '.dirname(__FILE__).'/run_SaveTemp.py -t '.$temp[0].' -f '.$temp[1]." -d ".$humidity.' -m '.$updh." 0";
				exec($cmd . " > /dev/null &"); 	
				Functions::log('cmd  : '.$cmd);
				Functions::log('Detect temp humidity as  : '.$temp[0]." ".$temp[1]." ".$humidity);
				
			}
			elseif (substr($state,0,3)=='WTU') { //WTU/40
				$pos = strpos($state, '/');
				//$temps=substr($state,4,$pos-4);
				//$temp = explode("_", $temps);
				$Pic=substr($state,$pos+1,strlen($state));
				$pic=intval($Pic);
			
				Functions::log('Detect WTU Lumi as  : '.$pic);
				$relay->st3=$pic;
				$relay->save();
			}
			elseif (substr($state,0,3)=='Gsm') {
				$gsmmsg=substr($state,3,strlen($state));
				$gsmmsg=str_replace("&quot;","-",$gsmmsg);
				//$gsmmsg=htmlspecialchars_decode($gsmmsg);
				Functions::log($gsmmsg);
				$lastIndex = strripos($gsmmsg, '-');
				if ($lastIndex===false) { 
					$lastIndex=0;
				}
				else {
					$lastIndex=$lastIndex+1;
				}
					
				$endc=strlen($gsmmsg);
				$pat = '/-([^-]*?)-/'; // text between quotes excluding quotes
				preg_match_all($pat, $gsmmsg, $matches);
				$message=substr($gsmmsg,$lastIndex,$endc);
				$pos=  strpos($gsmmsg,"CMT");
				$numpho="Uknown";
				if ($pos !== false) {
					$numpho=$matches[0][0];
					$numpho=str_replace("-","",$numpho);
				}
				Functions::log('Received gsm  : '.$message." from ".$numpho." ");
			}
			else {
				$ip=getdeviceIP($mac);
				HomeCheckRelay_plugin_update_state($state,$relay);
			}
			$response="OK";
			$json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
			
			break;
			
		case 'HomeCheckRelay_manual_change_state':
		
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r")) {
				$auto=isset($_['mode']) ? 1 : 0;
				Action::write(
					function ($_, &$response) {
						$error = HomeCheckrelay_plugin_change_state($_['engine'], $_['state'],$auto);
						
						if ($error) {
							$response['errors'][] = $error;
						}
					}	
				);
			}
			else {
				$response="-1";
			}
			
            break;
					
		case 'HomeCheckRelay_vocal_change_state':
            global $_,$myUser;
			
            try {
                $response['responses'][0]['type'] = 'talk';
                if (!$myUser->can('Home_Check', 'u')) {
                    throw new Exception(
                        'Je ne vous connais pas, ou alors vous n\'avez pas le droit, je refuse de faire ça!'
                    );
                }
				$auto=isset($_['mode']) ? 1 : 0;
                HomeCheckRelay_plugin_change_state($_['engine'], $_['state'],$auto);
				
                $response['responses'][0]['sentence'] = Personality::response('ORDER_CONFIRMATION');
            } catch (Exception $e) {
                $response['responses'][0]['sentence'] = Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
            }
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
		
		case 'HomeCheckGroup_manual_change_state':
		
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r")) {
				$auto=isset($_['mode']) ? 1 : 0;
				Action::write(
					function ($_, &$response) {
						$error = HomeCheckGroup_plugin_change_state($_['engine'], $_['state'],$auto);
						
						if ($error) {
							$response['errors'][] = $error;
						}
					}	
				);
			}
			else {
				$response="-1";
			}
			
            break;
					
		case 'HomeCheckGroup_vocal_change_state':
            global $_,$myUser;
			
            try {
                $response['responses'][0]['type'] = 'talk';
                if (!$myUser->can('Home_Check', 'u')) {
                    throw new Exception(
                        'Je ne vous connais pas, ou alors vous n\'avez pas le droit, je refuse de faire ça!'
                    );
                }
				$auto=isset($_['mode']) ? 1 : 0;
                HomeCheckGroup_plugin_change_state($_['engine'], $_['state'],$auto);
				
                $response['responses'][0]['sentence'] = Personality::response('ORDER_CONFIRMATION');
            } catch (Exception $e) {
                $response['responses'][0]['sentence'] = Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
            }
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
		
		case 'HomeCheckGpio_vocal_change_state':
					
					if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r")) {
						Action::write(
							function ($_, &$response) {
								$error = HomeCheckGpio_plugin_change_state($_['engine'], $_['state']);
								
								if ($error) {
									$response['errors'][] = $error;
								}
							}	
						);
					}
					else {
						$response="-1";
					}
					
					break;		
					
		case 'HomeCheckGpio_manual_change_state':
			
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r")) {
				Action::write(
					function ($_, &$response) {
						$error = HomeCheckGpio_plugin_change_state($_['engine'], $_['state']);
						
						if ($error) {
							$response['errors'][] = $error;
						}
					}	
				);
			}
			else {
				$response="-1";
			}
			
            break;
			
		case 'HomeCheckIPCAM_plugin_change_state':
			
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r")) {
				Action::write(
					function ($_, &$response) {
						$error = HomeCheckIPCAM_manual_change_state($_['engine'], $_['state']);
						
						if ($error) {
							$response['errors'][] = $error;
						}
					}
				);
				
			}	
			
            break;
		
		case 'HomeCheck_commands_execute':
            global $_,$myUser;
            Functions::log('Control in_out : '.$_['imei']." ".$_['state']);
			
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r")) {
				try {
					HomeCheck_plugin_update_state($_['imei'], $_['state'],1);
					$response=1;
				} catch (Exception $e) {
					$response=0;
				}
			}
			else {
				$response =0;
			}
			
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
		
            break;
			
		case 'HomeCheck_control_execute':
			global $_,$myUser;
            try {
														   
                if (!$myUser->can('Home_Check', 'u')) {
                    throw new Exception(
                        'Je ne vous connais pas, ou alors vous n\'avez pas le droit, je refuse de faire ça!'
                    );
                }
				if ($_['check']==1) {
					$code=HomeCheck_whois(1);
					}
				else {
					$code=HomeCheck_whois(0);
				}

			} catch (Exception $e) {
                $code=-1;
            }
            $json = json_encode($code);
            echo ($json=='[]'?'{}':$json);
            break;
				
		case 'HomeCheck_AlarmStatus':
			$response=HomeCheck_alarmStatus();
			$json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
			
            break;
		
		case 'HomeCheck_ReceiverTestDetect':
			
			
			$cmd='python '.dirname(__FILE__).'/run_TestDetect.py';
			exec($cmd,$out);   
		
			foreach ($out as $v) echo $v;
				$answer=$v;
			//echo $answer;
            break;
		
	
		case 'HomeCheck_ReceiverDetect':
			global $_,$myUser;
			// no more used
			$code=$_['code'];
   
			$detector=HomeCheck_GetReceiver($code);
  
			if ($detector!="RX" ) {
				if ($detector!=Null) {
					Functions::log('Detetect command : '.$code);
					$MessageAlerte="Alert at ".$detector->getDescription();
					Plugin_Alarme_Start_Action($detector->getId(),$MessageAlerte);
				} else {
						Functions::log('Detect Unknown Code : '.$code);
				}
			}
			break;
		
		case 'HomeCheck_vocal_weatherhome':
		
			$url="https://home.nest.com/api/0.1/weather/forecast/38000,FR";
			$string = file_get_contents($url);
			$json_a = json_decode($string, true);
			
			//echo date('Y-m-d H:i:s', 1514415600);
			//echo date('H:i', 1514358900);
			/*
			$jsonIterator = new RecursiveIteratorIterator(
			new RecursiveArrayIterator(json_decode($string, TRUE)),
			RecursiveIteratorIterator::SELF_FIRST);

			foreach ($jsonIterator as $key => $val) {
				if(is_array($val)) {
					echo "$key:\n";
				} else {
					echo "$key => $val\n";
				}
			}*/
			
			$daycond= $json_a["forecast"]['daily']["0"];
			
			$curcond=$json_a['now']["conditions"];
			switch ($curcond)
				{
					//Les actions suite au retour vocal
					case "Snow":
						$sky="neige";
					break;
					case "Rain":
						$sky="pluie";
					break;
					case "Partly Cloudy":
						$sky="couvert";
					break;
					default:
						$sky="ensoleillé";
					break;
				}
					

			$lowtemp=$daycond["low_temperature"];
			$lowtemp = ($lowtemp - 32)*5/9;
			$lowtemp=number_format((float)$lowtemp, 0, '.', ',');
			$higttemp=$daycond["high_temperature"];
			$higttemp = ($higttemp - 32)*5/9;
			$higttemp=number_format((float)$higttemp, 0, '.', ',');
			$curtemp= $json_a['now']["current_temperature"];
			$curhumidity=$json_a['now']["current_humidity"];
			$sunrise=$json_a['now']["sunrise"];
			$sunset=$json_a['now']["sunset"];
			$curwind=$json_a['now']["current_wind"];
			$winddir=$json_a['now']["wind_direction"];
			
			$alarme_conf = new AlarmeConf();
			$temp=get_conf_value('plugin_homecheck_temp');
			$temp=number_format((float)$temp, 1, ',', '.');
			$humidity=get_conf_value('plugin_homecheck_humidity');
			$response.="A l'intérieur, la température ambiante est de ".$temp." degré ";
			$response.="et l'Humidité ".$humidity." %.";
			$response.="Pour les Conditions exterieur, ".$sky.".";
			$response.=" la Température est de ".$curtemp."degré,";
			$response.=" et l'Humidité de ".$curhumidity."%.";
			$response.=" Le soleil se leve à ".date('H:i', $sunrise). " et se couche à ".date('H:i',$sunset ).".";
			$response.=" Demain la température mini est de ".$lowtemp." degré et maxi ".$higttemp." degré.";
			
			$retour['responses'][0]['type'] = 'talk';
			$retour['responses'][0]['sentence']=htmlspecialchars_decode($response,ENT_QUOTES);
			$json = json_encode($retour);
            echo ($json=='[]'?'{}':$json);
			
			HomeCheck_plugin_SendCli("info",$response);
			sleep(1);
            break;
			
		case 'HomeCheckRelay_vocal_statehome':
			$alarme_conf = new AlarmeConf("r");
			$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));
			$people=HomeCheck_whois(0);
			$sensor_Manager = new AlarmeSensorRadio("r");
			$sensors = $sensor_Manager->loadAll(array('type'=>"SensorRXRADIO"));

			
			if($alarme_conf->getValue()=="1")
			{
				$sentence="Surveillance Active.";
			}
			elseif($alarme_conf->getValue()=="0")
			{
				$sentence="Alarme Inactive.";
			}
			elseif($alarme_conf->getValue()=="2")
			{
				$sentence="Alerte, Alarme déclenchée.";
			}
			$response.="Etat Alarme .".$sentence.' ';
			$response.=" Présent .".$people." ";
			
			$sen="";
			foreach($sensors as $sensor) {
				if ($sensor->state!=0) {
					$sen.=" ".$sensor->getDescription().",";
				}
			}
			
			$response.=" Recepteur Actif . ".$sen." ";
			
			$etat="";
			$Relay_Manager = new AlarmeRelay("r");
			$Relays = $Relay_Manager->populate();
			
			foreach($Relays as $Relay) {
				if ($Relay->isSwitch != 0) {
				$etat.=$Relay->getDescription()." ".GetRelayState($Relay->state).", ";
				}
			}
			$response.=" Etat Relais Wifi . ".$etat;
			//echo htmlspecialchars_decode($response,ENT_QUOTES);
			//$res='test avec espace é'; // utf8_encode('test avec espace é');
			//echo $res;
			HomeCheck_plugin_SendCli("info",$response);
			sleep(1);
			$retour['responses'][0]['type'] = 'talk';
			$retour['responses'][0]['sentence']=htmlspecialchars_decode($response,ENT_QUOTES);
			$json = json_encode($retour);
            echo ($json=='[]'?'{}':$json);
            break;
		
		case 'HomeCheck_GetLanIP':
			$lan = Monitoring::internalIp();
			$response =$lan;
			$json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
			
		case 'HomeCheck_SetIp':
			global $_,$myUser;
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r")) {
				try {
					$ip=$_['IP'];
					$imei=$_['IMEI'];
					$name=HomeCheck_SetLocalIP($ip,$imei);
					$response ='Bienvenue '.$name;
				} catch (Exception $e) {
					$response=Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
				}
			}
			else {
				$response =Personality::response('WORRY_EMOTION').'! '."Vous étes qui?";
			}
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
			
		case 'HomeCheck_Test_Con':
			global $_,$myUser;
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r")) {
				$response=1;
			}
			else {
				$response=0;
			}
			$json = json_encode($response);
			echo ($json=='[]'?'{}':$json);

			break;
		
		case 'HomeCheck_SetFcmId':
			global $_,$myUser;
			try {
				$imei=$_['imei'];
				$fcmid=$_['fcmid'];

				Functions::log('update '.$imei." fcmid ".$fcmid);
				$response=HomeCheck_updateFcmId($imei,$fcmid);
				
			} catch (Exception $e) {
                $response['responses'][0]['sentence'] = Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
            }
			
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
		case 'HomeCheck_getServerLogs':
			global $_,$myUser;
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r")) {
				
				$loglines="";
				$logs = dirname(__FILE__).'/../../'.LOG_FILE ;
				//echo $logs;
				if(file_exists($logs)){
					$lines = file($logs);
					$nb_lines = count($lines)-1; // -1 pour ne pas avoir la ligne avec uniquement la virgule
					
					for($i=$nb_lines; $i>0; $i--){
						$line=$lines[$i];
						$loglines .= $line;
					}
				}
				$response=$loglines;				
			}
			else {
				$response=0;
			}
			$json = json_encode($response);
			echo ($json=='[]'?'{}':$json);
			HomeCheck_send_notification("Logs sent from server"); 
			break;
			
			
		case 'HomeCheck_SetPos':
			global $_,$myUser;
			try {
				$pos=$_['POS'];
				$imei=$_['IMEI'];
				$ishome=$_['HOME'];
				
				Functions::log('membre '.$imei." loc ".$pos);
				
				$code=HomeCheck_SetPos($pos,$imei);
				HomeCheck_plugin_update_state($imei,$ishome,0);
				$response =$code;
				
			} catch (Exception $e) {
                $response['responses'][0]['sentence'] = Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
            }
			
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
		
		case 'HomeCheck_GetPos':
			global $_,$myUser;
			try {
				$nummob=$_['nummob'];
				//echo $nummob;
				Functions::log('Get pos '.$nummob);
				HomeCheck_plugin_SendCli("loc",$nummob);
			} catch (Exception $e) {
                
            }
			echo plugin_alarme_LoadPersonnes();
            break;
		
		case 'HomeCheck_admin_execute':
			global $_,$myUser;
            try {
                $response['responses'][0]['type'] = 'check';
                if (!$myUser->can('Home_Check',"r")) {
                    throw new Exception(
                        'Je ne vous connais pas, ou alors vous n\'avez pas le droit, je refuse de faire ça!'
                    );
                }
				$code=HomeCheck_whoisadmin($_['imei']);
				$response['responses'][0]['sentence'] =$code;
			} catch (Exception $e) {
                $response['responses'][0]['sentence'] = Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
            }
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
				
		case 'Plugin_Alarme_Start_Action':
			global $_,$myUser;
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r"))
			{	
				Plugin_Alarme_Start_Action();
			}
			else
			{
				echo('Action non autorisé');
			}
			$response="Done";
			$json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
			
            break;
		
		
		case 'Plugin_Alarme_Manual_Active_Action':
			global $_,$myUser;
			
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r"))
			{
				Plugin_Alarme_Active_Action(1);
				$response['responses'][0]['sentence']="Alarme Active";
			}
			else
			{
				//echo('Action non autorisé');
				$response['responses'][0]['sentence']="Action non autorisé";
			}
			$json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
			
            break;
			
		case 'Plugin_Alarme_Active_Action':
			global $_,$myUser;
			
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r"))
			{
				$response=Plugin_Alarme_Active_Action();
			}
			else
			{
				//echo('Action non autorisé');
				$response="Action non autorisé";
			}
			$json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
			
            break;
		
		case 'Plugin_Alarme_Start_ActivationCli':
		
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r"))
			{
				$act=$_['status'];
				save_conf("Plugin_Alarme_Cli",$act);	
				
				$code="Byp".$act;
				HomeCheckRelay_send_intr($code);
				if ($act=="1") {
					save_conf("plugin_homecheck_modeday",'night');
				} else {
					save_conf("plugin_homecheck_modeday",'day');
				}
			}
			else
			{
				echo('Action non autorisé');
			}
			break;
		
		case 'Plugin_Alarme_Get_ActivationCli':
			global $_,$myUser;
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r"))
			{
				$alarme_conf = new AlarmeConf();
				$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_Cli"));	
				$response=(int) $alarme_conf->getValue();
			}
			else
			{
				$response="-1";
			}
			$json = json_encode($response);
			echo ($json=='[]'?'{}':$json);
			break;
		
		//Activation par URL des détecteurs 
		case 'Plugin_Alarme_Start_Activation':
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r"))
			{
				$src=$_['src'];
				Plugin_Alarme_Activation($src);
			}
			else
			{
				echo('Action non autorisé');
			}
		break;
		
		//Désactivation par URL des détecteurs 
		case 'Plugin_Alarme_Start_Desactivation':
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r"))
			{
				$src=$_['src'];				
				Plugin_Alarme_Desactivation($src);
				
				Functions::log('Alarm disactivated ');
			}
			else
			{
				echo('Action non autorisé');
			}
			$response['responses'][0]['sentence']="Alarme desactivee";
			$json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
		break;
		
		//Désactivation par URL des détecteurs 
		case 'Plugin_Alarme_Start_Switch':
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r"))
			{
				$alarme_conf = new AlarmeConf("r");
				$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));
				
				
				if ($alarme_conf->getValue()=='1')
				{
					Plugin_Alarme_Desactivation();
				}
				elseif ($alarme_conf->getValue()=='0')
				{
					Plugin_Alarme_Activation();
				}
			}
			else
			{
				echo('Action non autorisé');
			}
		break;
		
		//Action aprés ordre vocal association ancien client yana
		case 'plugin_alarme_vocal_action':
			if(($myUser->can('Home_Check',"r"))&&(isset($_['Type'])))//exception temporaire pour le yana scan sans token
			{
				switch ($_['Type'])
				{
					//Les actions suite au retour vocal
					case "On":
						$error=Plugin_Alarme_Activation();
						if($error==null)
							{
								$response = array('responses'=>array(array('type'=>'talk','sentence'=>talk(Personality::response('ORDER_CONFIRMATION')))));
								$json = json_encode($response);
								echo ($json=='[]'?'{}':$json);
							}
							else
							{
								$response = array('responses'=>array(
								array('type'=>'talk','sentence'=>'Une erreur est survenue!, '.$error)));
								echo json_encode($response);
							}
					break;
					
					case "Off":
						$error=Plugin_Alarme_Desactivation ();
						if($error==null)
							{
								$response = array('responses'=>array(array('type'=>'talk','sentence'=>talk(Personality::response('ORDER_CONFIRMATION')))));
								$json = json_encode($response);
								echo ($json=='[]'?'{}':$json);
							}
							else
							{
								$response = array('responses'=>array(
								array('type'=>'talk','sentence'=>'Une erreur est survenue!, '.$error)));
								echo json_encode($response);
							}
					break;
				}
			}
			else
			{
				echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_add_Sensor':
			if($myUser->can('Home_Check','c')&& isset($_['type']) && isset($_['descriptionSensor'])&& isset($_['numGPIO']))
			{
				$alarme_Manager = new AlarmeSensor();
				$alarme_Manager->setType($_['type']);
				$alarme_Manager->setDescription($_['descriptionSensor']);
				$alarme_Manager->setNumGPIO(trim($_['numGPIO']));
				$alarme_Manager->onCommand=$_['onCommand'];
				$alarme_Manager->offCommand=$_['offCommand'];
				$alarme_Manager->save();
				if ($_['type']=="SensorGPIO")
				{
					echo plugin_alarme_LoadSensor();
				}
				elseif($_['type']=="SensorADGPIO")
				{
					echo plugin_alarme_LoadADSensor();
				}
			}
			else
			{
				header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_sms':
			if($myUser->can('Home_Check','c') && isset($_['AlarmeUserName'])&& isset($_['AlarmePassName'])&& isset($_['AlarmeMsgName']))
			{
				$alarme_Manager = new AlarmeSMS();
				$alarme_Manager->setType($_['AlarmeTypeName']);
				$alarme_Manager->setIdentifiant_user(trim($_['AlarmeUserName']));
				$alarme_Manager->setIdentifiant_mdp(trim($_['AlarmePassName']));
				$alarme_Manager->setMessage($_['AlarmeMsgName']);
				$alarme_Manager->save();
				echo plugin_alarme_LoadActions_SMS();
			}
			else
			{
				header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'AddActionGroup':
			if($myUser->can('Home_Check','c') )
			{
				$group_Manager = new ActionGroup();
				if (empty($_['descriptionGroup'])) {
					throw new Exception("Le nom est obligatoire");
				}
				   
				$group = !empty($_['id']) ? $group_Manager->getById($_['id']): new ActionGroup();
				$group->description=$_['descriptionGroup'];
				$group->onCommand=$_['onCommand'];
				$group->offCommand=$_['offCommand'];
				
				$group->save();
				//echo plugin_alarme_LoadActionGroup();
			}
			else
			{
				header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
			break;
		
		case 'AddActionProg':
			if($myUser->can('Home_Check','c') )
			{
				$group_Manager = new ExecCmd();
				if (empty($_['descriptionProg'])) {
					throw new Exception("Le nom est obligatoire");
				}
				$tok=htmlspecialchars_decode($myUser->getToken(),ENT_QUOTES);
				$url=$_['url']."&token=".$tok;
				Functions::log('add actionprog '.$_['cmd']);   
				$group = !empty($_['id']) ? $group_Manager->getById($_['id']): new ExecCmd();
				$group->description=$_['descriptionProg'];
				$group->cmdline=$_['cmd'];
				$group->url=$_['url'];
				$group->pic=$_['pic'];
				$group->typ=1;
				$group->status="on";
				//$temp=fopen("/tmp/homeaction.txt", "w");
				//fwrite($temp, $content);
				//fclose($temp);
				// add action to cron
				$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"/rpc/client.py -a 1 ".$url." ".$_['cmd']."\"");
				//$return=shell_exec("python ".dirname(__FILE__)."/rpc/client.py -a 1 \"".$_['url']."\" \"".$_['cmd']."\"");
				Functions::log('Actionprog res '.$return); 
				$group->pid=$return;
				$group->save();
				echo plugin_alarme_LoadActionProg(1);
			}
			else
			{
				header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
			break;
		
		case 'FonctionLog':
			Functions::log('Log external '.$_['log']);   
			break;
			
		case 'AddActionLumi':
			if($myUser->can('Home_Check','c') )
			{
				$group_Manager = new ExecCmd();
				if (empty($_['descriptionProg'])) {
					throw new Exception("Le nom est obligatoire");
				}
				$tok=htmlspecialchars_decode($myUser->getToken(),ENT_QUOTES);
				$url=$_['url']."&token=".$tok;
				Functions::log('add actionprog '.$cmd);   
				$group = !empty($_['id']) ? $group_Manager->getById($_['id']): new ExecCmd();
				$group->description=$_['descriptionProg'];
				$group->cmdline=$_['cmd'];
				$group->url=$_['url'];
				$group->pic=$_['pic'];
				$group->st1=$_['linkr']; // id relai source
				$group->typ=2;
				$group->status="on";
				// add action to cron
				$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"/rpc/client.py -a 2 ".$url." ".$_['cmd']." ".$_['pic']." ".$_['linkr']."\"");
				
				Functions::log('ActionLumi res '.$return); 
				$group->pid=$return;
				$group->save();
				echo plugin_alarme_LoadActionProg(2);
			}
			else
			{
				header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
			break;
			
		case 'AddActionItemGroup':
			if($myUser->can('Home_Check','c') )
			{
				$alarme_Manager = new ActionCollection();
				$alarme_Manager->type=$_['id'];
				$alarme_Manager->linkradio=$_['linkid'];
				$alarme_Manager->description=$_['description'];
				$alarme_Manager->save();
				//echo plugin_alarme_LoadActionfromGroup();
				
			}
			else
			{
				header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_Email':
			if($myUser->can('Home_Check','c') )
			{
				$alarme_Manager = new AlarmeEmail();
				$alarme_Manager->setEmailExp($_['EmailExp']);
				
				$alarme_Manager->save();
				echo plugin_alarme_LoadActions_Email();
			}
			else
			{
				header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_GPIO':
			if($myUser->can('Home_Check','c') && isset($_['descriptionGPIO'])&& isset($_['numGPIO'])&& isset($_['stateGPIO']))
			{
				$alarme_Manager = new AlarmeGPIO();
				$alarme_Manager->setDescriptionGPIO($_['descriptionGPIO']);
				$alarme_Manager->setNumGPIO(trim($_['numGPIO']));
				$alarme_Manager->setStateGPIO(trim($_['stateGPIO']));
				$alarme_Manager->save();
				echo plugin_alarme_LoadActions_GPIO();
			}
			else
			{
				header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_Vocal':
			if($myUser->can('Home_Check','c') && isset($_['MessageVocal']))
			{
				$alarme_Manager = new AlarmeActionVocal();
				$alarme_Manager->setMessageVocal($_['MessageVocal']);
				$alarme_Manager->save();
				echo plugin_alarme_LoadActions_Vocales();
			}
			else
			{
				header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_CommandeVocale':
			if($myUser->can('Home_Check','c') && isset($_['type'])&& isset($_['commandeVocale']))
			{
				$alarme_Manager = new AlarmeCommandeVocale();
				$alarme_Manager->setType($_['type']);
				$alarme_Manager->setCommande($_['commandeVocale']);
				$alarme_Manager->setConfidence("0.92");
				$alarme_Manager->save();
				echo plugin_alarme_LoadCommandes_Vocales();
			}
			else
			{
				header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_CameraIP':
			if($myUser->can('Home_Check','c'))
			{
				
				$alarme_conf = new AlarmeConf();
				
				$alarme_conf = $alarme_conf->load(array('conf'=>"Plugin_Alarme_DriveDirectory"));
				$alarme_conf->setValue(trim($_["Plugin_Alarme_DriveDirectory"]));
				$alarme_conf->save();
				
				$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_RepoDirectory"));
				$alarme_conf->setValue(trim($_['Plugin_Alarme_RepoDirectory']));
				$alarme_conf->save();

				$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_StoreDirectory"));
				$alarme_conf->setValue(trim($_['Plugin_Alarme_StoreDirectory']));
				$alarme_conf->save();
				
				$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_SendEmail"));
				$alarme_conf->setValue(trim($_['Plugin_Alarme_SendEmail']));
				$alarme_conf->save();

				$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_SendSms"));
				$alarme_conf->setValue(trim($_['Plugin_Alarme_SendSms']));
				$alarme_conf->save();

				
				echo '<i class="fa fa-check fa-2x" style="color:green"></i>Enregistré';		
			}
			else
			{
				echo '<i class="fa fa-times fa-2x" style="color:red"></i>Erreur :'.$e->getMessage();
			}
			break;
		
		case 'plugin_alarme_add_Camera':
			if($myUser->can('Home_Check','c'))
			{
				if (isset($_['type']) && $_['type'] =="Photo")
				{
					if(isset($_['Plugin_Alarme_Resolution_H'])&&isset($_['Plugin_Alarme_Resolution_V'])&&isset($_['Plugin_Alarme_CameraOption'])&&isset($_['Plugin_Alarme_CameraCopyDirectory']))
					{
						$alarme_conf = new AlarmeConf();
						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraType"));
						$alarme_conf->setValue(trim($_['type']));
						$alarme_conf->save();
						
						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResV"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_Resolution_V']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResH"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_Resolution_H']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraOption"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_CameraOption']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraCopyDirectory"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_CameraCopyDirectory']));
						$alarme_conf->save();
					}
				}
				elseif((isset($_['type'])) && ($_['type'] =="Video"))
				{
					if(isset($_['Plugin_Alarme_Resolution_H'])&&isset($_['Plugin_Alarme_Resolution_V'])&&isset($_['Plugin_Alarme_TimeToCapture'])&&isset($_['Plugin_Alarme_CameraOption'])&&isset($_['Plugin_Alarme_CameraCopyDirectory']))
					{	
						$alarme_conf = new AlarmeConf();
						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraType"));
						$alarme_conf->setValue(trim($_['type']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResV"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_Resolution_V']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResH"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_Resolution_H']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraTime"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_TimeToCapture']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraOption"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_CameraOption']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraCopyDirectory"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_CameraCopyDirectory']));
						$alarme_conf->save();
					}
				}
				echo '<i class="fa fa-check fa-2x" style="color:green"></i>Enregistré';		
			}
			else
			{
				echo '<i class="fa fa-times fa-2x" style="color:red"></i>Erreur :'.$e->getMessage();
			}
		break;
		
		case 'plugin_alarme_add_URL':
			if($myUser->can('Home_Check','c') && isset($_['type'])&& isset($_['actionUrl']))
			{
				$alarme_Manager = new AlarmeURL();
				$alarme_Manager->setType($_['type']);
				$alarme_Manager->setUrl($_['actionUrl']);
				$alarme_Manager->save();
				echo plugin_alarme_LoadActionsURL();
			}
			else
			{
				header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_Shell':
		if($myUser->can('Home_Check','c')&& isset($_['actionShell']))
		{
			$alarme_Manager = new AlarmeShell();
			$alarme_Manager->setShell($_['actionShell']);
			$alarme_Manager->save();
			echo plugin_alarme_LoadActionsShell();
		}
		else
		{
			header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
		}
		break;
		
		//Modificaiton des refresh du widgetcase 'plugin_alarme_add_URL':
		case 'plugin_alarme_updateRefresh':
			if($myUser->can('Home_Check','u') && isset($_['champs'])&& isset($_['value']))
			{
				$alarme_conf = new AlarmeConf();
				$alarme_conf = $alarme_conf->load(array("conf"=>$_['champs']));
				$alarme_conf->setValue($_['value']);
				$alarme_conf->save();
			}
			else
			{
				header('location:index.php?module=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_delete_alarme_ADSensor':
		if($myUser->can('Home_Check','d') && isset($_['id']))
		{
			$alarme_Manager = new AlarmeSensor();
			$alarme_Manager->delete(array('id'=>$_['id']));
			echo  plugin_alarme_LoadADSensor();
		}
		else
		{
			 echo 'Token ou utilisateur incorrect';
		}
		break;
		
		case 'plugin_alarme_delete_alarme_Sensor':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeSensor();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadSensor();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_alarme_SMS':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeSMS();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadActions_SMS();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_alarme_Email':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeEmail();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadActions_Email();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_alarme_GPIO':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeGPIO();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadActions_GPIO();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_alarme_Vocal':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeActionVocal();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadActions_Vocales();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_alarme_camera':
			if($myUser->can('Home_Check','d') && isset($_['name']))
			{
				$absolute_path = getcwd()."/plugins/HomeCheck/camera/";
				unlink($absolute_path.$_['name']);
				echo  plugin_alarme_LoadCamera();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_delete_Radio':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$HomeCheckManager = new AlarmeSensorRadio();
                $HomeCheckManager->delete(array('id'=>$_['id']));
				echo plugin_alarme_LoadSensorRadio($_['type']);
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_delete_Relay':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$HomeCheckManager = new AlarmeRelay();
                $HomeCheckManager->delete(array('id'=>$_['id']));
				echo plugin_alarme_LoadRelay();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_delete_HomeCheck':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$HomeCheckManager = new Home_Check();
                $HomeCheckManager->delete(array('id'=>$_['id']));
				
				echo  plugin_alarme_LoadPersonnes();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_delete_ActionGroup':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				//delete first all link from ActionCollection
				$ActionItemManager = new ActionCollection();
                $ActionItemManager->delete(array('type'=>$_['id']));
				
				$HomeCheckManager = new ActionGroup();
                $HomeCheckManager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadActionGroup();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
			break;
		
		case 'plugin_check_ActionProg':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{		
				$HomeCheckManager = new ExecCmd();
				
				//delete the associate cron task
				$cmdex = $HomeCheckManager->load(array('id'=>$_['id']));
				$pid=$cmdex->pid;
				$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"/rpc/client.py -g 1 ".$pid."\"");
								
				echo "Next Run ".$return;
				echo plugin_alarme_LoadActionProg($cmdex->typ);
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
			break;
		
		case 'plugin_mod_ActionProg':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{		
				$HomeCheckManager = new ExecCmd();
				
				//delete the associate cron task
				$cmdex = $HomeCheckManager->load(array('id'=>$_['id']));
				$status=$cmdex->status;
				$url=$cmdex->url;
				$cmd=$cmdex->cmdline;
				$pic=$cmdex->pic;
				$linkid=$cmdex->st1;
				
				$tok=htmlspecialchars_decode($myUser->getToken(),ENT_QUOTES);
				$url=$url."&token=".$tok;
				
				if ($status=="on") {
					$cmdex->status="off";
					shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"/rpc/client.py -d 1 ".$cmdex->pid."\"");
					$cmdex->pid="";
				} else {
					$cmdex->status="on";
					// add action to cron	
					if ($cmdex->typ==1) {
						$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"/rpc/client.py -a 1 ".$url." ".$cmd."\"");
					} elseif ($cmdex->typ==2) {
						$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"/rpc/client.py -a 2 ".$url." ".$cmd." ".$pic." ".$linkid."\"");
					}					
					$cmdex->pid=$return;
				}
				$cmdex->save();
				echo plugin_alarme_LoadActionProg($cmdex->typ);
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
			break;
			
		case 'plugin_delete_ActionProg':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{		
				$HomeCheckManager = new ExecCmd();
				
				//delete the associate cron task
				$cmdex = $HomeCheckManager->load(array('id'=>$_['id']));
				$pid=$cmdex->pid;
	
				shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"/rpc/client.py -d 1 ".$pid."\"");
				
				//delete the entity
                $HomeCheckManager->delete(array('id'=>$_['id']));
				echo plugin_alarme_LoadActionProg($cmdex->typ);
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
			break;
			
		case 'plugin_delete_ActionItemGroup':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$ActionItemManager = new ActionCollection();
				//echo $_['id']." ".$_['linkid'];
                $ActionItemManager->delete(array('type'=>$_['id'],'linkradio'=>$_['linkid']));
				header('Location: '.$_SERVER['REQUEST_URI']);
				//echo  plugin_alarme_LoadActionGroup($_['id']);
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
			break;
		case 'plugin_alarme_delete_alarme_CommandeVocale':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeCommandeVocale();
				$alarme_Manager->delete(array('id'=>$_['id']));
				
				echo  plugin_alarme_LoadCommandes_Vocales();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_Url':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeURL();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadActionsURL();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_Shell':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeShell();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadActionsShell();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		
		//fonction appelée en ajax pour tester les identifiants/pass/message
		case 'plugin_alarme_test_wifi':
		if($myUser->can('Home_Check',"r"))
		{
			if(isset($_['user'])&& isset($_['pass']))
			{
				$user=$_['user'];
				$pass=$_['pass'];
				$id=$_['id'];
			}
			//echo "/raspberrypiwifi.sh \" wpa_cli_mod.py -u 1 ".$user." ".$pass."\"";
			//Functions::log('wifi '.$id);
			if ($id=="1") {
				$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"run_Wpa_cli_mod.py -l 1 ".$user." ".$pass."\"");
			} elseif ($id=="2") {
				$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"run_Wpa_cli_mod.py -s 1 ".$user." ".$pass."\"");
			} elseif ($id=="3") {
				$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"run_Wpa_cli_mod.py -u 1 ".$user." ".$pass."\"");
			}
			echo $return;
			
		}
		break;	
		
		//fonction appelée en ajax pour tester les identifiants/pass/message
		case 'plugin_alarme_test_SMS':
		if($myUser->can('Home_Check',"r"))
		{
			if(isset($_['user'])&& isset($_['pass'])&& isset($_['msg']))
			{
				$user=$_['user'];
				$pass=$_['pass'];
				$msg=$_['msg'];
			}
			elseif (isset($_['id']))
			{
				$alarme_Manager = new AlarmeSMS("r");
				$alarme_Manager=$alarme_Manager->getById($_['id']);
				$user=$alarme_Manager->getIdentifiant_user();
				$pass=$alarme_Manager->getIdentifiant_mdp();
				$msg=$alarme_Manager->getMessage();
			}
			$return =plugin_alarme_sendSms($user,$pass, $conf->get('VOCAL_ENTITY_NAME')." ".$msg);
			Switch ($return)
				{
				case "200":
					$retour ='<i class="fa fa-check fa-2x" style="color:green"></i>Sms envoyé';
				break;
				
				case "400":
					$retour = '<i class="fa fa-times fa-2x" style="color:red"></i>Un des paramètres obligatoires est manquant.';
				break;	
				
				case "402":
					$retour = '<i class="fa fa-times fa-2x" style="color:red"></i>Trop de SMS ont été envoyés en trop peu de temps.';
				break;	
				
				case "403":
					$retour = '<i class="fa fa-times fa-2x" style="color:red"></i>Le service n\'est pas activé sur l\'espace abonné, ou login / clé incorrect.';
				break;	
				
				case "500":
					$retour = '<i class="fa fa-times fa-2x" style="color:red"></i>Erreur côté serveur. Veuillez réessayer ultérieurement.';
				break;	
				
				default:
				echo curl_error($ch);
				break;
			}
			echo $retour;
		}
		break;	
		
	
		//fonction appelée en ajax pour tester les identifiants/pass/message
		case 'plugin_alarme_test_GPIO':
			
			if($myUser->can('Home_Check',"r"))
			{
				if(isset($_['numGPIO'])&& isset($_['stateGPIO']))
				{
					$numGPIO=(int)$_['numGPIO'];
					$stateGPIO=(int)$_['stateGPIO'];
				}
				elseif (isset($_['id']))
				{
					$alarme_Manager = new AlarmeGPIO("r");
					$alarme_Manager=$alarme_Manager->getById($_['id']);
					$numGPIO=(int)$alarme_Manager->getNumGPIO();
					$stateGPIO=(int)$alarme_Manager->getStateGPIO();
				}
				
				//Si l'etat demandé est le méme que le test, on change l'etat avant le test pour valider le fonctionnement
				$preState=(int)Gpio::read($numGPIO);
				Gpio::mode($numGPIO,'out');
				$ChangePrea=$preState;
				if ($preState==$stateGPIO)
				{
					$at = $preState == 1 ? 0 : 1;
					Gpio::write($numGPIO,$at);
					
					$ChangePrea=(int)Gpio::read($numGPIO);
					if ($ChangePrea!=$preState)
					{
						echo '<i class="fa fa-check fa-2x" style="color:green"></i>Changement préalable de la sortie pour validation du changement ok</br>';
					}
					else
					{
						echo '<i class="fa fa-times fa-2x" style="color:red"></i> Changement préalable de la sortie pour validation du changement échoué</br>';
					}
				}
				
				//On change l'état
				Gpio::mode($numGPIO,'out');
				Gpio::write($numGPIO,$stateGPIO);
				
				//On vérifie
				$postState=(int)Gpio::read($numGPIO);
				
				//On confirme ou non
				if(($stateGPIO==$postState&&$preState!=$stateGPIO)||($stateGPIO==$postState&&$ChangePrea!=$stateGPIO))
				{
					echo '<i class="fa fa-check fa-2x" style="color:green"></i>Changement GPIO validé';
				}
				else
				{
					echo '<i class="fa fa-times fa-2x" style="color:red"></i>Echec lors du changement';
				}
				
				//On met le pin dans son état précédant
				Gpio::mode($numGPIO,'out');
				Gpio::write($numGPIO,$preState);
				
				//Re-test de la reprise de l'etat précédant
				
			}
		break;
		
		case 'plugin_alarme_test_Camera':
		if($myUser->can('Home_Check',"r"))
		{	
				$alarme_conf = new AlarmeConf("r");
				$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_CameraDirectory"));
				$absolute_path=$alarme_conf->getValue();
			if (isset($_['type']) && $_['type'] =="Photo")
			{
				if(isset($_['Plugin_Alarme_Resolution_H'])&&isset($_['Plugin_Alarme_Resolution_V'])&&isset($_['Plugin_Alarme_CameraOption'])&&isset($_['Plugin_Alarme_CameraCopyDirectory']))
				{
					try
					{
						$name =time().".jpg";
						system('raspistill '.$_['Plugin_Alarme_CameraOption'].' -w '.$_['Plugin_Alarme_Resolution_V'].' -h '.$_['Plugin_Alarme_Resolution_H'].'-n -o '.$absolute_path.$name);
						//Si le champs copie n'est pas vide, on copi la photo ou la vidéo.
						if ($_['Plugin_Alarme_CameraCopyDirectory']!="")
						{
							copy($absolute_path.$name, $_['Plugin_Alarme_CameraCopyDirectory'].$name);
						}
						echo plugin_alarme_LoadCamera();
					}
					catch (Exception $e) 
					{
						echo '<i class="fa fa-times fa-2x" style="color:red"></i> Erreur lors de la capture, erreur : '.$e->getMessage().'<br>';
					}
				}
			}	
			elseif((isset($_['type'])) && ($_['type'] =="Video"))
			{
				if(isset($_['Plugin_Alarme_Resolution_H'])&&isset($_['Plugin_Alarme_Resolution_V'])&&isset($_['Plugin_Alarme_TimeToCapture'])&&isset($_['Plugin_Alarme_CameraOption'])&&isset($_['Plugin_Alarme_CameraCopyDirectory']))
				{	
					try
					{
						$name =time();
						system('raspivid '.$_['Plugin_Alarme_CameraOption'].' -t '.$_['Plugin_Alarme_TimeToCapture'].' -w '.$_['Plugin_Alarme_Resolution_V'].' -h '.$_['Plugin_Alarme_Resolution_H'].' -n -o '.$absolute_path.$name.'.h264');
						system('MP4Box -fps 30 -add '.$absolute_path.$name.'.h264 '.$absolute_path.$name.'.mp4 > /dev/null');
						unlink($absolute_path.$name.'.h264');
						//Si le champs copie n'est pas vide, on copi la photo ou la vidéo.
						if ($_['Plugin_Alarme_CameraCopyDirectory']!="")
						{
							copy($absolute_path.$name.'.mp4', $_['Plugin_Alarme_CameraCopyDirectory'].$name.'.mp4');
						}
						
						echo plugin_alarme_LoadCamera();
					}
					catch (Exception $e) 
					{
						echo '<i class="fa fa-times fa-2x" style="color:red"></i> Erreur lors de la capture, erreur : '.$e->getMessage().'<br>';
					}
				}
			}
		}
		break;
		
		case 'plugin_alarme_test_Vocal':
		if($myUser->can('Home_Check',"r"))
		{
			if(isset($_['MessageVocal']))
			{
				$MessageVocal=$_['MessageVocal'];
			}
			elseif(isset($_['id']))
			{
				$alarme_Manager = new AlarmeActionVocal("r");
				$alarme_Manager=$alarme_Manager->getById($_['id']);
				$MessageVocal=$alarme_Manager->getMessageVocal();
			}
			
			try
			{
				$cli = new Client();
				$cli->connect();
				$cli->talk(htmlspecialchars_decode($MessageVocal,ENT_QUOTES));
				$cli->disconnect();
				echo '<i class="fa fa-check fa-2x" style="color:green"></i>Diction ok';
			}
			catch (Exception $e) 
			{
				echo '<i class="fa fa-times fa-2x" style="color:red"></i>Erreur lors de la disction de la phrase : '.$alarme_Manager->getMessageVocal().', erreur : '.$e->getMessage().'<br>';
			}

		}
		break;
				
		case 'plugin_alarme_test_URL':
		if($myUser->can('Home_Check',"r"))
		{
			if(isset($_['actionUrl']))
			{
				$url=urldecode($_['actionUrl']);
			}
			elseif(isset($_['id']))
			{
				$alarme_Manager = new AlarmeURL("r");
				$alarme_Manager=$alarme_Manager->getById($_['id']);
				$url=htmlspecialchars_decode($alarme_Manager->getUrl(),ENT_QUOTES);
			}
			if (function_exists('curl_version'))
			{
				//Si CURL est activé, tester l'URL
				$ch = curl_init();
				curl_setopt($ch,CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_TIMEOUT, 5);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				if(curl_exec($ch))
				{
					echo '<i class="fa fa-check fa-2x" style="color:green"></i>URL exécutée<br>';
					echo '<i class="fa fa-check fa-2x" style="color:green"></i>Retour de l\'URL :'.curl_multi_getcontent($ch);
				}
				else
				{
					echo '<i class="fa fa-times fa-2x" style="color:red"></i>Erreur lors de l\'exécution de l\'URL : '.curl_error($ch).'<br>';
					echo '<i class="fa fa-times fa-2x" style="color:red"></i>Code d\'erreur HTML: '.curl_getinfo($ch, CURLINFO_HTTP_CODE);
				}
				curl_close($ch);
			}
			else
			{
				echo '<i class="fa fa-times fa-2x" style="color:red"></i>Impossible de tester l\'URL de Yana-Server, cURL manquant sur ce RPI';
			}
		}
		break;
		
		case 'plugin_alarme_test_Shell':
		if($myUser->can('Home_Check',"r"))
		{
			if(isset($_['actionShell']))
			{
				$Shell=urldecode($_['actionShell']);
			}
			elseif(isset($_['id']))
			{
				$alarme_Manager = new AlarmeShell("r");
				$alarme_Manager=$alarme_Manager->getById($_['id']);
				$Shell=htmlspecialchars_decode($alarme_Manager->getShell(),ENT_QUOTES);
			}
			$return2 = exec($Shell, $returnString, $returnState);
			
			if (!$returnState)
			{	
				echo '<i class="fa fa-check fa-2x" style="color:green"></i>Commande Shell : "'.$Shell.'" exécutée avec succés <br>';
				echo '<i class="fa fa-check fa-2x" style="color:green"></i>Retour du Shell : ';
				print_r($returnString);
			}
			else
			{
				echo '<i class="fa fa-times fa-2x" style="color:red"></i>Erreur lors de l\'exécution de la commande : "'.$Shell.'"<br>';
				echo '<i class="fa fa-times fa-2x" style="color:red"></i>Retour du Shell: ';
				print_r($returnString);
			}
			
		}
		break;
		
		case 'plugin_alarme_testcode':
		
			$code=$_['code'];
			$type=$_['type'];
			if(isset($code))
			{
				HomeCheckradio_plugin_test_code($code);
				echo plugin_alarme_LoadSensorRadio($type);
			}
		
		break;
		
		case 'plugin_alarme_timetoStart':
		if($myUser->can('Home_Check','c'))
		{
			if(isset($_['time']))
			{
				$alarme_conf = new AlarmeConf();
				$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_timetoStart"));
				$alarme_conf->setValue($_['time']);
				$alarme_conf->save();  
				echo '<i class="fa fa-check fa-2x" style="color:green"></i>Enregistré';
			}
		}
		break;
		
		case 'plugin_alarme_doc_install':
		if($myUser->can('Home_Check','c'))
		{
			header("Content-type:application/pdf");
			header("Content-Disposition:attachment;filename='InstallationPluginAlarme.pdf'");
			readfile("InstallationPluginAlarme.pdf");
		}
		break;
				
		case 'ponctuel_alarme':

		//$table1 = new AlarmeShell();
		//$table1->create();
		
		//$alarme_conf = new AlarmeConf("r");
		//$objetCharge=$alarme_conf->load(array("conf"=>"plugin_alarme_RefreshWidget"));
		//$objetCharge->setValue("9000");
		//$objetCharge->save(); 
			//global $myUser, $conf;
			//print_r ($_SESSION['configuration']);
		break;
	
		//Widget
		case 'HomeCheck_globalstate_load_widget':
			$alarme_conf = new AlarmeConf("r");
			$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));
			$alarmeActive=$alarme_conf->getValue();
			
			$alarme_confCli = $alarme_conf->load(array("conf"=>"Plugin_Alarme_Cli"));
			$alarmeActiveCli=$alarme_confCli->getValue();
			
			$people=HomeCheck_whois(0);
			$sensor_Manager = new AlarmeSensorRadio("r");
			$sensors = $sensor_Manager->loadAll(array('type'=>"SensorRXRADIO"));
			
			header('Content-type: application/json');				
			$response = array();
			$response['title'] = 'Etat Global';
			$response['content'] ='<ul class="yana-list">';
			if($alarmeActive=="1") {
				$sentence=" Surveillance Active";
			}
			elseif($alarmeActive=="0") {
				$sentence=" Alarme Inactive";
			}
			elseif($alarmeActive=="2") {
				$sentence=" Alerte, Alarme déclenchée";
			}
			$response['content'] .='<li><strong class="badge">'."Etat Alarme Générale: ".'</strong></br>'.$sentence.'  </li>';
			$sentence=$alarmeActiveCli==1 ? 'Active' : 'Inative';
			$response['content'] .='<li><strong class="badge">'."Etat Alarme Nuit: ".'</strong></br>'.$sentence.'  </li>';
			
			$response['content'] .='<li><strong class="badge">'."Présent(s): ".'</strong></br>'.$people.'  </li>';
			
			$sen="";
			foreach($sensors as $sensor) {
				if ($sensor->state!=0) {
					$sen.="</br>".$sensor->getDescription();
				}
			}
			$response['content'] .='<li><strong class="badge">'."Récepteur(s) Actif(s): ".'</strong>'.$sen.'  </li>';
			
			$etat="";
			$Relay_Manager = new AlarmeRelay("r");
			$Relays = $Relay_Manager->populate();
			
			foreach($Relays as $Relay) {
				if ($Relay->isSwitch!=0) {
					$etat.="</br>".$Relay->getDescription().": ".GetRelayState($Relay->state);
				}
			}
			$response['content'] .='<li><strong class="badge">'."Etat Relais Wifi: ".'</strong>'.$etat.'  </li>';
						
			$response['content'] .='</ul>';
			$response['desc']="Etat Relais Wifi";
			$response['id']="Level";
			$response['cost']="10";
			$response['indicatorValue']="5";
			echo json_encode($response);
			break;
			
		case 'GET_GLOBAL_COMMAND':
			if(!$myUser->can('Home_Check',"r")) exit('Token ou utilisateur incorrect');
			{	
				$RadioManager = new AlarmeRelay();
				$exports = $RadioManager->populate();
				$response['commands']=$exports;
				echo json_encode($response);
			}
			break;
			
		case 'plugin_alarme_load_widget':
			
			if(!$myUser->can('Home_Check',"r")) exit('Token ou utilisateur incorrect');
			{		
				$alarme_manager = new AlarmeConf("r");
				$alarme_conf = $alarme_manager->load(array("conf"=>"plugin_alarme_Start"));
				$plugin_alarme_Start=$alarme_conf->getValue();
				
				$alarme_conf = $alarme_manager->load(array("conf"=>"plugin_alarme_RefreshWidget"));				
				$plugin_alarme_RefreshWidget=$alarme_conf->getValue();
				
				$alarme_conf = $alarme_manager->load(array("conf"=>"plugin_alarme_RefreshWidgetPhoto"));				
				$plugin_alarme_RefreshWidget_photo=$alarme_conf->getValue();
				
				header('Content-type: application/json');				
				$response = array();
				$response['title'] = "Alarme";
				$response['content'] = '<script type="text/javascript" src="./plugins/Home_Check/js/widget.js"></script>
				<div id="xhrBlock">';
				
				$response['content'] .='<div id="widget_plugin_alarme_valeur_id" data-valeur="'.$plugin_alarme_Start.'" data-refresh="'.$plugin_alarme_RefreshWidget.'" ><a class="btn" title="Activé désactiver l\'alarme"> ';
				$response['content'] .='<i id="widget_plugin_alarme_icone_id" class=" fa fa-cog fa-lg" style="color:black" ></i></a><span id="widget_plugin_alarme_sentence_id"></span>';
				$response['content'] .='</div></div>';
				//prise de photo ou video
				$response['content'] .='<div data-photoexist="1" data-refreshphoto="'.$plugin_alarme_RefreshWidget_photo.'" id="xhrBlockPhoto" ><img id="widget_plugin_alarme_photo_id" style="max-width:631px;margin:auto;width:100%;height:auto;display: none;" ></div>';
				
				echo json_encode($response);
				
			}
		break;
		
		case 'plugin_alarme_load_widget_refresh':
			if(!$myUser->can('Home_Check',"r")) exit('Token ou utilisateur incorrect');
			{
				echo plugin_alarme_LoadWidget();
			}
		break;
		
		case 'plugin_alarme_load_widget_refresh_photo':
			if(!$myUser->can('Home_Check',"r")) exit('Token ou utilisateur incorrect');
			{
				$alarme_manager = new AlarmeConf("r");
				$alarme_conf = $alarme_manager->load(array("conf"=>"plugin_alarme_WidgetCameraOption"));				
				$plugin_alarme_WidgetCameraOption=$alarme_conf->getValue();
			
				//On supprime les photos existantes
				array_map('unlink', glob(getcwd()."/plugins/Home_Check/cameraWidget/*.jpg"));
				
				//on prend la novuelle
				$absolute_path =getcwd()."/plugins/Home_Check/cameraWidget/";
				$name=time().".jpg";
				
				exec('raspistill '.$plugin_alarme_WidgetCameraOption.' -w 631 -h 631 -n -o '.$absolute_path.$name, $output, $return);

				if($return==0)
				{
					$valeur="1";
					$sentence=" Caméra disponible";
				}
				else
				{
					$valeur="0";
					$sentence=" Camera non dispopnible pour la prise de photo";	

				}
				
				$refresh=array(	"valeur"=>$valeur,
				"sentence"=>$sentence,
				"chemin"=>"./plugins/Home_Check/cameraWidget/".$name,
				"error"=>$error);
				echo json_encode($refresh);
			}
		break;
		
		case 'plugin_alarme_click_toChangeAlarme':
			if(!$myUser->can('Home_Check','u')) exit('Token ou utilisateur incorrect');
			if (isset($_['state']))
				{
					if ($_['state']=="1")
					{
						$error = Plugin_Alarme_Desactivation();
					}
					elseif($_['state']=="0")
					{
						$error = plugin_alarme_Activation();
					}
					elseif($_['state']=="2")
					{
						$error = $error = Plugin_Alarme_Desactivation();
					}
					echo plugin_alarme_LoadWidget($error);
				}
		break;
		
		//Fonction appelée par les widgets pour choisir une couleur pour le widget
		case 'plugin_alarme_click_change_color':
			if(!$myUser->can('Home_Check','u')) exit('Token ou utilisateur incorrect');
				echo '<form name="mon_formulaire">
				<input type="color" id ="plugin_alarme_changeColor" name="plugin_alarme_changeColor" />
				<br />
				<input type="button" value="Enregistrer" onclick="plugin_alarme_saveColor()" />
				</form>';
		break;

		case 'plugin_alarme_click_save_color':
			if(!$myUser->can('Home_Check','u')) exit('Token ou utilisateur incorrect');
				if (isset($_['color']))
				{
					$alarme_manager = new AlarmeConf();
					$alarme_conf = $alarme_manager->load(array("conf"=>"plugin_alarme_widget_color"));
					$alarme_conf->setValue($_['color']);
					$alarme_conf->save();
					header('location:index.php');
				}
		break;
		
		case 'HomeCheck_import_HomeCheck':
            Action::write(
                function ($_, &$response) {
                    $exportprofiles = json_decode($_POST["import"]);
                    //var_dump($exportRadios);
                    if ($exportprofiles) {
                        foreach ($exportprofiles as $exportprofile) {
                                 $homecheck = new Home_Check();
                                 $homecheck->name = $exportprofile->name;
                                 $homecheck->description = $exportprofile->description;
                                 $homecheck->imei = $exportprofile->imei;
								 $homecheck->state="0";
                                 $homecheck->isadmin = $exportprofile->isadmin;
                                 $homecheck->password = $exportprofile->password;
								 $homecheck->nummobile = $exportprofile->nummobile;
								 $homecheck->email = $exportprofile->email;
								 $homecheck->ip = "";
								 $homecheck->location = "";
								 $homecheck->isclientserv = $exportprofile->isclientserv;
                                 $homecheck->save();
                                 $response['message'] = 'Relais importés avec succès';
                        }
                    } else {
                        throw new Exception("Les valeurs importés sont incorrectes, vérifier les dans un lecteur JSON");
                    }
                },
                array('Home_Check'=>'c')
            );
            break;
		case 'plugin_HomeCheck_radio_import':
			Action::write(
                function ($_, &$response) {
                    $exportprofiles = json_decode($_POST["import"]);
                    //var_dump($exportRadios);
                    if ($exportprofiles) {
                        foreach ($exportprofiles as $exportprofile) {
                                 $alarmeRadio = new AlarmeSensorRadio();
                                 $alarmeRadio->description = $exportprofile->description;
                                 $alarmeRadio->type = $exportprofile->type;
                                 $alarmeRadio->onCommand = $exportprofile->onCommand;
                                 $alarmeRadio->offCommand = $exportprofile->offCommand;
								 $alarmeRadio->radiocodeOn = $exportprofile->radiocodeOn;
								 $alarmeRadio->radiocodeOff = $exportprofile->radiocodeOff;
								 $alarmeRadio->isalarm = $exportprofile->isalarm;
								 $alarmeRadio->sensorTxTyp = $exportprofile->sensorTxTyp;
                                 $alarmeRadio->save();
                                 $response['message'] = 'Relais importés avec succès';
                        }
                    } else {
                        throw new Exception("Les valeurs importés sont incorrectes, vérifier les dans un lecteur JSON");
                    }
                },
                array('Home_Check'=>'c')
            );
            break;
		case 'plugin_HomeCheck_relay_import':
			Action::write(
                function ($_, &$response) {
                    $exportprofiles = json_decode($_POST["import"]);
                    //var_dump($exportRadios);
                    if ($exportprofiles) {
                        foreach ($exportprofiles as $exportprofile) {
                                 $alarmeRelay = new AlarmeRelay();
                                 $alarmeRelay->description = $exportprofile->description;
                                 $alarmeRelay->IPadress = $exportprofile->IPadress;
                                 $alarmeRelay->onCommand = $exportprofile->onCommand;
                                 $alarmeRelay->offCommand = $exportprofile->offCommand;
								 $alarmeRelay->stopCommand = $exportprofile->stopCommand;
                                 $alarmeRelay->save();
                                 $response['message'] = 'Relais importés avec succès';
                        }
                    } else {
                        throw new Exception("Les valeurs importés sont incorrectes, vérifier les dans un lecteur JSON");
                    }
                },
                array('Home_Check'=>'c')
            );
            break;	
		
		case 'plugin_HomeCheck_restore_all':
			if(!$myUser->can('Home_Check',"r")) exit('Token ou utilisateur incorrect');
			{
				echo HomeCheck_restore_all();
			}
			break;
		
		case 'plugin_HomeCheck_backup_all':
			if(!$myUser->can('Home_Check',"r")) exit('Token ou utilisateur incorrect');
			{
				echo HomeCheck_backup_all();
			}
			break;
		
		case 'plugin_HomeCheck_Upload':
			if(!$myUser->can('Home_Check',"r")) exit('Token ou utilisateur incorrect');
			{
				echo HomeCheck_Upload();
			}
			break;
			
		case 'genericRadio_load_widget':

            require_once(dirname(__FILE__).'/../dashboard/Widget.class.php');

            Action::write(
                function ($_, &$response) {
                    $widget = new Widget();
                    $widget = $widget->getById($_['id']);
                    $data = $widget->data();

                    $content = '';

                    if (empty($data['relay'])) {
                        $content = 'Choisissez un relais en cliquant sur l \'icone 
                                <i class="fa fa-wrench"></i> de la barre du widget';
                    } else {
                        
						$relay = new AlarmeSensorRadio();
						$relay = $relay->getById($data['relay']);

						$response['title'] = $relay->description;
						
						$content=get_style();
						$content .= '
                        <ul class="genericradio_relay_pane">
                            <li class="genericradio-case '.($relay->state?'active':'').'" 
                                onclick="plugin_genericradio_change(this,'.$relay->id.');" style="text-align:center;">
                                <i title="On/Off" class="fa fa-flash"></i>
                            </li>
                            <li>
                                <h2>'.$relay->description.'</h2>
                            </li>
                        </ul>

                        <!-- JS -->
                        <script type="text/javascript">
                            function plugin_genericradio_change(element,id){
                                var state = $(element).hasClass(\'active\') ? 0 : 1 ;
                                $.action(
                                {
                                    action : \'HomeCheckRadio_manual_change_state\', 
                                    engine: id,
                                    state: state
                                },
                                function(response){
                                    $(element).toggleClass("active");
                                }
                                );

							}
							</script>
							';
                    }
                    $response['content'] = $content;
					
                }
            );
            break;

        case 'genericRadio_edit_widget':
            require_once(dirname(__FILE__).'/../dashboard/Widget.class.php');
            $widget = new Widget();
            $widget = $widget->getById($_['id']);
            $data = $widget->data();

            $relayManager = new AlarmeSensorRadio();
            $relays = $relayManager->loadAll(array('type'=>'SensorRXRADIO')); //populate();

            $content = '<h3>Relais ciblé</h3>';

            if (count($relays) == 0) {
                $content = 'Aucun relais existant dans yana, 
                <a href="setting.php?section=genericRadio">Créer un relais ?</a>';
            } else {
                $content .= '<select id="relay">';
                $content .= '<option value="">-</option>';
                foreach ($relays as $relay) {
                    $content .= '<option value="'.$relay->id.'">'.$relay->description.'</option>';
                }
                $content .= '</select>';
            }
            echo $content;
            break;

        case 'genericRadio_save_widget':
                require_once(dirname(__FILE__).'/../dashboard/Widget.class.php');
                $widget = new Widget();
                $widget = $widget->getById($_['id']);
                $data = $widget->data();

                $data['relay'] = $_['relay'];
                $widget->data($data);
                $widget->save();
                echo $content;
            break;
		
		case 'genericRelay_load_widget':
		
            require_once(dirname(__FILE__).'/../dashboard/Widget.class.php');

            Action::write(
                function ($_, &$response) {
                    $widget = new Widget();
                    $widget = $widget->getById($_['id']);
                    $data = $widget->data();

                    $content = '';

                    if (empty($data['relay'])) {
                        $content = 'Choisissez un relais en cliquant sur l \'icone 
                                <i class="fa fa-wrench"></i> de la barre du widget';
                    } else {
                        
						$relay = new AlarmeRelay();
						$relay = $relay->getById($data['relay']);
						$state=$relay->state;
						
						$response['title'] = $relay->description;
						$content=get_style();
						$content .= '
                        <ul class="genericradio_relay_pane">
                            <li class="genericradio-case '.($state==1?'active':'').'" 
                                onclick="plugin_genericrelay_change(this,'.$relay->id.',1);" style="text-align:center;">
                                <i title="DOWN" class=" fa fa-chevron-circle-down"></i>
                            </li>
							<li class="genericradio-case '.($state==0?'active':'').'" 
                                onclick="plugin_genericrelay_change(this,'.$relay->id.',0);" style="text-align:center;">
                                <i title="STOP" class=" fa fa-stop-circle"></i>
                            </li>
							<li class="genericradio-case '.($state==2?'active':'').'" 
                                onclick="plugin_genericrelay_change(this,'.$relay->id.',2);" style="text-align:center;">
                                <i title="UP" class=" fa fa-chevron-circle-up"></i>
                            </li>
                       
                        </ul>

                        <!-- JS -->
                        <script type="text/javascript">
                            function plugin_genericrelay_change(element,id,etat){
								var state="STOP";
								switch(etat) {
									case 0:
										state="STOP";
										break;
									case 1:
										state="DOWN";
										break;
									case 2:
										state="UP";
										break;
									default:	
										state="DOWN";
										break;
								} 
                               
                                $.action(
                                {
                                    action : \'HomeCheckRelay_manual_change_state\', 
                                    engine: id,
                                    state: state
                                },
                                function(response){
									setTimeout(function(){ location.reload(); }, 1500);
                                   
                                }
                                );
							}
							</script>
							';
                    }
                    $response['content'] = $content;
					
                }
            );
            break;

        case 'genericRelay_edit_widget':
            require_once(dirname(__FILE__).'/../dashboard/Widget.class.php');
            $widget = new Widget();
            $widget = $widget->getById($_['id']);
            $data = $widget->data();

            $relayManager = new AlarmeRelay();
            $relays = $relayManager->populate();

            $content = '<h3>Relais ciblé</h3>';

            if (count($relays) == 0) {
                $content = 'Aucun relais existant dans yana, 
                <a href="setting.php?section=genericRadio">Créer un relais ?</a>';
            } else {
                $content .= '<select id="relay">';
                $content .= '<option value="">-</option>';
                foreach ($relays as $relay) {
                    $content .= '<option value="'.$relay->id.'">'.$relay->description.'</option>';
                }
                $content .= '</select>';
            }
            echo $content;
            break;

        case 'genericRelay_save_widget':
                require_once(dirname(__FILE__).'/../dashboard/Widget.class.php');
                $widget = new Widget();
                $widget = $widget->getById($_['id']);
                $data = $widget->data();

                $data['relay'] = $_['relay'];
                $widget->data($data);
                $widget->save();
               
            break;

		case 'HomeCheck_ipcam_save_camera':
			
			Action::write(
				function($_,&$response){

					$camera = new IPCamera();

					if(empty($_['labelCamera'])) throw new Exception("Le nom est obligatoire");
					if(empty($_['ipCamera']))  throw new Exception("L'IP est obligatoire");

					$camera = !empty($_['id']) ? $camera->getById($_['id']): new IPCamera();
					$camera->label = $_['labelCamera'];
					$camera->location = $_['locationCamera'];
					$camera->pattern = $_['patternCamera'];
					$camera->ip  = $_['ipCamera'];
					$camera->login  = $_['loginCamera'];
					$camera->password  = $_['passwordCamera'];
                    foreach(IPCamera::brands() as $brand=>$pattern):
							if ($camera->pattern == $pattern) {
                                $camera->brand  = $brand;
                                break;
                            }
					endforeach;
                    
					$camera->save();
					
					
					$response['message'] = 'Caméra enregistrée avec succès';
				},
				array('Home_Check'=>'c')
			);
		break;

		case 'HomeCheck_ipcam_delete_camera':
			Action::write(
				function($_,$response){
					$camera = new IPCamera();
					$camera->delete(array('id'=>$_['id']));
				},
				array('Home_Check'=>'d') 
			);
		break;


		
		case 'HomeCheck_ipcam_load_widget':
			
			require_once(dirname(__FILE__).'/../dashboard/Widget.class.php');
			
			Action::write(
				function($_,&$response){	

					$widget = new Widget();
					$widget = $widget->getById($_['id']);
					$parameters = $widget->data();
					$content='';
					if(empty($parameters['camera'])){
						$content = 'Choisissez une camera en cliquant sur l \'icone <i class="fa fa-wrench"></i> de la barre du widget';
					}else{
						global $conf;
						$camera  = new IPCamera();
					
						$camera = $camera->getById($parameters['camera']);
						$room = new Room();
						$room = $room->getById($camera->location);
						$state=0;
						
						$response['title'] = 'Sonde '.$camera->label.' ('.$room->getName().')';
						$content=get_style();
						$content .= '		
						<!-- HTML -->';
                        $brand=$camera->brand;
	
						if (strtolower($brand)=='picam') {
							$camstream=$camera->ip;
							//$port=strpos($camstream,':');
							//$camstream=substr($camstream,0,$port);
							//$camstream=$camstream.':8099';
							//echo $camstream;
						}
						else {
							$camstream=$camera->ip;
						}
						
						$url = str_replace(array(
							'{{login}}',
							'{{password}}',
							'{{ip}}'
						),array(
							$camera->login,
							$camera->password,
							$camstream
						),$camera->pattern);
						
						
						///pour ma cam, a la fin de l'ip : http://{{login}}:{{password}}@{{ip}}/videostream.cgi
						$content .= '<div class="HomeCheck_ipcam_widget"><img name="main" id="main" border="0" src="'.$url.'">';
						$content .= '</div>';
						$content .= '
                        <ul class="genericradio_relay_pane">
							<li class="genericradio-case '.($state==1?'active':'').'" 
                                onclick="plugin_camip_change(this,'.$camera->id.',0);" style="text-align:center;">
                                <i title="UP" class=" fa fa-chevron-circle-up" style="font-size: 0.8em"></i>
                            </li>
							<li class="genericradio-case '.($state==1?'active':'').'" 
                                onclick="plugin_camip_change(this,'.$camera->id.',4);" style="text-align:center;">
                                <i title="LEFT" class=" fa fa-chevron-circle-left" style="font-size: 0.8em"></i>
                            </li>
							<li class="genericradio-case '.($state==1?'active':'').'" 
                                onclick="plugin_camip_change(this,'.$camera->id.',3);" style="text-align:center;">
                                <i title="HOME" class=" fa fa-home" style="font-size: 0.8em"></i>
                            </li>
							<li class="genericradio-case '.($state==1?'active':'').'" 
                                onclick="plugin_camip_change(this,'.$camera->id.',6);" style="text-align:center;">
                                <i title="Right" class=" fa fa-chevron-circle-right" style="font-size: 0.8em"></i>
                            </li>
							<li class="genericradio-case '.($state==1?'active':'').'" 
                                onclick="plugin_camip_change(this,'.$camera->id.',2);" style="text-align:center;">
                                <i title="DOWN" class=" fa fa-chevron-circle-down" style="font-size: 0.8em"></i>
                            </li>
                        </ul>
					
						<!-- JS -->
                        <script type="text/javascript">
                            function plugin_camip_change(element,id,etat){
                                $.action(
                                {
                                    action : \'HomeCheckIPCAM_plugin_change_state\', 
                                    engine: id,
                                    state: etat
                                },
                                function(response){
									console.log(response);
                                }
                                );
							}
							</script>
							';
                    }
                    $response['content'] = $content;
				}
			);
		break;

		case 'HomeCheck_ipcam_edit_widget':
			require_once(dirname(__FILE__).'/../dashboard/Widget.class.php');
	
			$widget = new Widget();
			$widget = $widget->getById($_['id']);
			$data = $widget->data();
			$camera = new IPCamera();
			$cameras = $camera->populate();
			$content = '<h3>Choix de la camera</h3>';
			if(count($cameras) == 0):  
			$content = 'Aucune camera enregistrée,<a href="index.php?module=Home_Check&block=ADAlarme&sousblock=CameraIP">enregistrer une camera<a>';
			else :
			$content .= '<select id="camera">';
			foreach($cameras as $camera)
				$content .= '<option '.($camera->id==$data['camera']?'selected="selected"':'').' value="'.$camera->id.'">'.$camera->label.' ('.$camera->uid.')</option>';

			$content .= '</select>';
			endif;
			echo $content;
			break;

		case 'HomeCheck_ipcam_save_widget':
			require_once(dirname(__FILE__).'/../dashboard/Widget.class.php');
			$widget = new Widget();
			$widget = $widget->getById($_['id']);
			$data = $widget->data();
			
			$data['camera'] = $_['camera'];
			$widget->data($data);
			$widget->save();
			echo $content;
			break;
		
		case 'propise_select_widget_menu':
			require_once(__DIR__.'/../dashboard/Widget.class.php');
			Action::write(
				function($_,&$response){
				$widget = new Widget();
				$widget = $widget->getById($_['id']);
				$data = $widget->data();
				
				$data['menu'] = $_['menu'];
				$widget->data($data);
				$widget->save();
			});
			break;
		
		case 'propise_get_data':
			
			Action::write(
				function($_,&$response){
				$relay = new AlarmeRelay();
				$relay = $relay->getById($_['id']);
				
				$response['light'] = $relay->st3;
				$response['humidity'] = $relay->st2;
				$response['temperature'] = $relay->st1;
				$response['mouvment'] = 0 ;//$relay->st4;
				},
				array('Home_Check'=>'r') );
			break;
		
		case 'HomeCheck_temp_load_widget':
			require_once(dirname(__FILE__).'/../dashboard/Widget.class.php');

            Action::write(
                function ($_, &$response) {
					
					$widget = new Widget();
                    $widget = $widget->getById($_['id']);
                  
					$parameters = $widget->data();

                    if (empty($parameters['relaytemp'])) {
                        $response['content'] = 'Choisissez un relais en cliquant sur l \'icone 
                                <i class="fa fa-wrench"></i> de la barre du widget';
                    } else {
						global $conf;
						$sensor = new AlarmeRelay();
						$sensor = $sensor->getById($parameters['relaytemp']);
						//Functions::log('SENSOR: '.$sensor->id);
						
						$response['title'] = 'Temperature/Humidité' . $sensor->description;
						$content = '
						<!-- CSS -->
						<style>
							
							.propise_menu{
								margin:0;
							}
							.propise_menu li{
								cursor: pointer;
								display: inline-block;
								font-size: 20px;
								height: 25px;
								margin-top: 3px;
								padding: 5px 5px 0 5px;
								text-align: center;
								color:#222222;
								transition: all 0.2s ease-in-out 0s;
								width: 30px;
								border-top:4px solid #222222;
							}

							.propise_menu li:hover{
								background:#222222;
								color:#ffffff;
							}
							
							.propise_view{
								background:#222222;
								color:#ffffff;
								margin:0px;
								padding:0px;
								width:100%;
								list-style-type:none;
								transition:all 0.2s ease-in-out;
								box-sizing: border-box;
							}
							.propise_view ul{
								padding:0;
								margin:0;
							}

							.propise_view li i{
								font-size:40px;
							}
							.propise_view li{
								font-family: "Open Sans Light",sans-serif;
								text-align:center;
								padding:30px 15px 15px 15px;
								list-style-type:none;
								float:left;
								height: 100px;
								width:50%;
								box-sizing:border-box;
								font-weight:300;
								font-size:30px;
								
							}
							
							.propise_view.propise_detail_view li{
								font-size:60px;
								width:100%;
								height:140px;
								font-size:50px;
								padding:40px 0 40px 0;
								float:none;
							}
							
							.propise_menu li[data-view="temperature"]{
								border-color:#36B3E1;
							}
							.propise_menu li[data-view="humidity"]{
								border-color:#50597B;
							}
							.propise_menu li[data-view="light"]{
								border-color:#EF4D66;
							}
							.propise_menu li[data-view="mouvment"]{
								border-color:#FFBF4C;
							}
							.propise_menu li[data-view="stats"]{
								border-color:#b3e021;
							}
							
							
							.propise_view li[data-type="temperature"]{
								background-color:#36B3E1;
								border-color:#36B3E1;
							}
							.propise_view li[data-type="humidity"]{
								background-color:#50597B;
								border-color:#50597B;
							}
							.propise_view li[data-type="light"]{
								background-color:#EF4D66;
								border-color:#EF4D66;
							}
							.propise_view li[data-type="mouvment"]{
								background-color:#FFBF4C;
								border-color:#FFBF4C;
							}
							.propise_view li[data-type="propise_stats"]{
								background-color:#C1004F;
								border-color:#C1004F;
							}
						</style>
						
						<!-- HTML -->
						';
						
						$content .= '<div class="propise_widget" data-view="'.$parameters['menu'].'" data-id="'.$sensor->id.'">
						<div class="propise_view">
							
								<ul>
									<li data-id="'.$sensor->id.'" data-type="light"><i class="fa fa-sun-o fa-spin-low"></i> <span ></span>%</li>
									<li data-id="'.$sensor->id.'" data-type="temperature"><i class="fa fa-fire"></i> <span ></span>°</li>
									<li data-id="'.$sensor->id.'" data-type="humidity"><i class="fa fa-tint"></i> <span ></span>%</li>
									<li data-id="'.$sensor->id.'" data-type="mouvment"><i class="fa fa-eye"></i> <span ></span></li>
								</ul>
								<div class="clear"></div>
							
						';
				
						$content .= '</div>';
						
						$content .= '<ul class="propise_menu">';
							$content .= '<li class="propise_global" onclick="propise_menu(this)" data-view=""><i class="fa fa-columns"></i></li>';
							$content .= '<li onclick="propise_menu(this)" data-view="light"><i class="fa fa-sun-o"></i></li>';
							$content .= '<li onclick="propise_menu(this)" data-view="temperature"><i class="fa fa-fire"></i></li>';
							$content .= '<li onclick="propise_menu(this)" data-view="humidity"><i class="fa fa-tint"></i></li>';
							$content .= '<li onclick="propise_menu(this)" data-view="mouvment"><i class="fa fa-eye"></i></li>';
						$content .= '</ul>';
						
						$content .= '</div>';
						$content .= '
						<!-- JS -->
						<script type="text/javascript">
							$("document").ready(function(){
								propise_refresh_data_'.$sensor->id.'();
                                setInterval(propise_refresh_data_'.$sensor->id.',5000);
							});
							
							 function propise_refresh_data_'.$sensor->id.'(){
								$(".propise_widget[data-id='.$sensor->id.']").each(function(i,element){
										var view = $(element).attr("data-view");
										
										if(view != $(element).attr("data-selected")){
											propise_show($(element),view);

										}
										$.action({
                                            action:"propise_get_data",
                                            id:$(element).attr("data-id")
                                        },function(r){
                                            for(var key in r){
                                                searchStr = \'li[data-type="\'+key+\'"]\'
                                                searchStr+= \'[data-id="'.$sensor->id.'"]\'
                                               
                                                var type = $(searchStr);
                                                if( key.length ==0 ) continue;
                                                $("span",type).html(r[key]);
                                            }

											var mouvment = $("[data-type=\'mouvment\']");
											$("i",mouvment).attr("class","fa fa-eye"+($("span",mouvment).text()==1?"":"-slash"));
										
											
										});
									});
							}
							
							function propise_menu(element,global){
								var line = $(element);
								var container = line.closest(".propise_widget");
								var view = $(element).attr("data-view");
								var widget = $(element).closest(\'.dashboard_bloc\').attr(\'data-id\');
								
								$(container).attr("data-view",view);
								$.action({
									action:"propise_select_widget_menu",
									id:widget,
									menu: view
								});

								propise_show(container,view);
							};
							
							function propise_show(container,view){
								
								$(container).attr("data-selected",view);
								
								if(view==\'\'){
									$(".propise_view ul li",container).fadeIn();
									$(".propise_view",container).removeClass("propise_detail_view")
									return;
								}
								
								$(".propise_view",container).addClass("propise_detail_view")
								$(".propise_view ul li",container).hide();
								$(".propise_view").css("background-color",$(".propise_view ul li[data-view=\'"+view+"\']",container).css("border-top-color"));
								$(".propise_view ul li[data-type=\'"+view+"\']",container).fadeIn();
							}
							
						</script>
						';
					}
					
					$response['content'] = $content;
				}
				//echo json_encode($response);

				
            );
			break;
				
		case 'HomeCheck_temp_edit_widget':
            require_once(dirname(__FILE__).'/../dashboard/Widget.class.php');
            $widget = new Widget();
            $widget = $widget->getById($_['id']);
            $data = $widget->data();

            $relayManager = new AlarmeRelay();
            $relays = $relayManager->populate();

            $content = '<h3>Relais ciblé</h3>';

            if (count($relays) == 0) {
                $content = 'Aucun relais existant, 
                <a href="setting.php?section=genericRadio">Créer un relais ?</a>';
            } else {
                $content .= '<select id="relaytemp">';
                $content .= '<option value="">-</option>';
                foreach ($relays as $relay) {
					if ($relay->isSwitch == 0) {
						$content .= '<option '.($relay->id==$data['relaytemp']?'selected="selected"':'').' value="'.$relay->id.'">'.$relay->description.' ('.$relay->uid.')</option>';
					}
                }
                $content .= '</select>';
				echo $content;
            }
            
            break;

        case 'HomeCheck_temp_save_widget':
                require_once(dirname(__FILE__).'/../dashboard/Widget.class.php');
                $widget = new Widget();
                $widget = $widget->getById($_['id']);
                $data = $widget->data();

                $data['relaytemp'] = $_['relaytemp'];
                $widget->data($data);
                $widget->save();
				
				
				echo $content;
               
            break;
			
		case 'HomeCheck_GetLastUpdate':
			$alarme_conf = new AlarmeConf("r");
	
			$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_TimeStamp"));
			$lastmod=$alarme_conf->getValue();
			
			$json = json_encode($lastmod);
            echo ($json=='[]'?'{}':$json);
			break;
		
		case 'HomeCheck_CheckIn':
			global $_,$myUser;
			$mac=$_['mac'];
			$ip=$_['localip'];
			Functions::log('Checkin '.$mac." IP".$ip);
			$cmd='python '.dirname(__FILE__).'/run_pingHost.py '.$ip.' '.$mac;
			exec($cmd . " > /dev/null &"); 	
			$response=$mac." is in";
			HomeCheck_plugin_SendCli("info",$response);	
			
			break;
		case 'Plugin_checkout':
			global $_,$myUser;
			$mac=$_['mac'];
			Functions::log($mac." checkout");
			$response=$mac." is out";
			HomeCheck_plugin_SendCli("info",$response);
			
			break;	
		case 'HomeCheck_BT_Pres':
			$state=$_['state'];
			Functions::log($state);
			$state=str_replace(":"," ",$state);
			$msg=htmlspecialchars_decode($state,ENT_QUOTES);
			HomeCheck_plugin_SendCli("info",$msg);
			break;
		
		case "gettestsecret":
			global $_,$myUser,$conf;
			$date = new DateTime(); 
			$ts=$date->getTimestamp();
			$secret=$conf->get('secret');
			$sync=0;
			if ($sync==1) {
				$code=$secret;
				$state="SYNC";
			}
			if ($sync==0) {
				$code=GetOTP($secret);
				$code=str_pad($code,6, "0");
				$state="DOWN";
			}				
			
			$ip='192.168.0.36';

			echo $code." ".$ts;
			$url = "http://".$ip."/{{";
	
			switch($state)
			{
				case "DOWN":
					$url .= "01";
					break;
				case "UP":
					$url .= "02";
					break;
				case "STOP":
					$url .= "00";
					break;
				case "SYNC":
					$url .= "12";
					$ts=$code;
					$code="111111";
					break;
				default:
					$url .= "10";
					$code="111111";
					break;
			}
			
			$url.=$code.$ts."}}";
			//echo $url;
			$ch = curl_init();
			
			curl_setopt($ch,CURLOPT_URL, $url);
			//curl_setopt($ch, CURLOPT_COOKIESESSION, false);
			curl_setopt($ch, CURLOPT_HEADER, true);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLINFO_HEADER_OUT, true);
			$result=curl_exec($ch);
			curl_close($ch);
			
			break;
		case 'get_radio_state':
			
			$alarme_Manager = new AlarmeSensorRadio("r");
			echo "RECEPTEURS"."<br>";
			$sensors = $alarme_Manager->loadAll(array('type'=>'SensorRXRADIO'));
			
			foreach ($sensors as $sensor) {	
				$len=20-strlen($sensor->description);
				echo $sensor->id." ".$sensor->description." ".str_repeat('_',$len)." ".$sensor->state." ".$sensor->radiocodeOn." ".$sensor->radiocodeOff."<br>";
			}
			echo "<br>"."<br>";
			echo "DETECTEURS"."<br>";
			$sensors = $alarme_Manager->loadAll(array('type'=>'SensorTXRADIO'));
			
			foreach ($sensors as $sensor) {	
				$len=20-strlen($sensor->description);
				echo $sensor->id." ".$sensor->description." ".str_repeat('_',$len)." ".$sensor->state." ".$sensor->radiocodeOn." "."<br>";
			}
			break;
			
		case 'HomeCheck_BCI_query':
			global $_,$myUser,$conf;
			
			$payload=$_['payload'];
			//echo "mpmp". $payload;
			Functions::log("BCI req: ".$payload);
			break;
			
		case 'HomeCheck_query':
			global $_,$myUser,$conf;
			
			$query=$_SERVER['REQUEST_URI'];
			$query=str_replace("/action.php?action=HomeCheck_query&","",$query);
			//echo rawurldecode($_SERVER['REQUEST_URI']);
			$i=0;
			foreach (explode('&', $query) as $chunk) {
				$param = explode("=", $chunk);
				if ($param) {
					if ($i==0) $query=urldecode($param[1]);
					if ($i==1) $token=urldecode($param[1]);
					$i++;
					//printf("La valeur du paramètre \"%s\" est \"%s\"<br/>\n", urldecode($param[0]), urldecode($param[1]));
				}
			}
			//echo $query." ".$token;
			//echo iconv("UTF-8", "ISO-8859-1", $_SERVER['REQUEST_URI']);
			//$req=ote_accent($_SERVER['REQUEST_URI']);
			//Functions::log("ini req  ".$req);
			//$req = mb_convert_encoding($_['query'],'HTML-ENTITIES','utf-8');
			//$req=htmlspecialchars_decode($_['query'],ENT_QUOTES);
			//$req= htmlentities($_['query'], ENT_QUOTES, "UTF-8");
			
			//$req='"'. ote_accent($query).'"';
			$req=ote_accent($query);
			Functions::log("ifff ".str_to_noaccent($req));

			//echo escapeshellarg($req);
			
			try {
				$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"run_Cmpvoice.py -t ".$token." ".escapeshellarg($req)."\"");
				Functions::log("query ".$return);
				//$cmd="python ".dirname(__FILE__)."/cmpvoice.py -t ".$token." ".escapeshellarg($req);
				//$cmd="sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"cmpvoice.py -t ".$token." ".escapeshellarg($req)."\"";
				//Functions::log("ifff ".$cmd);
				//exec($cmd . " > /dev/null 2>&1 &"); 	
				
			} catch (Exception $e) {
				echo 'Caught exception: ',  $e->getMessage(), "\n";
			}

			break;
			
		case 'sync_time':
			global $_;

			$state=$_['state'];
			Functions::log("Get GSM state ".$state);
			$date = new DateTime(); 
			$ts=$date->getTimestamp();
			$ts=$ts.":".date('Z');
			//echo date('Z');
			//$heure = date('H', time());
			//$minute=date('i', time());
			//$meridiem=date('a', time());
			//$ts=$heure.":".$minute.":".$meridiem;
			$json = json_encode($ts);
            echo ($json=='[]'?'{}':$json);
			break;
		case 'plugin_check_test':
			// aftestaf
			global $_,$myUser,$conf;
			
			//HomeCheck_send_notification("Alarm Activated","alarm","Alert");
			//break;
			$notif=$_['notif'];
			$loglines="Logs;";
			$logs = dirname(__FILE__).'/../../'.LOG_FILE ;
			//echo $logs;
			if(file_exists($logs)){
				$lines = file($logs);
				$nb_lines = count($lines)-1; // -1 pour ne pas avoir la ligne avec uniquement la virgule
				
				for($i=$nb_lines; $i>$nb_lines-25; $i--){
					$line=$lines[$i];
					$loglines .= $line.';';
				}
			}		

			//echo $loglines;		
			
			Functions::log("app send notif: ".$notif);
			//HomeCheck_send_notification($notif);
			//break;
			
			
			$HomeCheckManager = new Home_Check();	
			$admin= $HomeCheckManager->load(array("name"=>"emulator"));  // Alex / emulator
			
			$admin->location="dBNvitEEQ1mwCwyknAm9L8:APA91bHRKXfC3fEeUB5xA5qh-GqNmzeecHl0LP5MrzRO8Liw86Pu3BWsm3b3TJT6OKR_MBgpwdcCYXgvzHMZ4IdimN7pbvC1IUoC98GuobK6q-3aL5v32dfmBhHgaIQJ-X_7foe6M2yK";
			$fcmid=$admin->location;
			$admin->save();
			
			
			$currentDateTime = date('Y-m-d H:i:s');
			if ($admin!=null){
				
				echo "res ".$admin->imei." ".$admin->location;
				$fcmid=$admin->location;		

				$json_data=array(
					"to" => $fcmid,
					"collapse_key" => "New Message",
					"android_channel_id" => "HomeCheck",
					"notification" => [
					 "body" => "Alarm triggered ".$currentDateTime,
					 "title"=> "Alert"
					],
					"data" => [
					 "route" => "detect",
					 "topic"=> "alarm"
					]
				);
				
				$data = json_encode($json_data);
				//FCM API end-point
				$url = 'https://fcm.googleapis.com/fcm/send';
				//api_key in Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key
				$server_key = 'AAAAztbWxXY:APA91bEv6FdW7UpKv9Vi1cRZbuLSlLsPN15I0WKVPL3uzf9qlzP5hUbk7Z8aoH3d2Jz4Zr1jRy6DDgYTyCofMEdL1loHcwIJtXmUGLaW4-4ErybbpFj2zwiiBDLiEFVNDU_Dghmy50CX';
				//header with content_type api key
				$headers = array(
					'Content-Type:application/json',
					'Authorization:key='.$server_key
				);
				//CURL request to route notification to FCM connection server (provided by Google)
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
				$result = curl_exec($ch);
				echo $result;
				if ($result === FALSE) {
					die('Oops! FCM Send Error: ' . curl_error($ch));
				}
				curl_close($ch);
			} else {
				echo "not found";
			}
			
			
			break;
			$engine=18;
			$genericRelay = new AlarmeRelay();
			$genericRelay = $genericRelay->getById($engine);
			echo "state is ".$genericRelay->state;
	
			//echo getdeviceIP('7c:49:eb:b7:64:53');
			break;
			//Functions::log("test auto ".$_['url']);
			$url=$_['url'];
			$url="HomeCheckRelay_vocal_change_state";
			$cmd=$_['cmd'];
			$cmd=htmlspecialchars_decode($cmd,ENT_QUOTES);
			$cmd="month=*,day=*,week=*,day_of_week=*,hour=*,minute=5,jitter=120";
			//echo $url." -- ".$cmd;
			
			//echo "sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"/run_er.py\"";
			$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"run_er.py\"");
			
			echo $return;
			
			break;
			
			
			//$table = new detectIP();
			//$table->drop();
			//$table->create(); 
			
			//echo getdeviceIP('02:0f:b5:db:78:0b');
			//echo getdevicefromIP('192.168.0.21');

			//echo "<br>";
			//$ipManager=new detectIP();
			//$genericRadios = $ipManager->populate();
			//foreach ($genericRadios as $genericRadio) {
			//	echo $genericRadio->ip." ".$genericRadio->mac."</br>";
			//}
				
			//$conf->put('isopen','0');
			$state=$_['state'];
			$loc=$_['location'];
			$alarm=$_['alarm'];
			
			//HomeCheck_plugin_SendCli("info","HomeCheck Alert");
			//HomeCheck_plugin_SendCli("action","wake");
			if ($alarm==1) {
				//HomeCheck_plugin_SendGsm("HomeCheck Alert","Approach Home");
				Functions::log("Alarm detect: ");
				
			} 
			
			
			if ($state==1) {
				//HomeCheck_plugin_SendGsm("HomeCheck Alert","Approach Home");
				Functions::log("Loc: ".$loc);
				$res="false";
			} 
			elseif ($state==2) {
				HomeCheck_plugin_SendGsm("HomeCheck Alert","exit Home");
				Functions::log("exit home");
				$conf->put('isopen','0');
				$res="false";
			}
			elseif ($state==4) {
				Functions::log("check state");
				$isopen=$conf->get('isopen');
				if ($isopen==0) {
					$conf->put('isopen','1');
					Functions::log("was closed and now opened");
				} 
				$res="true";
			}
			elseif ($state==7) {  //set home pos
				Functions::log("set home pos ".$loc);
				list($lat, $long) = explode('_', $loc);
				
				$conf->put('homelat',$lat);
				$conf->put('homelong',$long);
				$res="true";
			}
			elseif ($state==8) {  //set home pos
				//Functions::log("get loc pos ".$loc);
				list($lat, $long,$id) = explode('_', $loc);
				$homelat=$conf->get('homelat');
				$homelong=$conf->get('homelong');
				//Functions::log("check ".$homelat." ".$homelong." ".$lat." ".$long);
				$distFromHome=vincentyGreatCircleDistance($lat, $long,$homelat,$homelong);
				Functions::log("Distance from home ".$distFromHome." ".$lat." ".$long." ".$id);
				
				if($distFromHome<10)
				{
					//HomeCheck_plugin_SendGsm("HomeCheck Alert","Arrived at Home");
					HomeCheck_plugin_update_state($id,1,1);
				}
				elseif ($distFromHome>100)
				{
					//HomeCheck_plugin_SendGsm("HomeCheck Alert","Leaving Home area");
					HomeCheck_plugin_update_state($id,0,1);
				}
				else {
					//HomeCheck_plugin_SendGsm("HomeCheck Alert","Enterring home area");
				}
				
				$res="true";
			}
			
			$response['content']=$res;
			echo json_encode($response);
			break;
			for ($i = 1; $i <= 3; $i++) {
				$adminphone="+33669329448";
				
				$cmd="\"SndTest:Domocom_".$adminphone."\"";
				Functions::log('test gsm  : '.$cmd);
				$command='python '.dirname(__FILE__).'/run_Client.py -d 192.168.0.10 -r 1 '.$cmd;
				$res=exec($command); //. " > /dev/null 2>&1 & 
				sleep(2);
			}
			//HomeCheckradio_update_gsm();
			break;
			
			echo HomeCheck_GetAdminPhone();
			break;
			$gsmmsg='Gsm+CIEV: &quot;MEPSAGE&quot;,: &quot;+33669329448&quot;,,&quot;2018/05/11,10:16:25+02&quot;Beb\0';
			$gsmmsg=htmlspecialchars_decode($gsmmsg);
			
			$gsmmsg=stripQuotes($gsmmsg);
			$lastIndex = strrpos($gsmmsg, '"');
			$ll=strrpos($gsmmsg, '\\0');
			echo $gsmmsg." last ind". $lastIndex." ".$ll; 
			
				$message=substr($gsmmsg,$lastIndex,strlen($gsmmsg));
				$pat = '/\"([^\"]*?)\"/'; // text between quotes excluding quotes
				preg_match_all($pat, $gsmmsg, $matches);
				echo $matches[0][1]." ";
				echo $matches[0][2]." ";
				//echo $matches[0][2];
				echo $message;
		
			//echo $_SERVER['SERVER_ADDR'];
			//echo $_SERVER['SERVER_PORT'];
			//HomeCheck_plugin_SendCli("info","hi af340");
			//HomeCheck_plugin_SendCli("info","it is me");
			// $state=$_['state'];
			// $url = "http://192.168.0.37/{{".$state."}}";
			// echo $state;
			//echo $url;
			// $ch = curl_init();
			
			// curl_setopt($ch,CURLOPT_URL, $url);
			//curl_setopt($ch, CURLOPT_COOKIESESSION, false);
			// curl_setopt($ch, CURLOPT_HEADER, true);
			// curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
			// curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			// curl_setopt($ch, CURLINFO_HEADER_OUT, true);
			// $result=curl_exec($ch);
			// curl_close($ch);
			// $cmd='python '.dirname(__FILE__).'/ExecCmd.py /usr/bin/backupcamip';
			// exec($cmd . " > /dev/null &"); 	
			// break;
			// $heure = date('i', time());
			// $meridiem=date('a', time());
			// $url="https://home.nest.com/api/0.1/weather/forecast/38000,FR";
			// $string = file_get_contents($url);
			// $json_a = json_decode($string, true);

			// echo $json_a['now'][current_temperature].'</br>';
			// echo $json_a['now'][current_humidity].'</br>';
			// echo $json_a['now'][sunrise].'</br>';
			// echo $json_a['now'][sunset].'</br>';

			//echo $heure." ".$meridiem;
			//save_conf('plugin_homecheck_modeday','day');
			//echo get_conf_value("plugin_homecheck_humidity");
			//echo get_conf_value("plugin_homecheck_modeday");
			//HomeCheck_plugin_SendCli("action","wake");
			
			//HomeCheck_plugin_SendCli("info","\"HomeCheck Alert\"");
			//HomeCheck_plugin_SendCli("info","\"Sensor test opened \"");
			//$response="HomeCheck Alert";
			//HomeCheck_plugin_SendCli("info","\"".$response."\"");

			//echo get_conf_value('plugin_homecheck_temp');
			//$Id="92";
			//$alarme_Manager = new AlarmeSensorRadio("r");
			//$alarme = $alarme_Manager->load(array('type'=>'SensorRXRADIO','id'=>$Id));
			//echo $alarme->state;
			break;
	}
}

// functions
/**
 * Calculates the great-circle distance between two points, with
 * the Vincenty formula.
 * @param float $latitudeFrom Latitude of start point in [deg decimal]
 * @param float $longitudeFrom Longitude of start point in [deg decimal]
 * @param float $latitudeTo Latitude of target point in [deg decimal]
 * @param float $longitudeTo Longitude of target point in [deg decimal]
 * @param float $earthRadius Mean earth radius in [m]
 * @return float Distance between points in [m] (same as earthRadius)
 */
function vincentyGreatCircleDistance(
  $latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371000)
{
  // convert from degrees to radians
  $latFrom = deg2rad($latitudeFrom);
  $lonFrom = deg2rad($longitudeFrom);
  $latTo = deg2rad($latitudeTo);
  $lonTo = deg2rad($longitudeTo);

  $lonDelta = $lonTo - $lonFrom;
  $a = pow(cos($latTo) * sin($lonDelta), 2) +
    pow(cos($latFrom) * sin($latTo) - sin($latFrom) * cos($latTo) * cos($lonDelta), 2);
  $b = sin($latFrom) * sin($latTo) + cos($latFrom) * cos($latTo) * cos($lonDelta);

  $angle = atan2(sqrt($a), $b);
  return $angle * $earthRadius;
}

function hex2rgb($hex) {
   $hex = str_replace("#", "", $hex);

   if(strlen($hex) == 3) {
      $r = hexdec(substr($hex,0,1).substr($hex,0,1));
      $g = hexdec(substr($hex,1,1).substr($hex,1,1));
      $b = hexdec(substr($hex,2,1).substr($hex,2,1));
   } else {
      $r = hexdec(substr($hex,0,2));
      $g = hexdec(substr($hex,2,2));
      $b = hexdec(substr($hex,4,2));
   }
   $rgb = array($r, $g, $b);
   return implode(",", $rgb); // returns the rgb values separated by commas
   //return $rgb; // returns an array with the rgb values
}

function save_conf($key,$val) {
	$alarme_conf = new AlarmeConf();
	$alarme_res = $alarme_conf->load(array("conf"=>$key));
	$alarme_res->setValue($val);
	$alarme_res->save();
}

function get_conf_value($key) {
	$alarme_conf = new AlarmeConf("r");
	$alarme_conf = $alarme_conf->load(array("conf"=>$key));
	$status=$alarme_conf->getValue();
	return $status;
	
}

function HomeCheck_backup_all(){

	$file = dirname(__FILE__)."//HomeCheck.json";
	 
	if ($file != "" && file_exists($file))
	{
		$size = filesize(($file))+1;
		header('Content-Type: application/json');
		header("Content-Type: application/force-download; name=HomeCheck.json");
		header("Content-Transfer-Encoding: binary");
		header("Content-Length: $size");
		header("Content-Disposition: attachment; filename=HomeCheck.json" );
		header("Expires: 0");
		header("Cache-Control: no-cache, must-revalidate");
		header("Pragma: no-cache");
		readfile(($file));
		exit();
	}
}

function HomeCheck_Upload() {
	$uploaddir = dirname(__FILE__);
	$uploadfile = $uploaddir .'//'. basename($_FILES['userfile']['name']);

	//echo '<pre>';
	if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
		echo "Le fichier est valide, et a été téléchargé
			   avec succès:\n";
		HomeCheck_restore_all();
	} else {
		echo "Erreur de restauration :\n";
	}
	
	header('Location: /index.php?module=Home_Check&block=ADAlarme&sousblock=AlarmeGeneral');
	exit;
	//echo 'Voici quelques informations de débogage :';
	//print_r($_FILES);

	//echo '</pre>';
}

function HomeCheck_restore_all(){
	
	$json = file_get_contents(dirname(__FILE__)."//HomeCheck.json");
	
	$obj = json_decode($json, true);
	//print_r($obj);
	$first=true;
	foreach($obj as $key=>$value) { 
		//echo "key is ".$key."</br>";
		
		$jsonIterator = new RecursiveIteratorIterator(
		new RecursiveArrayIterator($value),
		RecursiveIteratorIterator::SELF_FIRST);
		foreach ($jsonIterator as $keyobj => $val) {
			
			if(is_array($val)) {
				//echo $key."</br>";;
				if (!$first) $cls->save();
				$first=false;
				switch($key)
				{
				case 'membres':
					$cls = new Home_Check();
					break;
				case 'ipcameras':
					$cls=new IPCamera();
					break;
				case 'relaisradio':
					$cls = new AlarmeSensorRadio();
					break;
				case 'relaiswifi':
					$cls = new AlarmeRelay();
					break;
				default:
					break;
				}
			} else {
				if ($keyobj!="id") {
					$cls->$keyobj=$val;
				}
				//echo "valeur is $key => $val\n";
			
			}
		}
		$cls->save();
		//echo "next </br>";
		//echo "</br>";
		
	}
	
}
function get_style() {
	$wstyle='';
	$wstyle.='
	<!-- CSS -->
				<style>

				   .genericradio_relay_pane {
					background: none repeat scroll 0 0 #50597b;
					list-style-type: none;
					margin: 0;
					cursor:default;
					width: 100%;
				}
				.genericradio_relay_pane li {
					background: none repeat scroll 0 0 #50597b;
					display: inline-block;
					margin: 0 1px 0 0;
					padding: 10px;
					cursor:default;
					vertical-align: top;
				}
				.genericradio_relay_pane li h2 {
					color: #ffffff;
					font-size: 16px;
					margin: 0 0 5px;
					padding: 0;
					cursor:default;
				}
				.genericradio_relay_pane li h1 {
					color: #B6BED9;
					font-size: 14px;
					margin: 0 0 10px;
					padding: 0;
					cursor:default;
				}

				.genericradio_relay_pane li.genericradio-case{
					background-color:  #373f59;
					width: 55px;
					cursor:pointer;
				}
				.genericradio-case i{
					color:#8b95b8;
					font-size:50px;
					transition: all 0.2s ease-in-out;
				}
				.genericradio-case.active i{
					color:#ffffff;
					text-shadow: 0 0 10px #ffffff;
				}

				.genericradio-case.active i.fa-lightbulb-o{
					color:#FFED00;
					text-shadow: 0 0 10px #ffdc00;
				}
				.genericradio-case.active i.fa-power-off{
					color:#BDFF00;
					text-shadow: 0 0 10px #4fff00;
				}

				.genericradio-case.active i.fa-flash{
					color:#FFFFFF;
					text-shadow: 0 0 10px #00FFD9;
				}

				.genericradio-case.active i.fa-gears{
					color:#FFFFFF;
					text-shadow: 0 0 10px #FF00E4;
				}

			</style>

			<!-- CSS -->';
			
			return ($wstyle);
}
			
function getdeviceIP($mac) {
	$ipManager = new detectIP();
	//$device = $ipManager->load(array('mac'=>$mac));
	
	$devices  = $ipManager->populate(); //loadAll(array('type'=>'SensorTXRADIO'));
	
	 substr($dynamicstring, -8);
	 
	$ip=Null;
	foreach($devices as $device) {
		echo $device->mac."<br>";
		if (strtolower(substr($device->mac,-8))==strtolower(substr($mac,-8))) {
			$ip=$device->ip;
		}
	}
	return $ip;
	
}

function getdevicefromIP($ip) {
	$ipManager = new detectIP();
	$device = $ipManager->load(array('ip'=>$ip));
	return $device->mac;
}


function pingcli($host,$port=80) {
	//$host = '193.33.186.70'; 
	//$port = 80; 
	$waitTimeoutInSeconds = 1; 
	if($fp = fsockopen($host,$port,$errCode,$errStr,$waitTimeoutInSeconds)){   
	   // It worked 
	} else {
	   // It didn't work 
	} 
	fclose($fp);
}

function plugin_alarme_load_sensor_GPIO($GPIO, $time, $mode)
{
	//mode = 1 pour les sensor, mode = 0 pour les activations/désactivations
	$command=dirname(__FILE__)."/AlarmeDetector ".$GPIO." ".$time." ".$mode." > /dev/null &";
	$return = exec($command, $out, $return);
	return ($return);
}

function plugin_alarme_load_stopSensor_GPIO()
{
	$command=dirname(__FILE__)."/AlarmeStop";
	$return = exec($command, $out, $return);
	return ($return);
}

function HomeCheck_GetReceiver($code)
{
	$alarme_Manager = new AlarmeSensorRadio("r");
	$alarmes = $alarme_Manager->populate(); //loadAll(array('type'=>'SensorTXRADIO'));
	
	$source=Null;
	foreach($alarmes as $alarme) {
		if ($alarme->radiocodeOn==$code | $alarme->radiocodeOff==$code ) {
			if ($alarme->type=='SensorTXRADIO') {
				$source=$alarme;
			}
			else {
				 $source="RX"; }
		}
	}
	return $source;
}

function HomeCheckRelay_send_intr($code)
{
	// send intr to all relays not switch
	$Relay_Manager = new AlarmeRelay("r");
	$relays = $Relay_Manager->loadAll(array('isSwitch'=>0));

	foreach ($relays as $genericRelay) {
		// manage with wifi relay
		$ip=$genericRelay->IPadress; 
		Functions::log('cmd ip '.$ip); 
		$cmd='python '.dirname(__FILE__).'/run_SaveTemp.py -c '.$code." ".$ip;
		exec($cmd . " > /dev/null &"); 	
		Functions::log('cmd '.$cmd); 
		sleep(1);
	}
	
}


// gpio
function HomeCheckGpio_plugin_change_state($engine, $state) {
	global $conf;
	
	$alarme_Manager = new AlarmeSensor("r");
	$alarme=$alarme_Manager->getById($engine);
	$numGPIO=(int)$alarme->getNumGPIO();
	#$stateGPIO=(int)$alarme->getStateGPIO();
		
	$desc=$alarme->getDescription(); 	
	$numgpio=$alarme->getNumGPIO(); 
	Functions::log('gpio Action '.$desc." numgp ".$numGPIO." state ".$state); 						
	$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"run_Gpio.py -g ".$numgpio." ".$state."\"");
			
}

// group
function HomeCheckGroup_plugin_change_state($engine, $state,$auto) {
	global $conf;
	$GroupManager = new ActionGroup();
	$group=$GroupManager->getById($engine);
	Functions::log('group Actions '); 
	$group_Manager = new ActionCollection("r");
	$actions = $group_Manager->loadAll(array('type'=>$engine)); 
	// launch all action from same group engine 
	foreach ($actions as $action) {
		$linkr=$action->linkradio;
		Functions::log('start '.$linkr." state ".$state." isauto ".$auto); 
		HomeCheck_Link_Action($linkr,$state,$auto);
		
	}				
}

//relay
function HomeCheckRelay_plugin_change_state($engine, $state,$auto=0,$cde="AAA")
{
	/*
	value="1">DomoSwitch
	value="0">Relai 433Mhz
	value="2">Relai Alarme
	value="3">Relai Inter
	value="4">Relai GSM
	value="5">Weelight*/
	global $conf;
	$genericRelay = new AlarmeRelay();
    $genericRelay = $genericRelay->getById($engine);
	$ip=$genericRelay->IPadress;
	$rt=0;
	
	$rt+=1;
	$date = new DateTime(); 
	$ts=$date->getTimestamp();
	$secret=$conf->get('secret');
	
	$curstate=intval($genericRelay->state);
	$isauto=intval($auto);
	
	Functions::log("Relay id ".$engine." curstate ".$curstate." isauto ".$isauto);
	if ($curstate==0 && $isauto==1 && $genericRelay->isSwitch==1) {
		Functions::log("domoswtich from auto with pos stop, cancel state ".$state);
		return; //if domoswitch on pos stop, no action from scheduler
	}
	
	Functions::log("relay change state from auto ".$auto." state ".$genericRelay->state." cde ".$cde);
	if ($genericRelay->isSwitch==3){
		$code="_".$genericRelay->iddevice;
		$ts="";
	}
	elseif ($genericRelay->isSwitch==5){  // yeelight
		$act=($state=="UP")?"2":"1";
		$cmd='python '.dirname(__FILE__).'/run_Yeelamp.py -i '.$act." ".$ip;
		Functions::log("yee ".$cmd);
		//exec($cmd . " > /dev/null &"); 	
		$return=shell_exec("sudo ".dirname(__FILE__)."/raspberrypiwifi.sh \"run_Yeelamp.py -i ".$act." ".$ip."\"");
		Functions::log("change state ".$return);
		$genericRelay->state=$act;
		$genericRelay->save();
		return;
	}
	elseif ($genericRelay->isSwitch==6) {  // BW-SHP6
		$act=($state=="UP")?"On":"Off";
		$url="cm?cmnd=Power%20".$act;
		$command='python '.dirname(__FILE__).'/run_Client.py -d '.$ip.' -r 2 '.$url;
		exec($command . " > /dev/null &");
		sleep(1);
		Functions::log("send relay ".$ip." cmd ".$url);
	

		$genericRelay->state=$act;
		$genericRelay->save();
		return;
	}
	elseif ($cde=="AAA") {
		$code=GetOTP($secret);
		//$code=str_pad($code,6, "0");
		$code=str_pad($code, 6, "0", STR_PAD_LEFT);
	}
	else {
		$code=$cde;
	}
	//echo $ts." ".$code."</br>";
	//$url = http://".$ip."/{{";
	
	switch($state)
	{
		case "DOWN":
			$url .= "01";
			break;
		case "UP":
			$url .= "02";
			break;
		case "STOP":
			$url .= "00";
			break;
		case "SYNC":
			$url .= "12";
			$ts=$code;
			$code="111111";
			break;
		default:
			$url .= "10";
			$code="111111";
			break;
	}
	
	if ($genericRelay->isSwitch==5){
		
	} else {	
		
		$url.=$code.$ts; //."}}";
		//echo $url;
		//echo $HomeCheck->ip;
		$command='python '.dirname(__FILE__).'/run_Client.py -d '.$ip.' -r 1 '.$url;
		exec($command . " > /dev/null &");
		sleep(3);
		Functions::log("send relay ".$ip." cmd ".$url);
	}

}


function HomeCheckRelay_plugin_update_state($state,$relay)
{
	//$genericRelay = new AlarmeRelay();
	//$genericRelay = $genericRelay->load(array('IPadress'=>$ip));
	//if (empty($genericRelay)) return;
	
	switch($state)
	{
		case "DOWN":
			$intstate="1";
			break;
		case "UP":
			$intstate="2";
			break;
		case "STP":
			$intstate="0";
			break;
		case "SHOUT":
			$intstate="10";
			break;
			
		case "SHD":
			$intstate="12";
			break;
			
		case "NSHS":
			$intstate="911";
			break;
		case "WPD":
			$intstate="13";
			break;
		default:
			$intstate="-1";
			break;
	}
	Functions::log('upd: '.$ip.' state: '.$intstate." ".$relay->description);
	if ($intstate!="-1") {
		$relay->state=$intstate;
		$relay->save();
		
	}
}


function GetRelayState($state) {
	switch($state)
	{
		case "1":
			$stat="DOWN";
			break;
		case "2":
			$stat="UP";
			break;
		case "0":
			$stat="STOP";
			break;
		case "12":
			$stat="SYNCHRO";
			break;
		case "13":
			$stat="WRONG PASS, SYNCHRO NEEDED";
			break;
		default:
			$stat="Unknown";
			break;
	}
	return $stat;
}

function plugin_alarme_sendSms($user, $pass, $message)
{
	$ch = curl_init();
	$url = "https://smsapi.free-mobile.fr/sendmsg?user=".$user."&pass=".$pass."&msg=".htmlspecialchars_decode($message,ENT_QUOTES);
	
	curl_setopt($ch,CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_exec($ch);
	
	//retour code http
	$return = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);
	return ($return);
}


function plugin_alarme_LoadADSensor()
{
	global $myUser;
	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeSensor("r");
		$alarmes = $alarme_Manager->loadAll(array('type'=>'SensorADGPIO'));
		?>
			<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Description détecteur</th>
					<th width=100>Numéro du GPIO</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ ?>
				<tr>
					<td>
						<?php echo $alarme->getDescription(); ?>
					</td>
					<td width=100>
						<?php
							echo $alarme->getNumGPIO(); 
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_ADSensor(<?php echo $alarme->getId(); ?>);" title="Supprimer ce détecteur"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  ?>
		</table>
		<?php
	}
}

function load_alarme_CameraIP()
{
	global $myUser;
	if(!$myUser) throw new Exception('Vous devez être connecté pour effectuer cette action');
	$cameraManager = new IPCamera();
	$cameras = $cameraManager->populate();
	$roomManager = new Room();
	$rooms = $roomManager->loadAll(array('state'=>'0'));

	//Si on est en mode modification
	
	?>
	<legend>Consulter les sondes existants</legend>
	<table class="table table-striped table-bordered table-hover">
		<thead>
			<tr>
				<th>Nom</th>
				<th>IP</th>
				<th>Pièce</th>
                <th>Marque</th> 
				<th colspan="2"></th>
				
			</tr>
		</thead>
	
		<?php foreach($cameras as $camera){ 
			$room = $roomManager->load(array('id'=>$camera->location)); 
		?>
		<tr>
			<td><?php echo $camera->label; ?></td>
			<td><?php echo $camera->ip; ?></td>
			<td><?php echo $room->getName(); ?></td>
            <td><?php echo $camera->brand; ?></td>
			<td>
			
				<a class="btn" href="index.php?module=Home_Check&block=ADAlarme&sousblock=CameraIP&id=<?php echo $camera->id; ?>"><i class="fa fa-pencil"></i></a>
				<div class="btn" onclick="plugin_ipcam_delete(<?php echo $camera->id; ?>,this);"><i class="fa fa-times"></i></div>
			</td>
			</td>
		</tr>
		<?php } ?>
	</table>
	
	<?php
	
}

function plugin_alarme_LoadRelay()
{
	global $myUser;
	if($myUser!=false)
	{
		$relay_Manager = new AlarmeRelay("r");
		$relays = $relay_Manager->populate();
			
		?>
			<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Description détecteur</th>
					<th width=100>Adress IP</th>
					<th width=100>Mac Adresse</th>
					<th width=100>Type Relai</th>
					<th width=100>Commande vocale ON</th>
					<th width=100>Commande vocale OFF</th>
					<th width=100>Commande vocale Arrêt</th>
					<th width=100>Etat</th>
				</tr>
			</thead>

			<?php 
			foreach($relays as $relay) {
				$stat=GetRelayState($relay->state);
				$typ=$relay->isSwitch;
				switch ($typ) {
					case 0:
						$atyp="433Mhz";
						break;
					case 1:
						$atyp="DomoSwtich";
						break;
					case 2:
						$atyp="Alarme";
						break;
					case 3:
						$atyp="Interrupt";
						break;
					case 4:
						$atyp="GSM";
						break;
					case 5:
						$atyp="Weelight";
						break;
					case 6:
						$atyp="BW-SHP6";
						break;
				}
			 ?>
				<tr>
					<td><?php echo $relay->getDescription(); ?></td>
					<td width=100><?php echo $relay->IPadress;?></td>
					<td width=100><?php echo $relay->macaddr;?></td>
					<td width=100><?php echo $atyp;?></td>
					<td width=100><?php echo $relay->onCommand;?></td>
					<td width=100><?php echo $relay->offCommand;?></td>
					<td width=100><?php echo $relay->stopCommand;?></td>
					<td width=100><?php echo $stat;?></td>
					<td>
						<a class="btn" href="index.php?module=Home_Check&block=Sensor&sousblock=SensorRELAY&id=<?php echo $relay->id; ?>#BottomPage">
							<i class="fa fa-pencil"></i>
						</a>
						<div class="btn" onclick="plugin_HomeCheck_RelayDelete('<?php echo $relay->id ?>',this);">
						<i class="fa fa-times"></i>
						</div>
					</td>
				</tr>
				<?php
			}
			$exportRelays = $relays;
			foreach ($exportRelays as $key => $exportRadio) {
				unset($exportRelays[$key]->id);
				unset($exportRelays[$key]->state);
				}
			 ?>
             </table>
             

		<?php
	}
}

function plugin_alarme_LoadSensorRadio($type)
{
	global $myUser;
	if($myUser!=false)
	{

		$alarme_Manager = new AlarmeSensorRadio("r");
		
		$alarmes = $alarme_Manager->loadAll(array('type'=>$type));
		if ($type=="SensorTXRADIO") 
		{
			$ssbloc="SensorTXRADIO";
		}
		else {
			$ssbloc="SensorRXRADIO";
		}

		?>
			<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Description détecteur</th>
					<th width=100>Code ON</th>
					<th width=100>Code OFF</th>
					
					<?php if ($ssbloc==SensorRXRADIO) { ?>
					<th width=100>Commande vocale ON</th>
					<th width=100>Commande vocale OFF</th>
					<?php }
					else {
					?>	
					<th width=100>Detecteur Type</th>
					<th width=100>Relai associé</th>	
					<?php }
					?>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme) {
				
				$id=$alarme->id ;
				$type=$alarme->type ;
				$link=$alarme->linkradio;
				$linkRadio=$alarme_Manager->getById($link);
				$typsensor=$alarme->sensorTxTyp;
				if ($typsensor==0) {$ts="Autre";}
				if ($typsensor==1) {$ts="Présence";}
				if ($typsensor==2) {$ts="Ouverture";}
				if ($typsensor==3) {$ts="Interrupteur";}
			 ?>
				<tr>
					<td><?php echo $alarme->getDescription(); ?></td>
					<td width=100><?php echo $alarme->radiocodeOn;?></td>
					<td width=100><?php echo $alarme->radiocodeOff;?></td>
					<?php if ($ssbloc==SensorRXRADIO) { ?>
					<td width=100><?php echo $alarme->onCommand;?></td>
					<td width=100><?php echo $alarme->offCommand;?></td>
					<?php } 
					else { ?>
					<td width=100><?php echo $ts;?></td>
					<td width=100><?php echo $linkRadio->description;?></td>
					<?php }
					?>
					<td>
						<a class="btn" href="index.php?module=Home_Check&block=Sensor&sousblock=<?php echo $ssbloc?>&id=<?php echo $alarme->id; ?>#BottomPage">
							<i class="fa fa-pencil"></i>
						</a>
							<div class="btn" onclick="plugin_HomeCheck_RadioDelete('<?php echo $alarme->id ?>','<?php echo $alarme->type ;?>',this);">
							<i class="fa fa-times"></i>
						</div>
					</td>
				</tr>
				<?php
			}
			$exportRadios = $alarmes;
			foreach ($exportRadios as $key => $exportRadio) {
				unset($exportRadios[$key]->id);
				unset($exportRadios[$key]->state);
				}
			 ?>
             </table>
             

		<?php
	}
}

function plugin_alarme_LoadSensor()
{
	global $myUser;
	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeSensor("r");
		$alarmes = $alarme_Manager->loadAll(array('type'=>'SensorGPIO'));
		?>
			<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Description détecteur</th>
					<th width=100>Numéro du GPIO</th>
					<th width=100>Commande vocale ON</th>
					<th width=100>Commande vocale OFF</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ ?>
				<tr>
					<td><?php echo $alarme->getDescription(); ?></td>
					<td width=100><?php echo $alarme->getNumGPIO(); ?> </td>
					<td width=100><?php echo $alarme->onCommand;?></td>
					<td width=100><?php echo $alarme->offCommand;?></td>
					
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_Sensor(<?php echo $alarme->getId(); ?>);" title="Supprimer ce détecteur"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  ?>
		</table>
		<?php
	}
}
// 
function plugin_alarme_LoadActions_SMS()
{
	global $myUser;

	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeSMS("r");
		$alarmes = $alarme_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Type d'alarme</th>
					<th>Utilisateur</th>
					<th>Mot de passe</th>
					<th>Message</th>
					<th>Tester</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ ?>
				<tr>
					<td>
						<?php echo $alarme->getType(); ?>
					</td>
					<td>
						<?php
							echo $alarme->getIdentifiant_user(); 
						?>
					</td>
					<td>
						<?php
							echo str_repeat("*", strlen($alarme->getIdentifiant_mdp()));
						?>
					</td>
					<td>
						<?php
							echo htmlspecialchars_decode($alarme->getMessage(),ENT_QUOTES);
						?>
					</td>
					<td width=50>
						<a class="btn btn-success" onclick="plugin_alarme_test_SMS_ponctuel(<?php echo '\''.$alarme->getId().'\''; ?>);"
						 title="Tester l'envoie de SMS"  ><i class="fa fa-refresh" id ="plugin_alarme_test_sms<?php echo $alarme->getId(); ?>" style="color:white" ></i></a>
						<?php
						echo '<span id="plugin_alarme_test_spanId'.$alarme->getId().'" style="display:none;"></span>';
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_SMS(<?php echo $alarme->getId(); ?>);" title="Supprimer cette alarme"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  ?>
		</table>
		<?php
	}	
}

function plugin_alarme_LoadActions_Email()
{
	global $myUser,$_;
	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeEmail("r");
		$alarmes = $alarme_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Adresse destinataire</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ ?>
				<tr>
					<td>
						<?php echo $alarme->getEmailExp(); ?>
						<br/>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_Email(<?php echo $alarme->getId(); ?>);" title="Supprimer cette alarme"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  ?>
		</table>
		<?php
	}
}

function plugin_alarme_LoadActions_GPIO()
{
	global $myUser,$_;

	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeGPIO("r");
		$alarmes = $alarme_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Description GPIO</th>
					<th width=100>Numéro du GPIO</th>
					<th width=100>Etat du GPIO lors d'une alerte</th>
					<th width=100>Tester</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ ?>
				<tr>
					<td>
						<?php echo $alarme->getDescriptionGPIO(); ?>
					</td>
					<td width=100>
						<?php
							echo $alarme->getNumGPIO(); 
						?>
					</td>
					<td width=100>
						<?php
							echo $alarme->getStateGPIO();
						?>
					</td>
					<td width=100>
						<a class="btn btn-success" onclick="plugin_alarme_test_GPIO_ponctuel(<?php echo '\''.$alarme->getId().'\''; ?>);"
						 title="Tester le changement d'état d'un GPIO endant 3 secondes"  ><i class="fa fa-refresh" id ="plugin_alarme_test_gpio<?php echo $alarme->getId(); ?>" style="color:white" ></i></a>
						<?php
						echo '<span id="plugin_alarme_test_spanId'.$alarme->getId().'" style="display:none;"></span>';
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_GPIO(<?php echo $alarme->getId(); ?>);" title="Supprimer cette alarme"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  ?>
		</table>
		<?php
	}
}
	
function plugin_alarme_LoadActions_Vocales()
{
	global $myUser,$_;

	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeActionVocal("r");
		$alarmes = $alarme_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th width=150>Message</th>
					<th width=150>Tester</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ ?>
				<tr>
					<td>
						<?php echo $alarme->getMessageVocal(); ?>
					</td>
					<td width=100>
						<a class="btn btn-success" onclick="plugin_alarme_test_Vocal_ponctuel(<?php echo '\''.$alarme->getId().'\''; ?>);"
						 title="Tester la diction de cette phrase"  ><i class="fa fa-refresh" id ="plugin_alarme_test_Vocal<?php echo $alarme->getId(); ?>" style="color:white" ></i></a>
						<?php
						echo '<span id="plugin_alarme_test_spanId'.$alarme->getId().'" style="display:none;"></span>';
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_Vocal(<?php echo $alarme->getId(); ?>);" title="Supprimer cette alarme"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  ?>
		</table>
		<?php
	}
}	

function plugin_alarme_LoadCamera()
{
	global $myUser;

	if($myUser!=false)
	{		
		$alarme_conf = new AlarmeConf("r");
		$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_CameraDirectory"));
		$dir=$alarme_conf->getValue();
		echo $dir;
		$ScanDir=scandir($dir, 1);
		foreach($ScanDir as $value) 
		{ 
			// on exclue les fichier system, et on filtre seulement les images Jpg et les videos mp4
			if($value === '.' || $value === '..') {continue;}
			elseif(strstr($value ,'.jpg')!=false)
			{
				echo '<div style="position: relative;">';
				echo '<span style="position:absolute; top: 5px; left: 5px; z-index: 100;" ><a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_camera(\''.$value.'\');" title="Supprimer cette photo"><i class="fa fa-times" style="color:white" ></i></a></span>';
				echo '<img class="img-polaroid img-rounded" src="plugins/Home_Check/camera/'.$value.'" ><br/>';
				echo '</div>';
			}
			elseif((strstr($value ,'.mp4')!=false))
			{
				echo '<div style="position: relative;">';
				echo '<span style="position:absolute; top: 5px; left: 5px; z-index: 100;" ><a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_camera(\''.$value.'\');" title="Supprimer cette photo"><i class="fa fa-times" style="color:white" ></i></a></span>';
				echo '<video controls="controls" type="video/mp4" src="plugins/Home_Check/camera/'.$value.'">Vous n\'avez pas de navigateur moderne, donc pas de balise video HTML5 !</video>';
				echo '</div>';
			}
		}
	}
}

function plugin_alarme_LoadPersonnes()
{
	global $myUser,$conf;

	if($myUser!=false)
	{
		$People_Manager = new Home_Check("r");
		$Home_Checks = $People_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th width=50>Nom</th>
					<th width=200>Admin</th>
					<th width=100>Présente</th>
					<th width=200>Console</th> 							
				</tr>
			</thead>
			
			<?php 
				foreach ($Home_Checks as $HomeCheck) {
				?>
				<tr>
					<td><?php echo $HomeCheck->name; ?></td>
					<td><?php echo $HomeCheck->isadmin==1?"Yes":"No"; ?></td>
					<td><?php echo $HomeCheck->state==1?"Yes":"No"; ?></td>
					<td><?php echo $HomeCheck->isclientserv==1?"Yes":"No"; ?></td>
					<td width=50>
						<a class="btn" href="index.php?module=Home_Check&block=ADAlarme&sousblock=GestionMembres&id=<?php echo $HomeCheck->id; ?>#BottomPage">
							<i class="fa fa-pencil"></i>
						</a>
						<div class="btn" onclick="plugin_HomeCheck_delete(<?php echo $HomeCheck->id; ?>,this);">
							<i class="fa fa-times"></i>
						</div>
					</td>
				</td>
			</tr>
			<?php
			}
			$exportRadios = $Home_Checks;
			foreach ($exportRadios as $key => $exportRadio) {
				unset($exportRadios[$key]->id);
				unset($exportRadios[$key]->state);
			}
			?>
		</table>
		
		<?php
	}
}

function plugin_alarme_LoadCommandes_Vocales()
{
	global $myUser,$conf;

	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeCommandeVocale("r");
		$alarmes = $alarme_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th width=50>Type</th>
					<th width=200>Commande</th>
					<th width=100>Confidence</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ 
				?>
				<tr>
					<td>
						<?php echo $alarme->getType(); ?>
					</td>
					<td>
						<?php echo $conf->get('VOCAL_ENTITY_NAME').' : '.$alarme->getCommande(); ?>
					</td>
					<td>
						<?php echo $alarme->getConfidence(); ?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_CommandeVocale(<?php echo $alarme->getId(); ?>);" title="Supprimer cette alarme"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  
			?>
		</table>
		<?php
	}
}	

function plugin_alarme_LoadActionsURL()
{
	global $myUser;

	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeURL("r");
		$alarmes = $alarme_Manager->loadAll(array('type'=>'ActionUrl'));
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th width=200>URL</th>
					<th width=150>Tester</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ 
				?>
				<tr>
					<td>
						<?php echo $alarme->getUrl(); ?>
					</td>
					<td width=100>
						<a class="btn btn-success" onclick="plugin_alarme_test_actionsUrl_ponctuel(<?php echo '\''.$alarme->getId().'\''; ?>);"
						 title="Tester cette URL"  ><i class="fa fa-refresh" id ="plugin_alarme_test_actionsUrl<?php echo $alarme->getId(); ?>" style="color:white" ></i></a>
						 <br>
						<?php
						echo '<span id="plugin_alarme_test_spanId'.$alarme->getId().'" style="display:none;"></span>';
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_Url(<?php echo $alarme->getId(); ?>);" title="Supprimer cette URL"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  
			?>
		</table>
		<?php
	}
}	

function plugin_alarme_LoadActionsShell()
{
	global $myUser;

	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeShell("r");
		$alarmes = $alarme_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th width=200>Shell</th>
					<th width=150>Tester</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ 
				?>
				<tr>
					<td>
						<?php echo $alarme->getShell(); ?>
					</td>
					<td width=100>
						<a class="btn btn-success" onclick="plugin_alarme_test_actionsShell_ponctuel(<?php echo '\''.$alarme->getId().'\''; ?>);"
						 title="Tester cette commande"  ><i class="fa fa-refresh" id ="plugin_alarme_test_actionsShell<?php echo $alarme->getId(); ?>" style="color:white" ></i></a>
						 <br>
						<?php
						echo '<span id="plugin_alarme_test_spanId'.$alarme->getId().'" style="display:none;"></span>';
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_Shell(<?php echo $alarme->getId(); ?>);" title="Supprimer cette commande"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  
			?>
		</table>
		<?php
	}
}	

function plugin_alarme_LoadActionGroup()
{
	global $myUser,$conf;

	if($myUser!=false)
	{
		$group_Manager = new ActionGroup("r");
		$actions = $group_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th width=50>Nom</th>
					<th width=200>Command ON</th>
					<th width=100>Command OFF</th>					
				</tr>
			</thead>
			<?php 
				foreach ($actions as $action) {
				?>
				<tr>
					<td><?php echo $action->description; ?></td>
					<td><?php echo $action->onCommand; ?></td>
					<td><?php echo $action->offCommand; ?></td>
					
					<td width=50>
						<a class="btn" href="index.php?module=Home_Check&block=Actions&sousblock=ActionsGroup&id=<?php echo $action->id; ?>#BottomPage">
							<i class="fa fa-pencil"></i>
						</a>
						<div class="btn" onclick="plugin_ActionGroup_delete(<?php echo $action->id; ?>,this);">
							<i class="fa fa-times"></i>
						</div>
					</td>
				</td>
			</tr>
			<?php
			}
			?>
		</table>
		<?php
	}
}

function plugin_alarme_LoadActionProg($typ)
{
	global $myUser,$conf;

	if($myUser!=false)
	{
		$group_Manager = new ExecCmd("r");
		$actions = $group_Manager->loadAll(array('typ'=>$typ)); 
		?>
		<div id="xhrAlarme">
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th width=50>Nom</th>
					<th width=200>pid</th>
					<th width=100>cmd</th>		
					<th width=100>url</th>		
					<?php if ($typ==2) {?>	
						<th width=100>Seuil Lumi</th>	
					<?php }?>	
				</tr>
			</thead>
			<?php 
				foreach ($actions as $action) {	
				?>
				<tr>
					<td><?php echo $action->description; ?></td>
					<td><?php echo $action->pid; ?></td>
					<td><?php echo $action->cmdline; ?></td>
					<td><?php echo $action->url; ?></td>
					<?php if ($typ==2) {?>
						<td><?php echo $action->pic; ?></td>
						<?php }?>
					<td width=50>
						<div class="btn" title="Next run!" onclick="plugin_ActionProg_nextrun(<?php echo $action->id; ?>,this);">
							<i class="fa fa-clock-o"></i>
						</div>
						<div class="btn" title="Pause/resume" onclick="plugin_ActionProg_mod(<?php echo $action->id; ?>,this);">
						<?php  if ($action->status=="on") {?> <i class="fa fa-pause"></i>
						<?php  } elseif ($action->status=="off") {?> <i class="fa fa-play"></i>
						<?php }	?>
						</div>	
						<div class="btn" title="Delete" onclick="plugin_ActionProg_delete(<?php echo $action->id; ?>,this);">
							<i class="fa fa-times"></i>
						</div>
					</td>
				</td>
			</tr>
			<?php
			}
			?>
		</table>
		</div>
		<?php
	}
}

// load link actions from groupaction $id
function plugin_alarme_LoadActionfromGroup($id)
{
	global $myUser,$conf;
	if($myUser!=false)
	{
		$group_Manager = new ActionCollection("r");
		$actions = $group_Manager->loadAll(array('type'=>$id)); //
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th width=200>id</th>	
					<th width=200>type</th>
					<th width=200>Description</th>
					<th width=200>linkid</th>									
				</tr>
			</thead>
			
			<?php 
				foreach ($actions as $action) {
				?>
				<tr>
					<td><?php echo $action->getId(); ?></td>
					<td><?php echo $action->type; ?></td>
					<td><?php echo $action->description; ?></td>
					<td><?php echo $action->linkradio; ?></td>
					<td width=50>
						<div class="btn" onclick="plugin_ActionItemGroup_delete('<?php echo $action->type; ?>', '<?php echo $action->linkradio ?>');">
							<i class="fa fa-times"></i>
						</div>
					</td>
				</td>
			</tr>
			<?php
			}
			
			?>
		</table>
		<?php
	}
}

function GetOTP($secret){
	
	$lag = 0;  // (en secondes)
	 
	date_default_timezone_set('Europe/Paris');
	$maintenant = time() + $lag;
	 
	require_once dirname(__FILE__).'/otphp/lib/otphp.php';
	
	$encode_secret=Base32::encode($secret);

	$totp = new \OTPHP\TOTP($encode_secret,array('interval'=>30));
	$code=$totp->at($maintenant);
	return $code;
	
}
function HomeCheck_alarmStatus() {
	
	$alarme_conf = new AlarmeConf("r");
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));				
	$status=$alarme_conf->getValue();
	
	return $status;	
	
}

function HomeCheck_updateFcmId($imei,$fcmid) {
	$HomeCheckManager = new Home_Check();	
	$admin= $HomeCheckManager->load(array("imei"=>$imei));
	if ($admin!=null){
		$admin->location=$fcmid;
		$admin->save();
		return "ok";// $admin->location;
	} else {
		return "not found";
	}
}


function HomeCheck_SetLocalIP($ip,$imei) {
	
	$HomeCheckManager = new Home_Check();
	$HomeChecks = $HomeCheckManager->populate();
    foreach ($HomeChecks as $HomeCheck) {
		if ($HomeCheck->imei==$imei) {
			$HomeCheck->ip=$ip;
			$HomeCheck->save();
			return $HomeCheck->name;
			break;
		}
	}
}

function HomeCheck_SetPos($pos,$imei) {
	$date = date('c'); 
	$HomeCheckManager = new Home_Check();
	$HomeChecks = $HomeCheckManager->populate();
    foreach ($HomeChecks as $HomeCheck) {
		if ($HomeCheck->imei==$imei) {
			$HomeCheck->location=$pos.'   Updated: '.$date;
			$HomeCheck->save();
			break;
		}
	}	
}

function HomeCheck_GetAdminPhone() {
	$HomeCheckManager = new Home_Check();	
	$admin= $HomeCheckManager->load(array("isadmin"=>"1"));
	return $admin->nummobile;
}
function HomeCheck_whoisadmin($imei) {
	
	$code='';
	$gtr=0;
	
	$HomeCheckManager = new Home_Check();
	$HomeChecks = $HomeCheckManager->populate();
	
	foreach ($HomeChecks as $HomeCheck) {
		if ($HomeCheck->imei==$imei) {
			$code=$HomeCheck->isadmin.'_'.$HomeCheck->password.'_'.$HomeCheck->nummobile;
			break;
		}
	}
	
    foreach ($HomeChecks as $HomeCheck) {
		//echo $HomeCheck->state."<br>";
		if ($HomeCheck->isadmin==1 && $gtr==0) {
			$gtr=1;
			$code=$code.'_'.$HomeCheck->password.'_'.$HomeCheck->nummobile.'_'.$HomeCheck->email;
		}
	}
	
	return $code;	
}

function HomeCheck_whois($check) {
	$HomeCheckManager = new Home_Check();
	$code='';
    $HomeChecks = $HomeCheckManager->populate();
    foreach ($HomeChecks as $HomeCheck) {
		//echo $HomeCheck->state."<br>";
		
		if ($HomeCheck->state==1) {
			if ($check==0) {
			$code=$code.$HomeCheck->name.',';
			}
			else {
				$code=$code+1;
			}
		}
	}
	if ($code=='') {
		if ($check==1) {
			$code=0;}
		else {
			$code='Personne';
		}
	}
	return $code;	
}

function HomeCheck_send_notification($notif,$route="",$topic="") {
	
	$alarme_conf = new AlarmeConf();
	$alarme_confCli = $alarme_conf->load(array("conf"=>"Plugin_Alarme_Cli"));
	$alarmeActiveCli=$alarme_confCli->getValue();
				
	if ($alarmeActiveCli!="1") return;
	
	$HomeCheckManager = new Home_Check();	
	$admin= $HomeCheckManager->load(array("isadmin"=>"1"));
	//debug force user
	if (DEBUG):
	  //$debug->writeLine("stuff");
	  $admin= $HomeCheckManager->load(array("name"=>"emulator")); 
	endif;
	
	//
	$currentDateTime = date('Y-m-d H:i:s');
	if ($admin!=null){
		$fcmid=$admin->location;
	
		/* with data
		$json_data=array(
			"to" => $deviceId,
			"collapse_key" => "New Message",
			"notification" => [
			 "body" => "test from server",
			 "title"=> "Hello"
			],
			"data" => [
			 "route" => "SettingsPage",
			 "topic"=> "check"
			]
		);*/
		
		$json_data=array(
			"to" => $fcmid,
			"collapse_key" => "HomeCheck",
			"android_channel_id" => "HomeCheck",
			"notification" => [
			 "body" => $notif,
			 "title"=> "Alert ".$currentDateTime,
			],
			"data" => [
			 "route" => $route,
			 "topic"=> $topic
			]
		);
		
		$data = json_encode($json_data);
		//FCM API end-point
		$url = 'https://fcm.googleapis.com/fcm/send';
		//api_key in Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key
		$server_key = 'AAAAztbWxXY:APA91bEv6FdW7UpKv9Vi1cRZbuLSlLsPN15I0WKVPL3uzf9qlzP5hUbk7Z8aoH3d2Jz4Zr1jRy6DDgYTyCofMEdL1loHcwIJtXmUGLaW4-4ErybbpFj2zwiiBDLiEFVNDU_Dghmy50CX';
		//header with content_type api key
		$headers = array(
			'Content-Type:application/json',
			'Authorization:key='.$server_key
		);
		//CURL request to route notification to FCM connection server (provided by Google)
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		$result = curl_exec($ch);
		
		if ($result === FALSE) {
			die('Oops! FCM Send Error: ' . curl_error($ch));
		}
		curl_close($ch);
	} 

}
function HomeCheck_plugin_SendCli($mtype,$value) {
	global $conf;
	$date = new DateTime();
	$value=str_replace("_","-",$value);
	$curinstr=$mtype.$value;
	$curtimeaction=$date->getTimestamp();
	
	if($conf->get('curinstr')!=null) {
		$res=$conf->get('curinstr');
		//echo $res;
		$lastIndex = strripos($res, '_');
		if ($lastindex===false) { 
			$lastaction=$res;
			$lasttime=0;
		}
		else {
			$lastaction=substr($res,0,$lastIndex);
			$lasttime=substr($res,$lastIndex+1,strlen($res));
		}
	}
	else {
		$conf->put('curinstr',$curinstr."_".$curtimeaction);
		$lastaction=$curinstr;
		//echo 'not set';
	}

	$timelaps= $curtimeaction-$lasttime;
	//echo $timelaps;
	if (($curinstr==$lastaction) && ($timelaps<3)) {
		//echo "pass";
		return;
	}
	$conf->put('curinstr',$curinstr."_".$curtimeaction);
	$value=str_to_noaccent($value);
	$value="\"".$value."\"";
	
	$HomeCheckManager = new Home_Check("r");
	
	$HomeChecks = $HomeCheckManager->loadAll(array('isclientserv'=>1));
	foreach($HomeChecks as $HomeCheck)
	{
		$cmd=$mtype.':'.$value;
		//echo $HomeCheck->ip;
		$command='python '.dirname(__FILE__).'/run_Client.py -d '.$HomeCheck->ip.' '.$cmd;
		exec($command . " > /dev/null &");
		sleep(3);
	}
	
}

function HomeCheck_plugin_SendGsm($mtype,$value) {
	global $conf;
	$date = new DateTime();
	$value=str_replace("_","-",$value);
	
	$curinstr=$mtype.$value;
	$curtimeaction=$date->getTimestamp();
	$timetemp=10;
	
	if($conf->get('curinstr')!=null) {
		$res=$conf->get('curinstr');
		//echo $res;
		$lastIndex = strripos($res, '_');
		if ($lastindex===false) { 
			$lastaction=$res;
			$lasttime=0;
		}
		else {
			$lastaction=substr($res,0,$lastIndex);
			$lasttime=substr($res,$lastIndex+1,strlen($res));
		}
	}
	else {
		$conf->put('curinstr',$curinstr."_".$curtimeaction);
		$lastaction=$curinstr;
		//echo 'not set';
	}

	$timelaps= $curtimeaction-$lasttime;
	//echo $timelaps;
	if (($curinstr==$lastaction) && ($timelaps<$timetemp)) {
		//echo "pass";
		return;
	}
	$conf->put('curinstr',$curinstr."_".$curtimeaction);
	$value=str_to_noaccent($value);
	$value="\"".$mtype.':'.$value."\"";
	$alarme_Manager = new AlarmeRelay("r");
	$relays = $alarme_Manager->loadAll(array('isSwitch'=>4));
	
	// send FCM notif
	HomeCheck_send_notification($value);
	
	
	// send GSM text
	$adminphone=HomeCheck_GetAdminPhone();
	foreach($relays as $relay)
	{
		$cmd="Snd".$value.'_'.$adminphone;
		$command='python '.dirname(__FILE__).'/run_Client.py -d '.$relay->IPadress.' -r 1 '.$cmd;
		$res=exec($command);
		Functions::log('send gsm  : '.$value);
		sleep($timetemp);
	}
}

function HomeCheck_plugin_update_state($imei,$state,$wificon) {
	$HomeCheckManager = new Home_Check();
	
	$HomeCheck = $HomeCheckManager->load(array('imei'=>$imei));
	Functions::log('Home update in_out : db state '.$HomeCheck->state." new ".$state." from wifi".$wificon);
	if ($HomeCheck->state<>$state and $wificon==1) {
		if ($state==0) {
			$status="Out of home";
		}
		else {
			$status="At home";
		}
		//HomeCheck_plugin_SendCli("info","\"Membre ".$HomeCheck->name." ".$status." \"");
	}
	if ($HomeCheck->isclientserv==0) {
		$HomeCheck->state=$state;
		$HomeCheck->save();
	}
	
	
}

function HomeCheckradio_plugin_test_code($code)
{
	$param='/codesend';

    $cmd = dirname(__FILE__).$param." ".$code;
    exec($cmd, $out, $err);
	
}

function HomeCheckradio_update_gsm() {
	
	$serv=$_SERVER['SERVER_ADDR'];
	$alarme_Manager = new AlarmeRelay("r");
	$relays = $alarme_Manager->loadAll(array('isSwitch'=>4));
	Functions::log('sync gsm');
	
	$adminphone=HomeCheck_GetAdminPhone();
	foreach($relays as $relay)
	{
		$cmd="Ips".$serv.'_'.$adminphone;
		$command='python '.dirname(__FILE__).'/run_Client.py -d '.$relay->IPadress.' -r 1 '.$cmd;
		$res=exec($command);
		sleep(2);
		
		$cmd="Csq";
		$command='python '.dirname(__FILE__).'/run_Client.py -d '.$relay->IPadress.' -r 1 '.$cmd;
		$res=exec($command);
		sleep(2);
		
		$cmd="\"SndTest:Domocom\"_".$adminphone;
		Functions::log('test gsm  : '.$cmd);
		$command='python '.dirname(__FILE__).'/run_Client.py -d '.$relay->IPadress.' -r 1 '.$cmd;
		$res=exec($command);
		sleep(2);
		
		
	}
}
function HomeCheckradio_update_relays() {
	$alarme_Manager = new AlarmeSensorRadio("r");
	$sensors = $alarme_Manager->loadAll(array('type'=>'SensorTXRADIO'));
	$serv=$_SERVER['SERVER_ADDR'];
	$port=$_SERVER['SERVER_PORT'];
	$code="Ips".$serv.":".$port;
	HomeCheckRelay_send_intr($code);
	sleep(1);
	foreach ($sensors as $sensor) {
		$linkr=$sensor->linkradio;
		if (!empty($linkr) && $linkr!=-1) {
			$linkradio=$alarme_Manager->getById($linkr);
			if ($sensor->lumi==0) {
				$lumi=100;
			} else {
				$lumi=$sensor->lumi;
			}
			$code="Upd".$sensor->radiocodeOn."_".$linkradio->radiocodeOn."_".$lumi;
			Functions::log('upd relay '.$code); 
			HomeCheckRelay_send_intr($code);
			sleep(1);
		}
	}
}

function HomeCheckradio_plugin_change_state($engine, $state)
{
    global $conf;
    $genericRadio = new AlarmeSensorRadio();
    $genericRadio = $genericRadio->getById($engine);
	
    if ($state!=0) {
        $code = $genericRadio->radiocodeOn;
    } else {
        $code = $genericRadio->radiocodeOff;
    }

    $genericRadio->setState($state);
	$genericRadio->save();
    Functions::log('Launch system command : '.$code.' '.$state);
    // send radio code to sat
	HomeCheckRelay_send_intr("000".$code);
	
}

/**
* Remove first and end quote from a quoted string of text
*
* @param mixed $text
*/
function stripQuotes($text) {
  $unquoted = preg_replace('/(^[\"\']|[\"\']$)/', '', $text);
  return $unquoted;
} 

function UpdateLastMod() {
	
	$date = new DateTime();
	$lastmod=$date->getTimestamp();
	$alarme_conf = new AlarmeConf();
	$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_TimeStamp"));
	$alarme_conf->setValue($lastmod);
	$alarme_conf->save();
			
}

function HomeCheckIPCAM_manual_change_state($engine, $state)
{
	$cameraManager = new IPCamera();
    $genericCam = $cameraManager->getById($engine);
	$ip=$genericCam->ip;
	$login=$genericCam->login;
	$pass=$genericCam->password;
	$brand=$genericCam->brand;
	//Functions::log('icam: '.$brand); 
	switch (strtolower($brand)) {
		case "picam":
			switch ($state) {
			case 0: // up
				$mov="/tilt/+";
				break;
			case 2: // down
				$mov="/tilt/-";
				break;
			case 3: // home
				$mov="/home";
				break;
			case 4: // left
				$mov="/pan/-";
				break;
			case 6:  // right
				$mov="/pan/+";
				break;
			}
			//echo $mov;
			$url = "curl http://".$login.":".$pass."@".$ip.$mov;
			//$url = "curl ".$ip.$mov;
			exec($url);
			break;
		case "dlink 5222l":
			switch ($state) {
			case 0: // up
				$mov="p=0&t=100";
				break;
			case 2: // down
				$mov="p=0&t=-100";
				break;
			case 4: // left
				$mov="p=-100&t=0";
				break;
			case 6:  // right
				$mov="p=100&t=0";
				break;
			}
			$url = "curl http://".$login.":".$pass."@".$ip."//config/ptz_move_rel.cgi -d\"".$mov."\"";
			exec($url);
			break;
			
		case "wanscam":
			$url = "http://".$ip."/decoder_control.cgi?command=".$state."&onestep=5&user=".$login."&pwd=".$pass ;
			$ch = curl_init();
			curl_setopt($ch,CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_TIMEOUT, 5);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_exec($ch);
			break;
	}	
	return 0;
}

/* function:  generates thumbnail */
function make_thumb($src,$dest,$desired_width) {
	/* read the source image */
	try {
	$source_image = imagecreatefromjpeg($src);
	$width = imagesx($source_image);
	$height = imagesy($source_image);
	/* find the "desired height" of this thumbnail, relative to the desired width  */
	$desired_height = floor($height*($desired_width/$width));
	/* create a new, "virtual" image */
	$virtual_image = imagecreatetruecolor($desired_width,$desired_height);
	/* copy source image at a resized size */
	imagecopyresized($virtual_image,$source_image,0,0,0,0,$desired_width,$desired_height,$width,$height);
	/* create the physical thumbnail image to its destination */
	imagejpeg($virtual_image,$dest);
	} catch (Exception $e) {
		echo 'Exception: ',  $e->getMessage(), "\n";
	}
}

/* function:  returns files from dir */
function get_files($images_dir,$exts = array('jpg')) {
	$files = array();
	if($handle = opendir($images_dir)) {
		while(false !== ($file = readdir($handle))) {
			$extension = strtolower(get_file_extension($file));
			if($extension && in_array($extension,$exts)) {
				$files[] = $file;
			}
		}
		closedir($handle);
	}
	return $files;
}

/* function:  returns a file's extension */
function get_file_extension($file_name) {
	return substr(strrchr($file_name,'.'),1);
}

function listFiles( $from = '.')
{
    if(! is_dir($from))
        return false;
   
    $files = array();
    $dirs = array( $from);
    while( NULL !== ($dir = array_pop( $dirs)))
    {
        if( $dh = opendir($dir))
        {
            while( false !== ($file = readdir($dh)))
            {
                if( $file == '.' || $file == '..')
                    continue;
                $path = $dir . '/' . $file;
                if( is_dir($path))
                    $dirs[] = $path;
                else
                    $files[] = $path;
            }
            closedir($dh);
        }
    }
    return $files;
}

function is_image($path)
{
    $a = getimagesize($path);
    $image_type = $a[2];
    if(in_array($image_type , array(IMAGETYPE_GIF , IMAGETYPE_JPEG ,IMAGETYPE_PNG , IMAGETYPE_BMP)))
    {
        return true;
    }
    return false;
}

function ote_accent($str){
$str = utf8_decode($str);
$ch = strtr($str,
      'ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ',
      'AAAAAACEEEEIIIIOOOOOUUUUYaaaaaaceeeeiiiioooooouuuuyy');
return utf8_encode($ch);
}


function str_to_noaccent($str)
{
    $unwanted_array = array('Š'=>'S', 'š'=>'s', 'Ž'=>'Z', 'ž'=>'z', 'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A',
		'Å'=>'A', 'Æ'=>'A', 'Ç'	=>'C', 'È'=>'E', 'É'=>'E','Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I', 
		'Ï'=>'I', 'Ñ'=>'N','Ò'=>'O', 'Ó'=>'O', 'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U',
        'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'B', 'ß'=>'Ss', 'à'=>'a', 
		'á'=>'a', 'â'=>'a', 'ã'=>'a', 'ä'=>'a', 'å'=>'a', 'æ'=>'a', 'ç'=>'c',
        'è'=>'e', 'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i', 'î'=>'i', 
		'ï'=>'i', 'ð'=>'o', 'ñ'=>'n', 'ò'=>'o', 'ó'=>'o', 'ô'=>'o', 'õ'=>'o',
        'ö'=>'o', 'ø'=>'o', 'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ý'=>'y', 'þ'=>'b', 'ÿ'=>'y' );
	return strtr( $str, $unwanted_array );
}

// widgets

function plugin_alarme_LoadWidget($error=null)
{
	$alarme_conf = new AlarmeConf("r");
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));
	if($alarme_conf->getValue()=="1")
	{
		$sentence=" Alarme activée, surveillance en cours";
	}
	elseif($alarme_conf->getValue()=="0")
	{
		$sentence=" Alarme désactivée";
	}
	$refresh=array(	"valeur"=>$alarme_conf->getValue(),
						"sentence"=>$sentence,
						"error"=>$error);
	echo json_encode($refresh);
}

function Homecheck_globalState_widget(&$widgets){
	$widgets[] = array(
                'uid'      => 'dash_HomeCheckglobalstate',
                'icon'     => 'fa fa-bullseye',
                'label'    => 'HomeCheck Global State',
                'background' => '#50597b',
                'color' => '#fffffff',
                'onLoad'   => 'action.php?action=HomeCheck_globalstate_load_widget',
                'onEdit'   => 'action.php?action=HomeCheck_globalstate_edit_widget',
                'onSave'   => 'action.php?action=HomeCheck_globalstate_save_widget',
                );
	
}


function plugin_alarme_widget(&$widgets){
	$alarme_conf = new AlarmeConf("r");
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_widget_color"));
	
	$widgets[] = array(
		'uid'      => 'dash_HomeCheckpluginalarme',
		'icon'     => 'fa fa-bell-o',
		'label'    => 'Plugin Alarme',
		'addToHead'=> '	<li style="color:white" onclick="plugin_alarme_changeColor()"><i class="fa fa-adjust"></i></li>',
		'background' => $alarme_conf->getValue(), 
		'color' => '#fffffff',
		'onLoad'   => 'action.php?action=plugin_alarme_load_widget',
		'onEdit'   => 'action.php?action=plugin_alarme_edit_widget',
		'onSave'   => 'action.php?action=plugin_alarme_save_widget',
	);
}

function Homecheck_ipcam_widget(&$widgets){
		$widgets[] = array(
		    'uid'      => 'dash_HomeCheckipcam',
		    'icon'     => 'fa fa-video-camera',
		    'label'    => 'HomeCheck_Camera',
		    'background' => '#50597b', 
		    'color' => '#fffffff',
		    'onLoad'   => 'action.php?action=HomeCheck_ipcam_load_widget',
		    'onEdit'   => 'action.php?action=HomeCheck_ipcam_edit_widget',
		    'onSave'   => 'action.php?action=HomeCheck_ipcam_save_widget',
		);
}


function genericRadio_plugin_widget(&$widgets)
{
            $widgets[] = array(
                'uid'      => 'dash_HomeCheckgenericradio',
                'icon'     => 'fa fa-bullseye',
                'label'    => 'Relais Radio HomeCheck',
                'background' => '#50597b',
                'color' => '#fffffff',
                'onLoad'   => 'action.php?action=genericRadio_load_widget',
                'onEdit'   => 'action.php?action=genericRadio_edit_widget',
                'onSave'   => 'action.php?action=genericRadio_save_widget',
                );
}

function genericRelay_plugin_widget(&$widgets)
{
            $widgets[] = array(
                'uid'      => 'dash_HomeCheckgenericrelay',
                'icon'     => 'fa fa-bullseye',
                'label'    => 'Relais Relay HomeCheck',
                'background' => '#50597b',
                'color' => '#fffffff',
                'onLoad'   => 'action.php?action=genericRelay_load_widget',
                'onEdit'   => 'action.php?action=genericRelay_edit_widget',
                'onSave'   => 'action.php?action=genericRelay_save_widget',
                );
}

function HomeCheck_temp_widget(&$widgets)
{
            $widgets[] = array(
                'uid'      => 'dash_HomeChecktempwidget',
                'icon'     => 'fa fa-bullseye',
                'label'    => 'HomeCheck Temp',
                'background' => '#50597b',
                'color' => '#fffffff',
                'onLoad'   => 'action.php?action=HomeCheck_temp_load_widget',
                'onEdit'   => 'action.php?action=HomeCheck_temp_edit_widget',
                'onSave'   => 'action.php?action=HomeCheck_temp_save_widget',

                );
}

		//Le JS
		Plugin::addJs('/js/main.js',true);
		Plugin::addJs('/js/jsOTP.min.js',true);
		Plugin::addJs('/js/chart.min.js',true);
		Plugin::addJs('/js/jscolor.js',true);
		//Le CSS
		Plugin::addCss('/css/style.css',true);
		
		//Configuration Préférence
		Plugin::addHook("home", "plugin_alarme_setting_page"); //setting_bloc
		Plugin::addHook("menubar_pre_home", "plugin_alarme_setting_menu"); //setting_menu
		Plugin::addHook("vocal_command", "plugin_alarme_vocal_command");
		Plugin::addHook("action_post_case", "plugin_alarme_action"); 
		Plugin::addHook("widgets", "genericRadio_plugin_widget");
		Plugin::addHook("widgets", "genericRelay_plugin_widget");
		Plugin::addHook("widgets", "Homecheck_ipcam_widget");
		Plugin::addHook("widgets", "Homecheck_globalState_widget");	
		Plugin::addHook("widgets", "HomeCheck_temp_widget");

		
?>

