#!/usr/bin/python
# -*-coding:Utf-8 -*


from libExecCmd import *
	
if __name__ == '__main__':	
	ExecCmd()


