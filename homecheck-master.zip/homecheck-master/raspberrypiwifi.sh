#!/bin/bash

DIALOG_CANCEL=1
DIALOG_ESC=255
HEIGHT=0
WIDTH=0

display_result() {
  whiptail --title "$1" \
    --clear \
    --msgbox "$result" 0 0
}

string=$1
#echo $string


#echo $DIR
if [[ $string == *"py"* ]]; then
	#echo "python script"
	DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
	output=$(python $DIR/$string 2>&1)
	echo $output
	exit 0
fi


if [[ $string == *"installHomeCheck"* ]]; then
	tmp_dir=$(mktemp -d -t ci-XXXXXXXXXX)
	Directory="/var/www/yana-server/plugins/HomeCheck/"
	echo $tmp_dir
	rm -R -f Domo-Com-Server-master
	rm  -f master.zip
	echo "Getting last version"
	wget -P "$tmp_dir" https://github.com/Domo-Com/Domo-Com-Server/archive/refs/heads/master.zip
	cd $tmp_dir
	unzip $tmp_dir/master.zip
	cd  $tmp_dir/Domo-Com-Server-master/
	unzip homecheck-master.zip
	cd homecheck-master

	### To check if it's not exists
	if [ ! -d "$Directory" ];
	then 
		echo "create HomeCheck\n"
		mkdir "$Directory"
	fi
	echo "Copying $Directory"
	cp ./* "$Directory" -f -r
	sudo chown -R www-data:www-data "$Directory"
	sudo chmod -R 775 "$Directory"
	sudo usermod -a -G video www-data
	rm -rf $tmp_dir
	echo "Done"
	exit 0
fi

#########
#Shows the network menu options
#########
	stayInNetworkMenu=true
	while $stayInNetworkMenu; do
		exec 3>&1
		if [ -z $1 ] ; then
			NetworkMenuSelection=$(whiptail \
				--title "Network Configuration" \
				--clear \
				--cancel-button "Exit" \
				--menu "Please select:" $HEIGHT $WIDTH 3 \
				"1" "Display Network Information" \
				"2" "Scan for WiFI Networks (Root Required)" \
				"3" "Connect to WPA WiFi Network (Root Required)" \
				"4" "Connect to WEP WiFi Network (Root Required)" \
				"5" "Connect to Open WiFi Network (Root Required)" \
				"6" "Connect to Hidden WPA SSID Network (Root Required)" \
				"7" "Connect to WPA SSID Network with Static IP (Root Required)" \
				2>&1 1>&3)
		else
			NetworkMenuSelection=$1
		fi
		exit_status=$?
		case $exit_status in
			$DIALOG_CANCEL)
			  clear
        		  #echo "Program terminated."
      			  exit
     			  ;;
			$DIALOG_ESC)
			  clear
      			  #echo "Program aborted." >&2
      			  exit 1
      			  ;;
		esac
		case $NetworkMenuSelection in
			0 )
			  stayInNetworkMenu=false
			  ;;
			1 )
				result=$(ifconfig)
				display_result "Network Information"
				;;
			2 )
				currentUser=$(whoami)
				if [ $currentUser == "root" ] ; then
					ifconfig wlan0 up
					result=$(iwlist wlan0 scan | grep ESSID | sed 's/ESSID://g;s/"//g;s/^ *//;s/ *$//')
					display_result "WiFi Networks"
				else
					result=$(echo "You have to be running the script as root in order to scan for WiFi networks. Please try using sudo.")
					display_result "WiFi Network"
				fi
				;;
			3 )
				currentUser=$(whoami)
				if [ $currentUser == "root" ] ; then
					ifconfig wlan0 up
					wifiNetworkList=$(iwlist wlan0 scan | grep ESSID | sed 's/ESSID://g;s/"//g;s/^ *//;s/ *$//')
					
					if [ -z $2 ] ; then
						wifiSSID=$(whiptail --title "WiFi Network SSID" --inputbox "Network List: \n\n$wifiNetworkList \n\nEnter the SSID of the WiFi network you would like to connect to:" 0 0 2>&1 1>&3);
					else
						wifiSSID=$2
					fi
					if [ "$wifiSSID" != "" ] ; then
						actuallyConnectToWifi=false
						networkInterfacesConfigLocation="/etc/network/interfaces"
						cp $networkInterfacesConfigLocation $networkInterfacesConfigLocation"_bak"
						actuallyConnectToWifi=true
						
						# We can perform check
						echo "Performing Network check for $wlan"
						/bin/ping -c 2 -I wlan0 8.8.8.8 > /dev/null 2> /dev/null
						if [ $? -lt 1 ] ; then
							result="You are already connected to $wifiSSID."
							echo $result
							exit 0
						fi
						
						if [ $actuallyConnectToWifi == true ] ; then
							if [ -z $3 ] ; then					
								wifiPassword=$(whiptail --title "WiFi Network Password" --passwordbox "Enter the password of the WiFi network you would like to connect to:" 10 70 2>&1 1>&3);
							else
								wifiPassword=$3
							fi
							if [ ! "$wifiPassword" == "" ] ; then
								echo -e 'auto lo\n\niface lo inet loopback\nauto eth0\nallow-hotplug eth0\niface eth0 inet dhcp\n\nallow-hotplug wlan0\nauto wlan0\niface wlan0 inet dhcp\n\twpa-ssid "'$wifiSSID'"\n\twpa-psk "'$wifiPassword'"' > $networkInterfacesConfigLocation
								ifdown wlan0 > /dev/null 2>&1
								sleep 5
								ifup --force wlan0 > /dev/null 2>&1
								
								inetAddress=$(ifconfig wlan0 | grep "inet.*")
								if [ "$inetAddress" != "" ] ; then
									if [ -z $1 ] ; then	
										result=$(echo "You are now connected to $wifiSSID.")
										display_result "WiFi Network"
									else
										result="You are now connected to $wifiSSID."
										echo $result
									fi
								else
									if [ -z $1 ] ; then	
										result=$(echo "There was an issue trying to connect to $wifiSSID. Please ensure you typed the SSID and password correctly.")
										display_result "WiFi Network"
									else
										result="There was an issue trying to connect to $wifiSSID. Please ensure you typed the SSID and password correctly."
										echo $result
									fi
									
								fi
							fi
						fi
					fi
				else
					if [ -z $1 ] ; then	
						result=$(echo "You have to be running the script as root in order to connect to a WiFi network. Please try using sudo.")
						display_result "WiFi Network"
					else
						result="You have to be running the script as root in order to connect to a WiFi network. "
						echo $result
					fi
				fi
				stayInNetworkMenu=false
			;;
			4 )
			currentUser=$(whoami)
				if [ $currentUser == "root" ] ; then
					ifconfig wlan0 up
					wifiNetworkList=$(iwlist wlan0 scan | grep ESSID | sed 's/ESSID://g;s/"//g;s/^ *//;s/ *$//')
					wifiSSID=$(whiptail --title "WiFi Network SSID" --inputbox "Network List: \n\n$wifiNetworkList \n\nEnter the SSID of the WiFi network you would like to connect to:" 0 0 2>&1 1>&3);
					if [ "$wifiSSID" != "" ] ; then
						actuallyConnectToWifi=false
						networkInterfacesConfigLocation="/etc/network/interfaces"
						
						if (whiptail --title "Create Backup?" --yesno "Would you like to create a backup of your current network interfaces config?" 0 0) then
							if [ ! -f $networkInterfacesConfigLocation"_bak" ] ; then
								cp $networkInterfacesConfigLocation $networkInterfacesConfigLocation"_bak"
							else
								if (whiptail --title "Overwrite Backup?" --yesno "A backup currently exists. Do you want to overwrite it?" 0 0) then
									cp $networkInterfacesConfigLocation $networkInterfacesConfigLocation"_bak"
								fi
								actuallyConnectToWifi=true
							fi		
						else
							actuallyConnectToWifi=true
						fi
						if [ $actuallyConnectToWifi == true ] ; then
							wifiPassword=$(whiptail --title "WiFi Network Password" --passwordbox "Enter the password of the WiFi network you would like to connect to:" 10 70 2>&1 1>&3);
							if [ ! "$wifiPassword" == "" ] ; then
								echo -e 'auto lo\n\niface lo inet loopback\niface eth0 inet dhcp\n\nallow-hotplug wlan0\nauto wlan0\niface wlan0 inet dhcp\n\twireless-essid '"$wifiSSID"'\n\twireless-key '"$wifiPassword"'' > $networkInterfacesConfigLocation
								ifdown wlan0 > /dev/null 2>&1
								ifup wlan0 > /dev/null 2>&1
								
								inetAddress=$(ifconfig wlan0 | grep "inet addr.*")
								if [ "$inetAddress" != "" ] ; then
									result=$(echo "You are now connected to $wifiSSID.")
									display_result "WiFi Network"
								else
									result=$(echo "There was an issue trying to connect to $wifiSSID. Please ensure you typed the SSID and password correctly.")
									display_result "WiFi Network"
								fi
							fi
						fi
					fi
				else
					result=$(echo "You have to be running the script as root in order to connect to a WiFi network. Please try using sudo.")
					display_result "WiFi Network"
				fi
			;;
			5 )
			currentUser=$(whoami)
				if [ $currentUser == "root" ] ; then
					ifconfig wlan0 up
					wifiNetworkList=$(iwlist wlan0 scan | grep ESSID | sed 's/ESSID://g;s/"//g;s/^ *//;s/ *$//')
					wifiSSID=$(whiptail --title "WiFi Network SSID" --inputbox "Network List: \n\n$wifiNetworkList \n\nEnter the SSID of the WiFi network you would like to connect to:" 0 0 2>&1 1>&3);
					if [ "$wifiSSID" != "" ] ; then
						actuallyConnectToWifi=false
						networkInterfacesConfigLocation="/etc/network/interfaces"
						
						if (whiptail --title "Create Backup?" --yesno "Would you like to create a backup of your current network interfaces config?" 0 0) then
							if [ ! -f $networkInterfacesConfigLocation"_bak" ] ; then
								cp $networkInterfacesConfigLocation $networkInterfacesConfigLocation"_bak"
							else
								if (whiptail --title "Overwrite Backup?" --yesno "A backup currently exists. Do you want to overwrite it?" 0 0) then
									cp $networkInterfacesConfigLocation $networkInterfacesConfigLocation"_bak"
								fi
								actuallyConnectToWifi=true
							fi		
						else
							actuallyConnectToWifi=true
						fi
						if [ $actuallyConnectToWifi == true ] ; then
								echo -e 'auto lo\n\niface lo inet loopback\niface eth0 inet dhcp\n\nallow-hotplug wlan0\nauto wlan0\niface wlan0 inet dhcp\n\twireless-essid '"$wifiSSID"'\n\twireless-mode managed' > $networkInterfacesConfigLocation
								ifdown wlan0 > /dev/null 2>&1
								ifup wlan0 > /dev/null 2>&1
								
								inetAddress=$(ifconfig wlan0 | grep "inet addr.*")
								if [ "$inetAddress" != "" ] ; then
									result=$(echo "You are now connected to $wifiSSID.")
									display_result "WiFi Network"
								else
									result=$(echo "There was an issue trying to connect to $wifiSSID. Please ensure you typed the SSID and password correctly.")
									display_result "WiFi Network"
								fi
							fi
						fi
				else
					result=$(echo "You have to be running the script as root in order to connect to a WiFi network. Please try using sudo.")
					display_result "WiFi Network"
				fi
			;;
			6 )
			currentUser=$(whoami)
				if [ $currentUser == "root" ] ; then
					ifconfig wlan0 up
					wifiSSID=$(whiptail --title "WiFi Network SSID" --inputbox "Network List: Enter the Hidden SSID of the WiFi network you would like to connect to:" 0 0 2>&1 1>&3);
					if [ "$wifiSSID" != "" ] ; then
						actuallyConnectToWifi=false
						networkInterfacesConfigLocation="/etc/network/interfaces"
						
						if (whiptail --title "Create Backup?" --yesno "Would you like to create a backup of your current network interfaces config?" 0 0) then
							if [ ! -f $networkInterfacesConfigLocation"_bak" ] ; then
								cp $networkInterfacesConfigLocation $networkInterfacesConfigLocation"_bak"
							else
								if (whiptail --title "Overwrite Backup?" --yesno "A backup currently exists. Do you want to overwrite it?" 0 0) then
									cp $networkInterfacesConfigLocation $networkInterfacesConfigLocation"_bak"
								fi
								actuallyConnectToWifi=true
							fi		
						else
							actuallyConnectToWifi=true
						fi
						if [ $actuallyConnectToWifi == true ] ; then
							wifiPassword=$(whiptail --title "WiFi Network Password" --passwordbox "Enter the password of the WiFi network you would like to connect to:" 10 70 2>&1 1>&3);
							if [ ! "$wifiPassword" == "" ] ; then
							hexkey=$( wpa_passphrase "$wifiSSID" "$wifiPassword" | grep psk | awk '{if(NR==2)print $0}' | sed 's/^.\{5\}//g')
								echo -e 'auto lo\n\niface lo inet loopback\niface eth0 inet dhcp\n\nallow-hotplug wlan0\nauto wlan0\niface wlan0 inet dhcp\nwpa-driver wext\n\twpa-ssid "'$wifiSSID'"\nwpa-ap-scan 2\nwpa-proto WPA\nwpa-pairwise TKIP\nwpa-group TKIP\nwpa-key-mgmt WPA-PSK\n\twpa-psk "'$hexkey'"' > $networkInterfacesConfigLocation
								ifdown wlan0 > /dev/null 2>&1
								ifup wlan0 > /dev/null 2>&1
								
								inetAddress=$(ifconfig wlan0 | grep "inet addr.*")
								if [ "$inetAddress" != "" ] ; then
									result=$(echo "You are now connected to $wifiSSID.")
									display_result "WiFi Network"
								else
									result=$(echo "There was an issue trying to connect to $wifiSSID. Please ensure you typed the SSID and password correctly.")
									display_result "WiFi Network"
								fi
							fi
						fi
					fi
				else
					result=$(echo "You have to be running the script as root in order to connect to a WiFi network. Please try using sudo.")
					display_result "WiFi Network"
				fi
			;;
			7 )
				currentUser=$(whoami)
				if [ $currentUser == "root" ] ; then
					ifconfig wlan0 up
					wifiNetworkList=$(iwlist wlan0 scan | grep ESSID | sed 's/ESSID://g;s/"//g;s/^ *//;s/ *$//')
					wifiSSID=$(whiptail --title "WiFi Network SSID" --inputbox "Network List: \n\n$wifiNetworkList \n\nEnter the SSID of the WiFi network you would like to connect to:" 0 0 2>&1 1>&3);
					if [ "$wifiSSID" != "" ] ; then
						actuallyConnectToWifi=false
						networkInterfacesConfigLocation="/etc/network/interfaces"
						
						if (whiptail --title "Create Backup?" --yesno "Would you like to create a backup of your current network interfaces config?" 0 0) then
							if [ ! -f $networkInterfacesConfigLocation"_bak" ] ; then
								cp $networkInterfacesConfigLocation $networkInterfacesConfigLocation"_bak"
							else
								if (whiptail --title "Overwrite Backup?" --yesno "A backup currently exists. Do you want to overwrite it?" 0 0) then
									cp $networkInterfacesConfigLocation $networkInterfacesConfigLocation"_bak"
								fi
								actuallyConnectToWifi=true
							fi		
						else
							actuallyConnectToWifi=true
						fi
						if [ $actuallyConnectToWifi == true ] ; then
							wifiPassword=$(whiptail --title "WiFi Network Password" --passwordbox "Enter the password of the WiFi network you would like to connect to:" 10 70 2>&1 1>&3);
							if [ ! "$wifiPassword" == "" ] ; then
							ip=$(whiptail --title "New Raspberry Pi IP" --inputbox "\n\nEnter the IP address you would like your Raspberry Pi to have e.g. 192.168.0.110:" 0 0 2>&1 1>&3); 
							if [ "$ip" != "" ] ; then
							gatewaylist=$(netstat -nr)
							gateway=$(whiptail --title "Gateway" --inputbox "Gateway List: \n\n$gatewaylist \n\nEnter the default gateway for your router: typically 192.168.0.1:" 0 0 2>&1 1>&3);
							if [ ! "$gateway" == "" ] ; then
							netmask=$(whiptail --title "Netmask" --inputbox "\n\nEnter the default netmask for your router: typically 255.255.255.0:" 0 0 2>&1 1>&3);
							if [ ! "$netmask" == "" ] ; then
							echo -e 'auto lo\n\niface lo inet loopback\niface eth0 inet dhcp\n\nallow-hotplug wlan0\nauto wlan0\niface wlan0 inet static\n\taddress "'$ip'"\n\tgateway "'$gateway'"\n\tnetmask "'$netmask'"\n\twpa-ssid "'$wifiSSID'"\n\twpa-psk "'$wifiPassword'"' > $networkInterfacesConfigLocation
								ifdown wlan0 > /dev/null 2>&1
								ifup wlan0 > /dev/null 2>&1
								
								inetAddress=$(ifconfig wlan0 | grep "inet addr.*")
								if [ "$inetAddress" != "" ] ; then
									result=$(echo "You are now connected to $wifiSSID.")
									display_result "WiFi Network"
								else
									result=$(echo "There was an issue trying to connect to $wifiSSID. Please ensure you typed the SSID and password correctly.")
									display_result "WiFi Network"
								fi
								fi
								fi
								fi
							fi
						fi
					fi
				else
					result=$(echo "You have to be running the script as root in order to connect to a WiFi network. Please try using sudo.")
					display_result "WiFi Network"
				fi
			;;
		esac
	done
