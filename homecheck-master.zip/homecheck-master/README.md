HomeCheck plugin initial
to update repo:

sudo git pull
domo-com
domocom01

EOF