#!/usr/bin/python

# sudo apt-get install nmap
# sudo apt-get install arp-scan
#
from libScanip import *
				
if __name__ == '__main__':
	scanip()