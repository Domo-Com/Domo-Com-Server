#!/usr/bin/python
# -*-coding:Utf-8 -*

import ConfigParser
import urllib2
import json
import os
import sys
import time 

params=sys.argv[1]

timedelay=float(params)

# wait desactivation response
time.sleep(timedelay)

# alarm not yet desactivated so launch action

command = "http://127.0.0.1:8080/action.php?action=Plugin_Alarme_Active_Action"
try:
	json_commands = urllib2.urlopen(command) #.read() 
#Handle invalid IP
except IOError, e:
	print("Invalid")

# rep = json.loads(json_commands)
