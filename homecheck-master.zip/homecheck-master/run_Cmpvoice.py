#!/usr/bin/python
# -*-coding:Utf-8 -*
"""
This script manages vocal recognition for HomeCheck
"""
from libCmpvoice import *

		
if __name__ == '__main__':
	cmpvoice()
