#!/usr/bin/python
# -*-coding:Utf-8 -*

import time
import os
import tempfile
import urllib
import urllib2
import datetime
import sys
import time
import logging
from logging.handlers import RotatingFileHandler

def launcher():
	cwd = tempfile.gettempdir()

	# attention bien penser a sudo chmod  4775 scanip.py


	curdir=os.path.dirname(os.path.realpath(__file__))
	#print curdir


	# creation de l'objet logger qui va nous servir a ecrire dans les logs
	logger = logging.getLogger()
	# on met le niveau du logger a DEBUG, comme ca il ecrit tout
	logger.setLevel(logging.INFO)
	 
	# creation d'un formateur qui va ajouter le temps, le niveau
	# de chaque message quand on ecrira un message dans le log
	formatter = logging.Formatter('%(asctime)s :: %(levelname)s :: %(message)s')
	# creation d un handler qui va rediriger une ecriture du log vers
	# un fichier en mode 'append', avec 1 backup et une taille max de 1Mo
	file_handler = RotatingFileHandler(cwd+os.sep+'launcher_activity.log', 'a', 1000000, 1)
	# on lui met le niveau sur DEBUG, on lui dit qu'il doit utiliser le formateur
	# cree precedement et on ajoute ce handler au logger
	file_handler.setLevel(logging.DEBUG)
	file_handler.setFormatter(formatter)
	logger.addHandler(file_handler)
	 
	# creation d un second handler qui va rediriger chaque ecriture de log
	# sur la console
	stream_handler = logging.StreamHandler()
	stream_handler.setLevel(logging.DEBUG)
	logger.addHandler(stream_handler)
	 
	try:
		exists = os.path.isfile(cwd+os.sep+'homeaction.txt')
		print exists
		if exists:
			file = open(cwd+os.sep+'homeaction.txt','r') 
			cmd=file.readline()
			file.close()
			os.remove(cwd+os.sep+'homeaction.txt')
			print cmd
			logger.info("start cmd %s ", str(cmd))
			os.system("sudo python "+cmd)
			logger.info("end cmd %s ", str(cmd))
		
	except :
		logger.error('Error %s', sys.exc_info()[0])
	
if __name__ == '__main__':	
	launcher()