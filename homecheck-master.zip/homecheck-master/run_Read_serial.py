#!/usr/bin/python
# -*-coding:Utf-8 -*

import time
import os
import tempfile
import serial
import urllib
import urllib2
import datetime
import sys

# attention ajouter permission sudo usermod -a -G dialout www-data 
if len(sys.argv)>1:
	testdetect=0
else:
	testdetect=0
	
cwd = tempfile.gettempdir() #os.path.dirname(os.path.realpath(__file__))

#print(os.path.dirname(os.path.realpath(__file__)))

try:
	ser = serial.Serial(
  
   port='/dev/ttyACM0',
   baudrate = 9600,
   parity=serial.PARITY_NONE,
   stopbits=serial.STOPBITS_ONE,
   bytesize=serial.EIGHTBITS,
   timeout=1
	)
		
except Exception, e:
	print e

 
def sendtoserv(val,dest):
	
	if dest==1:
		action="HomeCheck_ReceiverDetect"
	elif dest==2:
		action="HomeCheck_SetPic"

	command = "http://127.0.0.1:8080/action.php?action="+action+"&code="+val
	try:
		json_commands = urllib2.urlopen(command).read() 
	#Handle invalid IP
	except IOError, e:
		print("Invalid IP")
			
counter=0
gok=0
gexit=0

FMT = '%H:%M:%S'

#start_time = datetime.datetime.now().time().strftime(FMT)
listcode={}

while gexit==0:
	try:
		x=ser.readline()
		if x!="":
			code=x[0:8]  # Received
			if code=="Received":
				gok=1
				slash=x.find("/")
				val=x[9:slash]
				val=val.strip()
				# start = datetime.datetime.now()
				# print x
			if code=="ReturnLu":
				gok=2
				slash=x.find("/")
				val=x[9:slash]
				val=val.strip()
				
		elif gok>0:
				if testdetect==0:
					sendtoserv(val,gok)
				else:
					if listcode.has_key(val):
						listcode[val]+=1
					else:
						listcode[val]=1
					#print val
				gok=0
		
		if os.path.isfile(cwd+os.sep+"getcode.txt") and testdetect==0 :
			testdetect=1
			start_time = datetime.datetime.now().time().strftime(FMT)
			os.remove(cwd+os.sep+'getcode.txt')
			
		if testdetect!=0:
			newtime=datetime.datetime.now().time().strftime(FMT)		
			tdelta = (datetime.datetime.strptime(newtime,'%H:%M:%S') - datetime.datetime.strptime(start_time,'%H:%M:%S'))
			if tdelta.seconds>=15:
				maxtot=0
				for code, tot in listcode.items():
					if tot>maxtot:
						bestcode=code
						maxtot=tot
				if maxtot!=0:		
					#print "best code is %s with a total of %s" %(bestcode, maxtot)
					res=bestcode
				else:
					res= "Unknown"
				file = open(cwd+os.sep+"setcode.txt",'w') 
				file.write(res) 
				file.close() 
				testdetect=0
				
	except Exception, e:
		print e
		ser.close()	
		exit(0)